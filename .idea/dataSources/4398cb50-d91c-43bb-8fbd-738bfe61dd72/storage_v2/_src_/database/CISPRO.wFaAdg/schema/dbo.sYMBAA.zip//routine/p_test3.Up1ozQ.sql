CREATE proc [dbo].[p_test3]
 
as
 set xact_abort ON
 
  --开启事务
 
  begin transaction
 
    INSERT INTO [DBLINK_HISPRODEV]..HISPRO.TEST(ID,NAME) VALUES(1,'AAA');
	--INSERT INTO [192.168.8.13].FGHIS5.DBO.aaa VALUES(1);
 
 
    commit transaction
 set xact_abort OFF
go

