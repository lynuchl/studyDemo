-- dbo.V_DRUG_INFO source

CREATE view [dbo].[V_DRUG_INFO] as
select c.ITEM_ID  drug_id,
c.ITEM_ID drug_common_id,
c.ITEM_ID drug_spec_id,
'0' dept_id,
a.drug_name drug_name,
a.drug_name drug_common_name,
a.drug_name drug_chemical_name,
null product_area,
hvic.FEE_GRADE rmb_flag,
a.DRUG_FORM  drug_dosage_form,
a.DRUG_FORM basic_dose,
a.DOSE_UNITS  dose_unit,
a.CLASS_CODE  drug_class,
NULL pharm_class,
NULL pharm_subclass,
NULL injection_volume,
NULL injection_volume_unit,
NULL injection_separator,
b.RETAIL_PRICE  basic_retail_price,
b.TRADE_PRICE  conv_trade_price,
b.RETAIL_PRICE conv_retail_price,
b.MIN_UNITS basic_package_unit,
b.AMOUNT_PER_PACKAGE conv_packing_quantity,
b.DRUG_SPEC  conv_packing_unit,
c.ITEM_SPEC  drug_spec,
c.ITEM_SPEC basic_spec,
b.MIN_SPEC  ref_dosage,
null ref_freq,
null ref_usage,
b.MIN_UNITS  ref_unit,
null bidding_type,
null bidding_no,
b.APPROVAL_NO  approval_no,
null regist_brand,
null drug_bar_code,
------HIS药品精麻毒药值域：普通、毒麻、精神
a.TOXI_PROPERTY fine_hemp_poison,
null import_drug,
null essential_drug,
null drug_attr,
null supplier_id,
a.input_code input_code1,
a.input_code input_code2,
a.input_code input_code3,
b.MEMOS remarks,
null status,
null update_date,
null extend_attr,
null dept_code,
null status_remark from 
[DBLINK_HISPRODEV]..[COMM].[DRUG_DICT] a
left JOIN [DBLINK_HISPRODEV]..[COMM].[DRUG_PRICE_LIST]  b ON a.DRUG_CODE = b.DRUG_CODE AND a.DRUG_SPEC = b.MIN_SPEC 
LEFT JOIN [DBLINK_HISPRODEV]..[HISPRO].[PRICE_LIST_ADD_C] c ON b.DRUG_CODE = c.ITEM_CODE  AND b.DRUG_SPEC + b.FIRM_ID  = c.ITEM_SPEC 
LEFT JOIN [DBLINK_HISPRODEV]..[HISPRO].[HIS_VS_INSUR_CATALOG] hvic ON hvic.CODE_HIS  = c.ITEM_CODE + c.ITEM_SPEC 
WHERE c.ITEM_CLASS is not null
AND GETDATE()  >=start_date and (GETDATE()<stop_date or stop_date is null);
go

