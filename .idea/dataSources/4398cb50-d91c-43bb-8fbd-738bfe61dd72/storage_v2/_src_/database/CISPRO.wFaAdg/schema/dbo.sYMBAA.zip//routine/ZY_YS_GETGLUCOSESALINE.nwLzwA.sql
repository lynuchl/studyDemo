CREATE   PROCEDURE [dbo].[ZY_YS_GETGLUCOSESALINE](@bqid              int,
                                                   @deptId          int,
                                                   @uid             int,
                                                   @itemClass       int,
												   @advAttr			varchar(1),--医嘱属性：0-长期 1-临时 2-出院带药 3-中草药
                                                   @DRUG_CODE_LIST  varchar(1000)) AS
  -- CIS住院糖盐水项目查询
  BEGIN
          SELECT
           DISTINCT
            T.DRUG_CLASS AS itemClass,
            T.DRUG_CLASS_NAME AS className,
            T.RMB_FLAG AS rmbFlag,
            T.RMB_NAME AS rmbName,
            T.DRUG_ID AS itemCode,
            T.DRUG_NAME AS itemName,
            --常规包装量(整装数量)等于1，规格取基本规格,大于1 规格取包装规格
            --草药用基本规格
            CASE
              WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                T.BASIC_SPEC
              WHEN T.WHOLE_QUANTITY > 1 THEN
                T.CONV_PACKING_SPEC
            END AS spec,
            T.BASIC_DOSE AS basicDosage,
            T.DOSE_UNIT AS basicDosageUnit,
            T.WHOLE_QUANTITY AS wholeQuantity,
            T.PACKING_QUANTITY AS packingQuantity,
            T.PACKING_UNIT AS packingUnit,
            T.CONV_PACKING_QUANTITY AS convPackingQuantity,
            --常规包装量(整装数量)等于1，取基本单位,大于1 取常规包装单位
            --草药用基本单位
            CASE
              WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                T.DRUG_UNIT
              WHEN T.WHOLE_QUANTITY > 1 THEN
                T.CONV_PACKING_UNIT
            END AS convPackingUnit,
            T.CONV_PACKING_SPEC AS convPackingSpec,
            T.RETAIL_PRICE AS price,
            T.DRUG_SHOW AS drugShow,
            T.STOCK_QUANTITY AS stockQuantity,
            T.DEPT_ID AS deptId,
            T.DEPT_NAME AS deptName,
            T.INDICATION_REMARKS AS indicationRemarks,
            T.PRODUCT_PLACE AS productPlace,
            T.INPUT_CODE AS inputCode,
            T.IS_INDICATION AS indicationFlag,
            '' AS fineHempPoisonFlag,
            '' AS highPriceDrugFlag,
            '' AS antibioticsFlag,
            '1' AS upLowCabFlag
          FROM CISPRO..DRUG_GLUCOSE_SALINE_TEMP T;
  END;
go

