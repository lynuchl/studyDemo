CREATE PROCEDURE [dbo].[ZY_NURSE_In_Ward](
    @inp_id varchar(50)) AS

-- 护士站 新患者入区登记存储过程
BEGIN

    --写的伪代码，防止报错
    update CISCOMM..CIS_HOSTPITAL_INFO set ORG_CODE ='' where INP_ID = @inp_id;


end ;
go

