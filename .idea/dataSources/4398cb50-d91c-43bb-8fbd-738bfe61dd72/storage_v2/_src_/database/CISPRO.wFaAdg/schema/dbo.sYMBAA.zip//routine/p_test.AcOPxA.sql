-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_test]
	  @type   VARCHAR(12), 
	@mc	    VARCHAR(12), 
	@lsh	Int OUTPUT,
	@count	    int=1
AS
BEGIN
set xact_abort ON
		BEGIN TRAN
				IF NOT EXISTS(SELECT * FROM fghis5.dbo.住院_编码流水号  WHERE RTrim(分类)=@type AND  RTrim(名称) = @mc)
					INSERT INTO fghis5.dbo.住院_编码流水号(分类,名称,流水号,创建时间) VALUES (@type,@mc,0,getdate())

				UPDATE fghis5.dbo.住院_编码流水号 SET
					流水号 = 流水号 + @count,更新时间=GETDATE()
				WHERE RTrim(分类)=@type AND  RTrim(名称)=@mc

				SELECT @lsh = 流水号
				FROM fghis5.dbo.住院_编码流水号
				WHERE RTrim(分类)=@type AND  RTrim(名称)=@mc
			COMMIT TRAN	
			set XACT_ABORT OFF
END
go

