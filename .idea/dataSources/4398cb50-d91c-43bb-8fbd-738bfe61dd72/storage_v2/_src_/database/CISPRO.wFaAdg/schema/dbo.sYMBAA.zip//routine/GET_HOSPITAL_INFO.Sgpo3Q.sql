CREATE PROCEDURE [dbo].[GET_HOSPITAL_INFO]
  @lsh AS nvarchar 
AS
BEGIN
	insert into ciscomm..CIS_HOSTPITAL_INFO
select t.流水号 ID,
      t.门诊号 patient_id,
      t.住院号 inp_id,
      t.住院id IN_HOSPITAL_ID,
      t.附加id ADDITIONAL_ID,
      t.病案号 med_record_no,
      t.姓名 name,
      t.性别 gender,
      (substring(t.出生日期, 1, 4) + '-' +
              substring(t.出生日期, 5, 2) + '-' +
              substring(t.出生日期, 7, 2) ) birthday,
      t.住院状态 inp_stat,
      t.结算状态 checkout_flag,
      t.入院年龄 inp_age,
      t.所属病区 ward_id,
      a.科室名称 ward_name,
      t.所属科室 dept_id,
      b.科室名称 dept_name,
      t.床位id beds_id,
      t.床位号 bed_no,
      t.入院日期 inp_time,
      t.入院病区 inp_ward_id,
      c.科室名称 inp_ward_name,
      t.入院科室 inp_dept_id,
      d.科室名称 inp_dept_name,
      t.入院病情 inp_condition,
      t.入院途径 inp_pathway,
      t.入院诊断 inp_diagnosis_id,
      t.入院诊断名称 inp_diagnosis_name,
      t.当前病情 current_condition,
      t.陪客标识 accompany_guest_flag,
      t.护理等级 care_level,
      t.门诊诊断 outp_diagnosis,
      null discharge_time,
      t.床位id bed_doctor_id,
      t.床位号 bed_doctor_no,
      t.床位医师 bed_doctor_name,
      t.主治医师 attending_doctor_id,
      null attending_doctor_no,
      null attending_doctor_name,
      t.责任护士 resp_nurse_id,
      null resp_nurse_no,
      null resp_nurse_name,
      null org_code,
      null org_name,
      t.院区ID org_id,
      null medical_team_id,
      null medical_team_name,
      null discharge_diagnosis,
      null discharge_diagnosis_name,
      t.默认卡号 card_no,
      null path_flag,
      null path_name,
      null allergy_flag,
      t.住院次数 inp_times,
      t.身份标识 [identity],
      null isolate_flag,
      null chief_doctor_id,
      null chief_doctor_no,
      t.主任医生 chief_doctor_name,
      t.护士长 head_nurse_id,
      null head_nurse_no,
      null head_nurse_name,
      t.床位护士 bed_nurse_id,
      null bed_nurse_no,
      null bed_nurse_name,
      null single_disease,
      null single_disease_name,

      t.饮食类型 diet_type,
      t.备注 remarks,
      null discharge_condition,
      null room_no,
      null room_name,
      null inp_ward_time,
      t.输入码1 INPUT_CODE
           ,null INP_WARD_OPERATOR
           ,T.病人标识 PAT_ID
           ,T.记帐代码 ACCOUNT_CODE
           ,T.入院操作员ID INP_OPERATOR_ID
           ,T.入院操作工号 INP_OPERATOR_NO
           ,T.入院操作时间 INP_OPERATOR_TIME
           ,T.入院操作姓名 INP_OPERATOR_NAME
           ,T.预出院操作时间 PRE_LEVEL_TIME
           ,T.预出院操作员ID PRE_OPERATOR_ID
           ,T.出院操作员ID LEVEL_OPERATOR_ID
 from fghis5_zy.dbo.住院_住院登记表 t
             left join fghis5.dbo.系统_科室信息表 a
               on t.所属病区 = a.科室ID
             left join fghis5.dbo.系统_科室信息表 b
               on t.所属科室 = b.科室ID
             left join fghis5.dbo.系统_科室信息表 c
               on t.入院病区 = c.科室ID
             left join fghis5.dbo.系统_科室信息表 d
               on t.入院科室 = d.科室ID
            where t.住院状态 = 1 and not exists(select * from ciscomm..CIS_HOSTPITAL_INFO tt where tt.id=t.流水号);
END
go

