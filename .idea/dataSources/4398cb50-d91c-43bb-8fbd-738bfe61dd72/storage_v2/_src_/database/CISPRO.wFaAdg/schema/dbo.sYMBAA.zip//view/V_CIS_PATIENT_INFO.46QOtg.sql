-- dbo.V_CIS_PATIENT_INFO source

-- dbo.V_CIS_PATIENT_INFO source

CREATE VIEW dbo.V_CIS_PATIENT_INFO
AS
SELECT  t.PATIENT_ID AS ID, 
		t.PATIENT_ID AS outp_no,
		t.NAME, a.SEX_code AS gender,
		CONVERT(varchar(100), t.DATE_OF_BIRTH, 23) AS birth_date,
		CONVERT(varchar(100), t.DATE_OF_BIRTH, 24) AS birth_time,
		t.ID_NO AS id_card,
		t.CITIZENSHIP AS nationality,
		t.NATION,
		NULL AS blood_type,
		NULL AS marriage,
		'0' AS occupation,
		t.NEXT_OF_KIN_PHONE AS telephone,
		t.NEXT_OF_KIN_PHONE AS mobile_phone,
		t.BIRTH_PLACE AS birth_province,
		'0' AS birth_city,
		'0' AS birth_county,
		'0' AS native_place_province,
		'0' AS native_place_city,
		'0' AS native_place_county,
		'0' AS census_register_province,
		'0' AS census_register_city,
		'0' AS census_register_county,
		'0' AS census_register_info,
		'0' AS current_residence_province,
		'0' AS current_residence_city,
		'0' AS current_residence_county, 
		t.NEXT_OF_KIN_ADDR AS current_residence_info,
		NULL AS remarks,
		NULL AS source,
		t.OPERATOR AS create_name, 
		t.INSERT_DATE AS create_date,
		NULL AS height,
		NULL AS weight,
		t.ZIP_CODE AS POST_CODE,
		NULL AS FAITH,
		NULL AS PZH,
		NULL AS YXQ,
		NULL AS BMJB,
		NULL AS GRPH,
		NULL AS SCJZ,
		NULL AS JKKH,
		NULL AS VIP,
		NULL AS YY,
		NULL AS wbbh
FROM      DBLINK_HISPRODEV..MEDREC.PAT_MASTER_INDEX AS t LEFT OUTER JOIN
                   DBLINK_HISPRODEV..COMM.SEX_DICT AS a ON t.sex = a.sex_name;
go

