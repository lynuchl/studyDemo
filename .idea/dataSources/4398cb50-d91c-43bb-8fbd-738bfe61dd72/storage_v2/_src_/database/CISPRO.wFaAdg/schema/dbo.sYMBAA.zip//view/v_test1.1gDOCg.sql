CREATE VIEW dbo.v_test1
AS
SELECT  t.PATIENT_ID AS ID, t.PATIENT_ID AS outp_no, t.NAME, a.SEX_code AS gender, t.DATE_OF_BIRTH AS birth_date, NULL 
                   AS birth_time, t.ID_NO AS id_card, t.CITIZENSHIP AS nationality, t.NATION, NULL AS blood_type, NULL AS marriage, NULL 
                   AS occupation, t.NEXT_OF_KIN_PHONE AS telephone, t.NEXT_OF_KIN_PHONE AS mobile_phone, NULL 
                   AS birth_province, NULL AS birth_city, NULL AS birth_county, NULL AS native_place_province, NULL 
                   AS native_place_city, NULL AS native_place_county, NULL AS census_register_province, NULL 
                   AS census_register_city, NULL AS census_register_county, NULL AS census_register_info, NULL 
                   AS current_residence_province, NULL AS current_residence_city, NULL AS current_residence_county, 
                   t.NEXT_OF_KIN_ADDR AS current_residence_info, NULL AS remarks, NULL AS source, t.OPERATOR AS create_name, 
                   t.INSERT_DATE AS create_date, NULL AS height, NULL AS weight, t.ZIP_CODE AS POST_CODE, NULL AS FAITH, NULL 
                   AS PZH, NULL AS YXQ, NULL AS BMJB, NULL AS GRPH, NULL AS SCJZ, NULL AS JKKH, NULL AS VIP, NULL AS YY, NULL 
                   AS wbbh
FROM      DBLINK_HISPRODEV..MEDREC.PAT_MASTER_INDEX AS t LEFT OUTER JOIN
                   DBLINK_HISPRODEV..COMM.SEX_DICT AS a ON t.sex = a.sex_name
go

