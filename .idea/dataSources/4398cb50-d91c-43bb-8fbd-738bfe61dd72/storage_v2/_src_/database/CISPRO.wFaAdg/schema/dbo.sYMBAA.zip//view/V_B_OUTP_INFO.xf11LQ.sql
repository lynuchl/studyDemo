CREATE VIEW [dbo].[V_OUTP_INFO] AS
SELECT T.科室ID DEPT_ID,B.科室名称 DEPT_NAME,T.门诊代码 OUTP_CODE,T.门诊名称 OUTP_NAME,T.输入码 INPUT_CODE FROM  [FGHIS5_MZ].[dbo].代码_门诊信息表 T
 LEFT JOIN [FGHIS5].[dbo].代码_科室信息表 B ON B.科室ID=T.科室ID
go

