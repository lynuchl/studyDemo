
CREATE VIEW [dbo].[V_CIS_P_CREDENTIALS_INFO] AS 
/*SELECT
	ID,
	OUTP_NO,
	CREDENTIALS_TYPE,
	CREDENTIALS_NAME,
	CREDENTIALS_NUMBER,
	REMARKS,
	CREATE_NAME,
	CREATE_DATE,
	STATE 
FROM
	ciscomm..CIS_CREDENTIALS_INFO; */
	
	select T.流水号 id,
        T.门诊号 outp_no,
        T.证件类型 credentials_type,
        T.证件名称 credentials_name,
        T.证件号码 credentials_number,
        T.证件备注 remarks,
        T.创建人 create_name,
        T.创建日期 create_date,
        (case
        when t.状态 = 1 then
            0
        when t.状态 = 0 then
            1
        end) state
    from FGHIS5.dbo.系统_病人凭证信息附加表 T;
go

