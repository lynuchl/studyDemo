



CREATE VIEW [dbo].[V_TUMOR_DICT] AS
SELECT 肿瘤名称 AS TUMOR_NAME,肿瘤编码 AS TUMOR_CODE,输入码 INPUT_CODE
        FROM [FGCISBZ].[dbo].临床字典_肿瘤编码表 ;
go

