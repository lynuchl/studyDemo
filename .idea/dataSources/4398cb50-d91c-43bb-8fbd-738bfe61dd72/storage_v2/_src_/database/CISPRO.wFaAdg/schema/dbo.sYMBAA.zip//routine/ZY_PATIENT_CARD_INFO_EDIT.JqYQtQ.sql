CREATE PROCEDURE [dbo].[ZY_PATIENT_CARD_INFO_EDIT](@currentCondition VARCHAR(30),
                                                   @accompanyGuestFlag char(1),
                                                   @careLevel VARCHAR(30),
                                                   @bedDoctorId numeric(20),
                                                   @bedDoctorNo VARCHAR(10),
                                                   @bedDoctorName VARCHAR(100),
                                                   @attendingDoctorId numeric(20),
                                                   @attendingDoctorName VARCHAR(100),
                                                   @respNurseId numeric(20),
                                                   @respNurseName VARCHAR(100),
                                                   @isolateFlag CHAR(1),
                                                   @chiefDoctorId numeric(20),
                                                   @chiefDoctorName VARCHAR(100),
                                                   @headNurseId numeric(20),
                                                   @headNurseName VARCHAR(100),
                                                   @bedNurseId numeric(20),
                                                   @bedNurseName VARCHAR(100),
                                                   @singleDisease VARCHAR(100),
                                                   @dietType VARCHAR(30),
                                                   @patientId VARCHAR(36),
                                                   @inpId VARCHAR(36),
                                                   @mobilePhone VARCHAR(20),
                                                   @telephone VARCHAR(20))
AS
BEGIN

    -- 右键患者卡片信息住院信息修改

    UPDATE CISCOMM..cis_hostpital_info
    SET CURRENT_CONDITION     = @currentCondition,
        ACCOMPANY_GUEST_FLAG  = @accompanyGuestFlag,
        CARE_LEVEL            = @careLevel,
        BED_DOCTOR_ID         = @bedDoctorId,
        BED_DOCTOR_NO         = @bedDoctorNo,
        BED_DOCTOR_NAME       = @bedDoctorName,
        ATTENDING_DOCTOR_ID   = @attendingDoctorId,
        ATTENDING_DOCTOR_NAME = @attendingDoctorName,
        RESP_NURSE_ID         = @respNurseId,
        RESP_NURSE_NAME       = @respNurseName,
        ISOLATE_FLAG          = @isolateFlag,
        CHIEF_DOCTOR_ID       = @chiefDoctorId,
        CHIEF_DOCTOR_NAME     = @chiefDoctorName,
        HEAD_NURSE_ID         = @headNurseId,
        HEAD_NURSE_NAME       = @headNurseName,
        BED_NURSE_ID          = @bedNurseId,
        BED_NURSE_NAME        = @bedNurseName,
        SINGLE_DISEASE        = @singleDisease,
        DIET_TYPE             = @dietType
    WHERE INP_ID = @inpId;


    update CISPRO..V_CIS_PATIENT_INFO
    set MOBILE_PHONE = @mobilePhone,
        TELEPHONE    = @telephone
    where OUTP_NO = cast(@patientId as int);

END;
go

