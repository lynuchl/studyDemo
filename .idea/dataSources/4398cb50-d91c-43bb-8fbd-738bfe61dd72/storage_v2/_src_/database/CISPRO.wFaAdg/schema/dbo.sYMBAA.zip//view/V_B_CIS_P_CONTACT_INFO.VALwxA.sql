CREATE VIEW [dbo].[V_CIS_P_CONTACT_INFO] AS 
/*SELECT ID,OUTP_NO,NAME,RELATION,TELEPHONE,MOBILE_PHONE,EMAIL,CREATE_DATE,STATE,ADDR,DEFAULT_INFO,REMARKS FROM ciscomm..CIS_CONTACT_INFO;*/

select t.流水号   id,
        t.门诊号   outp_no,
        t.联系姓名 name,
   
        case when   t.联系关系 ='1' then'配偶'
            when   t.联系关系 ='2' then '子'
            when   t.联系关系 ='3' then '女'
            when   t.联系关系 ='4' then '孙子孙女或外孙子外孙女'
            when   t.联系关系 ='5' then '父母'
            when   t.联系关系 ='6' then '祖父母或者外祖父母'
            when   t.联系关系 ='7' then '兄弟姐妹'
            when   t.联系关系 ='9' then '其他'
                else '' end 
            relation,
        t.联系电话 telephone,
        t.联系手机 mobile_phone,
        t.联系邮箱 email,
        t.创建日期 create_date,
        t.状态     state,
        t.地址信息 addr,
        1          default_info,
        t.备注     remarks
    from FGHIS5.dbo.系统_病人联系信息附加表 T
go

