-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步申请医技大类(APPLY_MED_CATEGORY)
-- Description:	 通过作业定时去同步his中新增或者修改的医技大类信息
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_MED_CATEGORY]
	 
AS
BEGIN

      
    
      merge ciseapp..APPLY_MED_CATEGORY as A
	  using(
	  SELECT t.大类ID category_id, 
			t.大类代码 category_code, 
			t.大类名称 category_name, 
			(case when t.申请分类='5' then '3' else t.申请分类 end) apply_type, 
			t.显示序号 seq FROM fghis5_mz.dbo.代码_申请医技大类表  t
			)B ON A.category_id=B.category_id
			WHEN MATCHED THEN 
			UPDATE SET A.category_code=B.category_code,A.category_name=B.category_name,A.update_id='1',A.UPDATE_DATE=GETDATE()
			when not matched then 
			INSERT (CATEGORY_ID
           ,CATEGORY_CODE
           ,CATEGORY_NAME
           ,APPLY_TYPE
           ,SEQ
           ,[ENABLED]
           ,CREATE_ID
           ,CREATE_DATE
           ,UPDATE_ID
           ,UPDATE_DATE
           ,ORG_ID) 
		values(b.CATEGORY_ID
           ,b.CATEGORY_CODE
           ,b.CATEGORY_NAME
           ,b.APPLY_TYPE
           ,b.SEQ
           ,'0' 
           ,'-1' 
           ,getdate() 
           ,null 
           ,null 
           ,'10001' )	;
      		  
END

go

