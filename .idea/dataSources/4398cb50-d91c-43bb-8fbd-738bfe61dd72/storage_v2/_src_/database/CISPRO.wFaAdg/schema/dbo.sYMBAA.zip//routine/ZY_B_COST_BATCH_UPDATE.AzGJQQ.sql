CREATE  PROCEDURE [dbo].[ZY_COST_BATCH_UPDATE](@ids  varchar(500)) AS

BEGIN

    update t set
		t.状态 = t1.STATUS
  from FGHIS5_ZY.dbo.住院_费用药品表 t
  inner join cisnurs..nur_cost t1 on t.费用ID = t1.id
  where t1.id in (select * from F_STRSPLIT(@ids))
       and t1.item_class in (1, 2, 3) ;


  update t set
		t.状态 = t1.STATUS
  from FGHIS5_ZY.dbo.住院_费用化验表 t
  inner join cisnurs..nur_cost t1 on t.费用ID = t1.id
  where t1.id in (select * from F_STRSPLIT(@ids))
       and t1.item_class in (7) ;

    update t set
		t.状态 = t1.STATUS
  from FGHIS5_ZY.dbo.住院_费用其他表 t
  inner join cisnurs..nur_cost t1 on t.费用ID = t1.id
  where t1.id in (select * from F_STRSPLIT(@ids))
       and t1.item_class not in (1,2,3,7);

END;
go

