--exec SYNC_APPLY_INSPECT_MASTER '0387431','613881'
-- **********************************************************************************----    
--1)功能描述：CIS住院医生，开立的医技医嘱，将数据插入至HIS申请单表中
--由于目前无法与第三检验直接对接，所以才采用当前这模式，将数据插入至HIS申请单表中
-- ********************************************************************************----
CREATE   PROCEDURE [dbo].[SYNC_APPLY_INSPECT_MASTER]
(@v_inpatno varchar(20), @v_apply_id INT) 
AS
begin

declare @num int,@count  int
DECLARE @Start_date DATE,@End_date date
set @Start_date=convert(varchar(10),GETDATE(),120)
set @End_date=convert(varchar(10),GETDATE()+1,120)
set @num=0
set @count=1

if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_ADVICE_GROUP'))
begin
	DROP TABLE #TEMP_ADVICE_GROUP;
	DROP TABLE #TEMP_ADVICE_NEW ;
end
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_ADVICE'))
   BEGIN
		DROP TABLE #TEMP_ADVICE;
   END
   else
   begin
       CREATE TABLE #TEMP_ADVICE (
						APPLY_ID numeric(20, 0) NULL,
						ADVICE_ID numeric(20, 0) NULL,
						EXTE_NUM varchar(200) NULL,
						EXTE_CODE varchar(50) NULL,
						CONFIRM_DATE datetime NULL,
						PRESC_ID INT 
					)
					 
   end

      ----当住院号与申请单号不为空时，按照住院号和申请单号查询对应信息，否则查询当天未被同步的申请单数据
       if @v_inpatno<>'' and @v_apply_id>0
	     begin
		   insert into #TEMP_ADVICE
			 select distinct D.APPLY_ID, T.ADVICE_ID,t.EXTE_NUM,T.EXTE_CODE,T.CONFIRM_DATE ,NULL PRESC_ID   from CISDOCT..DOC_ADVICE_EXTEND t
			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
			INNER JOIN CISEAPP..APPLY_INSPECT_DETAIL D ON T.EXTE_NUM = D.APPLY_ID and T.EXTE_CODE = D.APPLY_ORDER_NUM
			where D.APPLY_ID=@v_apply_id and a.INPAT_NO=@v_inpatno   and t.EXECUTE_DEPT_ID in(74,78) AND A.STATUS IN(2,3,4,7) 
			AND D.apply_state = '0'
			and not exists(select * from CISEAPP..APPLY_INSPECT_RECORD r where r.advice_id=t.ADVICE_ID);
			 
-- 			select B.APPLY_ID, T.ADVICE_ID,t.EXTE_NUM,T.EXTE_CODE,T.CONFIRM_DATE ,NULL PRESC_ID from CISDOCT..DOC_ADVICE_EXTEND t
-- 			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
-- 			INNER JOIN CISEAPP..APPLY_INSPECT_MASTER B ON T.EXTE_NUM=B.TEAM_ID 
-- 			where b.APPLY_ID=@v_apply_id and a.INPAT_NO=@v_inpatno  and t.EXECUTE_DEPT_ID in(74,78) AND A.STATUS IN(2,3,4,7) AND B.APPLY_STATE in (1,2)
-- 			and not exists(select * from CISEAPP..APPLY_INSPECT_RECORD r where r.advice_id=t.ADVICE_ID);
         end
	   else
	     begin
		    insert into #TEMP_ADVICE
				select distinct D.APPLY_ID, T.ADVICE_ID,t.EXTE_NUM,T.EXTE_CODE,T.CONFIRM_DATE ,NULL PRESC_ID   from CISDOCT..DOC_ADVICE_EXTEND t
			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
			INNER JOIN CISEAPP..APPLY_INSPECT_DETAIL D ON T.EXTE_NUM = D.APPLY_ID and T.EXTE_CODE = D.APPLY_ORDER_NUM
			where   (T.CONFIRM_DATE>=@Start_date and T.CONFIRM_DATE<@End_date) and t.EXECUTE_DEPT_ID in(74,78) AND A.STATUS IN(2,3,4,7) 
			AND D.apply_state = '0'
			and not exists(select * from CISEAPP..APPLY_INSPECT_RECORD r where r.advice_id=t.ADVICE_ID);
				
-- 		      select B.APPLY_ID, T.ADVICE_ID,t.EXTE_NUM,T.EXTE_CODE,T.CONFIRM_DATE ,NULL PRESC_ID   from CISDOCT..DOC_ADVICE_EXTEND t
-- 			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
-- 			INNER JOIN CISEAPP..APPLY_INSPECT_MASTER B ON T.EXTE_NUM=B.TEAM_ID 
-- 			where   (T.CONFIRM_DATE>=@Start_date and T.CONFIRM_DATE<@End_date) and t.EXECUTE_DEPT_ID in(74,78) AND A.STATUS IN(2,3,4,7) AND B.APPLY_STATE in (1,2)
-- 			and not exists(select * from CISEAPP..APPLY_INSPECT_RECORD r where r.advice_id=t.ADVICE_ID);
		 end

         --print '已完成查询当天未被同步';
          -----获取申请单个数
		  select @count=count(0) from #TEMP_ADVICE 
   		 if @count>0
		 begin
		       BEGIN TRAN
					UPDATE fghisdb.dbo.编码_流水号 SET 编码序号=编码序号+@count WHERE 编码名称='ZY_医嘱编号'
					--IF @@ERROR <> 0 GOTO ERR
					SELECT @num=ISNULL(MAX(编码序号),@count) FROM fghisdb.dbo.编码_流水号 with (nolock)  WHERE 编码名称='ZY_医嘱编号'

					--IF @@ERROR <> 0 GOTO ERR
			   COMMIT TRAN
		 end

		-- print '已完成取申请序列';
		 select APPLY_ID, ADVICE_ID,EXTE_NUM,EXTE_CODE,CONFIRM_DATE ,@num-(row_number() over(order by APPLY_ID)-1) PRESC_ID into #TEMP_ADVICE_NEW from #TEMP_ADVICE
		 select APPLY_ID,PRESC_ID into #TEMP_ADVICE_GROUP from(
		 SELECT APPLY_ID,PRESC_ID,row_number() over(partition by APPLY_ID order by presc_id desc) xh from #TEMP_ADVICE_NEW
		 )bb where bb.xh=1

begin tran

--     DECLARE @TEMP_ADVICE_MAIN table(APPLY_ID numeric(20, 0) NULL,PRESC_ID INT)
--		 INSERT INTO @TEMP_ADVICE_MAIN
--		 SELECT t.APPLY_ID,t.PRESC_ID FROM (SELECT APPLY_ID,PRESC_ID,ROW_NUMBER() OVER(PARTITION BY APPLY_ID ORDER BY EXTE_CODE DESC) rn FROM #TEMP_ADVICE) t WHERE t.rn = 1
---- 
		INSERT INTO  [FGHIS5_MZ].[dbo].[申请_检查申请单]
			   ([申请单号],[单次申请唯一号],[病人类型],[门诊号],[住院号],[姓名],[性别],[年龄],[记帐代码],[就诊ID],[挂号代码]
				,[所属病区],[所属科室],[床位号],[结账ID],[处方ID],[申请日期],[申请时间],[申请ID],[申请工号],[主述体征],[辅助检查]
				,[病史概要],[临床诊断],[受理科室],[分类代码],[分类名称],[费用状态],[申请状态],[备注],[项目代码],[项目名称]
				,[外部编号],[住院ID],[附加ID],[排队时间],[执行工号],[体格检查]
				)
	SELECT ta.APPLY_ID 申请单号
		  ,t.TEAM_ID 单次申请唯一号
		  ,PATIENT_TYPE 病人类型
		  ,T.PATIENT_ID 门诊号
		  ,T.INP_ID 住院号
		  ,A.NAME 姓名
			,case when A.GENDER = '1' then '男' when  A.GENDER = '2' then '女' else '其他' end 性别
		  ,A.INP_AGE 年龄
		  ,A.ACCOUNT_CODE 记帐代码
		  ,isnull(VISIT_NO,'0') 就诊ID
		  ,0 挂号代码
		  ,A.WARD_ID 所属病区
		  ,T.DEPT_ID 所属科室
		  ,A.BED_NO 床位号
		  ,isnull(ACCOUNT_NO,'0') 结账ID
		  ,TA.PRESC_ID 处方ID
		  ,CONVERT(varchar(8),t.APPLY_TIME,112) 申请日期
		  ,replace(CONVERT(varchar(8),t.APPLY_TIME,108),':','') 申请时间
		  ,T.CREATE_ID 申请ID
		  ,c.OPERATE_NO 申请工号
		  ,MAIN_SIGNS 主述体征
		  ,ASSIST_INSPECT 辅助检查
		  ,MEDICAL_HISTORY 病史概要
		  ,CLINICAL_DIAGNOSIS 临床诊断
		  ,ACCEPT_DEPT_ID 受理科室
		  ,B.CATEGORY_CODE 分类代码
		  ,T.CATEGORY_NAME 分类名称
		  ,0 费用状态
		  ,0 申请状态
		  ,t.REMARKS 备注
		  ,null 项目代码
		  ,null 项目名称
		  ,t.TEAM_ID 外部编号
		  ,A.IN_HOSPITAL_ID 住院ID
		  ,A.ADDITIONAL_ID 附加ID
		  ,APPLY_TIME 排队时间
		  ,EXCUTE_NO 执行工号
		  ,'' 体格检查 FROM #TEMP_ADVICE_GROUP ta 
		  inner join  CISEAPP..APPLY_INSPECT_MASTER T on ta.APPLY_ID=T.APPLY_ID
		  INNER JOIN CISCOMM..CIS_HOSTPITAL_INFO A ON T.INP_ID=A.INP_ID
		  LEFT JOIN CISEAPP..APPLY_MED_CATEGORY B ON T.CATEGORY_ID=B.CATEGORY_ID
		  left join ciscomm..AUTH_OPERATOR C on t.CREATE_ID=c.ID
		  --where exists(select * from #TEMP_ADVICE tp where tp.EXTE_NUM=t.TEAM_ID)
		  ;
		  --print '已完成存主检查申请单';

		 INSERT INTO [FGHIS5_MZ].[dbo].[申请_检查申请单明细]
           ([申请单号],[申请序号],[处方ID],[分类代码],[分类名称],[医嘱代码],[医嘱名称]
			,[单价],[数量],[金额],[检查部位],[检查要求],[包含介质],[费用状态]
			,[申请状态],[备注],[外部编号],[体位],[医嘱ID],[登记明细ID],[套餐分类ID],[地址]
			)
		select a.APPLY_ID [申请单号]
		,a.APPLY_ORDER_NUM [申请序号]
		,ta.PRESC_ID [处方ID]
		,c.CATEGORY_CODE [分类代码]
		,b.CATEGORY_NAME [分类名称]
		,p.MED_ADVICE_CODE [医嘱代码]
		,a.MED_ADVICE_NAME [医嘱名称]
		,PRICE [单价]
		,COUNT [数量]
		,AMOUNT [金额]
		,isnull(d.POSITION_NAME,'') [检查部位]
		,a.REQUIREMENTS [检查要求]
		,IS_NEED_MEDIUM [包含介质]
		,0 [费用状态]
		,0 [申请状态]
		----HIS医技申请状态：0 新申请  5 科室接收 6 科室完成  8 报告完成
		----CIS申请状态： 0暂存、1新申请、2护士确认、4科室接收、5科室取消（第三方回传）、6报告审核、7报告完成、8退费（仅门诊）、99作废
		,p.REMARKS [备注]
		,null [外部编号]
		,e.SUBCLASS_NAME [体位]
		,null [医嘱ID]
		,0 [登记明细ID]
		,COMBO_ID [套餐分类ID]
		,'' [地址]

		  FROM CISEAPP..APPLY_INSPECT_DETAIL a 
		  inner join #TEMP_ADVICE_NEW ta on a.APPLY_ID=ta.APPLY_ID and a.APPLY_ORDER_NUM = ta.EXTE_CODE
		  inner join CISEAPP..APPLY_INSPECT_MASTER b on a.APPLY_ID=b.APPLY_ID 
			LEFT JOIN CISEAPP..APPLY_MED_PROJECT p on a.med_advice_id = p.med_advice_id
		  LEFT JOIN CISEAPP..APPLY_MED_CATEGORY c ON b.CATEGORY_ID=c.CATEGORY_ID
		  left join CISEAPP..APPLY_MED_POSITION d on a.INSPECT_POSITION=convert(varchar(20),d.POSITION_ID)
		  left join CISEAPP..APPLY_MED_SUB_CATEGORY e on p.SUBCLASS_ID=convert(varchar(20),e.SUBCLASS_ID)
		  --where exists(select * from #TEMP_ADVICE tp where tp.EXTE_NUM=b.TEAM_ID);

		  --print '已完成存主检查申请单明细';

		  insert into CISEAPP..APPLY_INSPECT_RECORD
		  select APPLY_ID, ADVICE_ID,EXTE_NUM,EXTE_CODE,CONFIRM_DATE,@Start_date,1 TYPE from #TEMP_ADVICE t where not exists(select * from CISEAPP..APPLY_INSPECT_RECORD r where r.advice_id=t.ADVICE_ID)

		 -- print '保存申请单记录'
	     IF @@ROWCOUNT=0 AND @@ERROR = 0 GOTO ERR
	    COMMIT TRAN 
		drop table #TEMP_ADVICE
		DROP TABLE #TEMP_ADVICE_GROUP
		DROP TABLE #TEMP_ADVICE_NEW
  RETURN(0) 
ERR:
  ROLLBACK TRAN
  RAISERROR('保存检查申请数据失败！',1,2) WITH NOWAIT 
 
  RETURN(-1)
END
go

