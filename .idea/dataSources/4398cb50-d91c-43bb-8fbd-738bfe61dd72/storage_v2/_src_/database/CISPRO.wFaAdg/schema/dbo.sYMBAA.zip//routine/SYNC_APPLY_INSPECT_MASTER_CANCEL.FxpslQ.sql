create PROCEDURE [dbo].[SYNC_APPLY_INSPECT_MASTER_CANCEL]
(@apply_id INT) 
AS
BEGIN

  DELETE from [FGHIS5_MZ].[dbo].[申请_检查申请单] where 申请单号 = @apply_id and 申请状态 = '0' and 费用状态 = '0'

  DELETE from [FGHIS5_MZ].[dbo].[申请_检查申请单明细] where 申请单号 = @apply_id  and 申请状态 = '0' and 费用状态 = '0'

	-- routine body goes here, e.g.
	-- SELECT 'Navicat for SQL Server'
END
go

