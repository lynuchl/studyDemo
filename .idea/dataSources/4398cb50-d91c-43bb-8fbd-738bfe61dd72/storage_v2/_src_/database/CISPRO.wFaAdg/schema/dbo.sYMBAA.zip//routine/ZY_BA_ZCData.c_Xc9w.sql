/****** Object:  StoredProcedure [dbo].[ZY_BA_ZCData]    Script Date: 2023/1/12 10:15:33 ******/
CREATE PROCEDURE  [dbo].[ZY_BA_ZCData] (@baID int,@type varchar(2))      
        
as 

 --@type:0 临床_    
	----ZHANGWEI:20170223修改，增加 新字段 HIS病案ID，为了和临床_病史登记表关联,
	----原来的 病案ID 只让泽信使用
	IF @baID=0 RETURN      
	declare @strdj varchar(3000)   
	declare @strdjCIS varchar(3000)
	declare @strdjHis varchar(3000)   
	declare @strdjHisCIS varchar(3000)
	declare @strzd varchar(1000)     
	declare @strzdCIS varchar(1000)  
	declare @strzdHis varchar(1000)     
	declare @strzdHisCIS varchar(1000)  
	declare @strss varchar(1000) 
	declare @strssCIS varchar(1000)   
	declare @strssHis varchar(1000) 
	declare @strssHisCIS varchar(1000)
	declare @strye VARCHAR(1000)   
	declare @stryeCIS VARCHAR(1000)
	declare @dj varchar(3000)      
	declare @zd varchar(1000)      
	declare @ss varchar(1000)  
	declare @ye varchar(1000)

	declare @qkdj varchar(3000)      
	declare @qkzd varchar(1000)      
	declare @qkss varchar(1000)

	declare  @djsj int    
	declare  @zdsj int   
	declare  @sssj int   
	declare  @yesj int

	declare @病案ID INT  
	set @strdj='病案ID, 住院ID, 附加ID, 条形码, 主病案号, 病案号, 住院号, 病案状态, 病案类型, 存放地址, 健康卡号,       
	 医疗付款方式, 住院次数, 门诊号, 记帐代码, 姓名, 性别, 出生日期, 年龄, 婚姻, 职业代码, 民族, 国籍,        
	 身份证号, 出生地址, 籍贯, 家庭地址, 家庭电话, 家庭邮编, 户口地址, 户口邮编, 单位名称, 单位电话,        
	 单位邮编, 联系姓名, 联系关系, 联系地址, 联系电话, 入院途径, 入院日期, 入院科室, 入院病区, 入院床号,       
	 转科情况, 出院日期, 出院科室, 所属病区, 出院床号, 住院天数, 入院确诊日期, 外地病人, 出院待查,        
	 门诊与出院, 入院与出院, 手术前后, 临床与病理, 放射与病理, 有无药物过敏, 药物过敏, HBsAg, HCVAb,        
	 HIVAb, 抢救次数, 成功次数, 血型, Rh, 输血反应, 尸检, 妊娠梅毒筛查, 医源性手术, 医源性本院,        
	 是否产后出血, 产后出血量, 科主任ID, 主任医师ID, 主治医师ID, 住院医师ID, 责任护士ID, 进修医师ID,        
	 实习医师ID, 编码员ID, 质控医师ID, 质控护士ID, 质控日期, 病案质量, 死亡日期, 离院方式, 转院接收医院,        
	 转院接收卫生院, 再住院, 再住院目的, 入院前昏迷时间, 入院后昏迷时间, 治疗类别, 自制中药, 实施临床路径,        
	 使用医疗机构中药制剂, 使用中医诊疗设备, 使用中医诊疗技术, 辨证施护, 打印次数, 备注, 借阅标志, 完整性标志,        
	 借阅ID, 销毁号,卡类型,卡号,特需病人,输血记录,输血量U,输血量ML,输血方法,入院时主要症状及体征,院区ID'  
	set @strdjCIS='MRD_REGSTER_ID,INPAT_NO,null 附加ID,BAR_CODE,MRD_REGSTER_M_NO,MRD_REGSTER_NO,null 住院号,MRD_STATUS,MRD_TYPE,null 存放地址,HEALTH_CARD_NUM,
	 MEDICAL_MODE,INPAT_NUM,OUTP_NO,ACCOUNT_CODE,NAME,GENDER,BIRTHDAY,AGE,MARRIAGE,OCCUPATION_CODE,NATION,NATIONALITY,
	 ID_NUM,BORN_ADDRESS,NATIVE_PLACE,HOME_ADDRESS,HOME_TELEPHONE,HOME_ZIP_CODE,REGISTER_ADDRESS,REGISTER_ZIP_CODE,UNIT_NAME,UNIT_TELEPHONE,
	 UNIT_ZIP_CODE,CONTACT_NAME,CONTACT_RELATION,CONTACT_ADDRESS,CONTACT_TELEPHONE,INP_WAY,null 入院日期,INP_DEPT_ID,INP_WARD_ID,null 入院床号,
	 null 转科情况,LEAVE_DATE,LEAVE_DEPT_ID,BELONG_WARD,LEAVE_BED_NO,INP_DAYS,INP_MAKE_DATE,null 外地病人,LEAVE_CHECKED,
	 OUTP_LEAVE,INP_LEAVE,null 手术前后,CLINIC_PATHOLOGY,EMIT_PATHOLOGY,IS_DRUG_ALLERGY,DRUG_ALLERGY,HBSAG,HCVAB,
	 HIVAB,RESCUE_TIMES,SUCCESS_TIMES,BLOOD_TYPE,RH,TRANSFUSION_REACTION,IS_AUTOPSY,null 妊娠梅毒筛查,null 医源性手术,null 医源性本院,
	 IS_PPH,null 产后出血量,SECTION_DIRECTOR_ID,CHIEF_DOCTOR_ID,ATTENDING_DOCTOR_ID,HOSPITAL_DOCTOR_ID,RESP_NURSE_ID,REFRESHER_DOCTOR_ID,
	 INTERN_ID,CODER_ID,QUALITY_DOCTOR_ID,QUALITY_NURS_ID,QUALITY_DATE,MRD_QUALITY,DEATH_DATE,LEAVE_MODE,TRANS_RECEIVE_HOSPITAL,
	 TRANS_RECEIVE_CLINIC,null 再住院,null 再住院目的,null 入院前昏迷时间,null 入院后昏迷时间,null 治疗类别,null 自制中药,null 实施临床路径,
	 null 使用医疗机构中药制剂,null 使用中医诊疗设备,null 使用中医诊疗技术,NURSING,PRITE_NUM,null 备注,BORROW_FLAG,INTEGRITY,
	 BORROW_ID,DESTROY_NO,CARD_TYPE,CARD_NO,null 特需病人,null 输血记录,null 输血量U,null 输血量ML,null 输血方法,null 入院时主要症状及体征,ORG_ID'

	 set @strdjHis='HIS病案ID,病案ID, 住院ID, 附加ID, 条形码, 主病案号, 病案号, 住院号, 病案状态, 病案类型, 存放地址, 健康卡号,       
	 医疗付款方式, 住院次数, 门诊号, 记帐代码, 姓名, 性别, 出生日期, 年龄, 婚姻, 职业代码, 民族, 国籍,        
	 身份证号, 出生地址, 籍贯, 家庭地址, 家庭电话, 家庭邮编, 户口地址, 户口邮编, 单位名称, 单位电话,        
	 单位邮编, 联系姓名, 联系关系, 联系地址, 联系电话, 入院途径, 入院日期, 入院科室, 入院病区, 入院床号,       
	 转科情况, 出院日期, 出院科室, 所属病区, 出院床号, 住院天数, 入院确诊日期, 外地病人, 出院待查,        
	 门诊与出院, 入院与出院, 手术前后, 临床与病理, 放射与病理, 有无药物过敏, 药物过敏, HBsAg, HCVAb,        
	 HIVAb, 抢救次数, 成功次数, 血型, Rh, 输血反应, 尸检, 妊娠梅毒筛查, 医源性手术, 医源性本院,        
	 是否产后出血, 产后出血量, 科主任ID, 主任医师ID, 主治医师ID, 住院医师ID, 责任护士ID, 进修医师ID,        
	 实习医师ID, 编码员ID, 质控医师ID, 质控护士ID, 质控日期, 病案质量, 死亡日期, 离院方式, 转院接收医院,        
	 转院接收卫生院, 再住院, 再住院目的, 入院前昏迷时间, 入院后昏迷时间, 治疗类别, 自制中药, 实施临床路径,        
	 使用医疗机构中药制剂, 使用中医诊疗设备, 使用中医诊疗技术, 辨证施护, 打印次数, 备注, 借阅标志, 完整性标志,        
	 借阅ID, 销毁号,卡类型,卡号,特需病人,输血记录,输血量U,输血量ML,输血方法,入院时主要症状及体征,院区ID'  
	 set @strdjHisCIS='MRD_REGSTER_ID,MRD_REGSTER_ID,INPAT_NO,null 附加ID,BAR_CODE,MRD_REGSTER_M_NO,MRD_REGSTER_NO,null 住院号,MRD_STATUS,MRD_TYPE,null 存放地址,HEALTH_CARD_NUM,
	 MEDICAL_MODE,INPAT_NUM,OUTP_NO,ACCOUNT_CODE,NAME,GENDER,BIRTHDAY,AGE,MARRIAGE,OCCUPATION_CODE,NATION,NATIONALITY,
	 ID_NUM,BORN_ADDRESS,NATIVE_PLACE,HOME_ADDRESS,HOME_TELEPHONE,HOME_ZIP_CODE,REGISTER_ADDRESS,REGISTER_ZIP_CODE,UNIT_NAME,UNIT_TELEPHONE,
	 UNIT_ZIP_CODE,CONTACT_NAME,CONTACT_RELATION,CONTACT_ADDRESS,CONTACT_TELEPHONE,INP_WAY,null 入院日期,INP_DEPT_ID,INP_WARD_ID,null 入院床号,
	 null 转科情况,LEAVE_DATE,LEAVE_DEPT_ID,BELONG_WARD,LEAVE_BED_NO,INP_DAYS,INP_MAKE_DATE,null 外地病人,LEAVE_CHECKED,
	 OUTP_LEAVE,INP_LEAVE,null 手术前后,CLINIC_PATHOLOGY,EMIT_PATHOLOGY,IS_DRUG_ALLERGY,DRUG_ALLERGY,HBSAG,HCVAB,
	 HIVAB,RESCUE_TIMES,SUCCESS_TIMES,BLOOD_TYPE,RH,TRANSFUSION_REACTION,IS_AUTOPSY,null 妊娠梅毒筛查,null 医源性手术,null 医源性本院,
	 IS_PPH,null 产后出血量,SECTION_DIRECTOR_ID,CHIEF_DOCTOR_ID,ATTENDING_DOCTOR_ID,HOSPITAL_DOCTOR_ID,RESP_NURSE_ID,REFRESHER_DOCTOR_ID,
	 INTERN_ID,CODER_ID,QUALITY_DOCTOR_ID,QUALITY_NURS_ID,QUALITY_DATE,MRD_QUALITY,DEATH_DATE,LEAVE_MODE,TRANS_RECEIVE_HOSPITAL,
	 TRANS_RECEIVE_CLINIC,null 再住院,null 再住院目的,null 入院前昏迷时间,null 入院后昏迷时间,null 治疗类别,null 自制中药,null 实施临床路径,
	 null 使用医疗机构中药制剂,null 使用中医诊疗设备,null 使用中医诊疗技术,NURSING,PRITE_NUM,null 备注,BORROW_FLAG,INTEGRITY,
	 BORROW_ID,DESTROY_NO,CARD_TYPE,CARD_NO,null 特需病人,null 输血记录,null 输血量U,null 输血量ML,null 输血方法,null 入院时主要症状及体征,ORG_ID'

	set @strzd='HIS病案ID,诊断ID, 病案ID, 序号,诊断类型, 诊断编码, 诊断名称, 治疗结果, 统计码, 入院病情, 病理号'   
	set @strzdCIS='MRD_REGSTER_ID,DIAGNOSIS_ID, MRD_REGSTER_ID, SERIAL_NUM, DIAGNOSIS_TYPE, DIAGNOSIS_CODE, DIAGNOSIS_NAME, TREAT_RESULT, STATISTICAL_CODE, INP_CONDITION, PATHOLOGY_NO';

	set @strzdHis='HIS病案ID,诊断ID, 病案ID, 序号,诊断类型, 诊断编码, 诊断名称, 治疗结果, 统计码, 入院病情, 病理号'   
	set @strzdHisCIS='MRD_REGSTER_ID,DIAGNOSIS_ID, MRD_REGSTER_ID, SERIAL_NUM, DIAGNOSIS_TYPE, DIAGNOSIS_CODE, DIAGNOSIS_NAME, TREAT_RESULT, STATISTICAL_CODE, INP_CONDITION, PATHOLOGY_NO';

	set @strss='HIS病案ID,手术ID,病案ID, 序号, 手术编码, 手术名称, 手术日期, 主刀医师, 一助, 二助,       
	 麻醉, 切口等级, 愈合级别, 麻醉医师, 指导医师, 手术级别, 统计标志, 是否手术, 手术科室, 状态'
	set @strssCIS='MRD_REGSTER_ID,OPERATION_ID, MEDICAL_RECORD_ID, SERIAL_NO, OPERATION_CODE, OPERATION_NAME, OPERATION_DATE, BUTCHER_PHYSICIAN, ONE_ASSISTANT, TWO_ASSISTANT,
	 ANESTHESIA, INCISION_LEVEL, HEAL_LEVEL, ANESTHESIA_PHYSICIAN, GUIDE_PHYSICIAN, OPERATION_LEVEL, STAT_SIGN, OPERATION_FLAG, OPERATION_DEPT, STATUS' ;
 
 	set @strssHis='HIS病案ID,手术ID,病案ID, 序号, 手术编码, 手术名称, 手术日期, 主刀医师, 一助, 二助,       
	 麻醉, 切口等级, 愈合级别, 麻醉医师, 指导医师, 手术级别, 统计标志, 是否手术, 手术科室, 状态'
	set @strssHisCIS='MRD_REGSTER_ID,OPERATION_ID, MEDICAL_RECORD_ID, SERIAL_NO, OPERATION_CODE, OPERATION_NAME, OPERATION_DATE, BUTCHER_PHYSICIAN, ONE_ASSISTANT, TWO_ASSISTANT,
	 ANESTHESIA, INCISION_LEVEL, HEAL_LEVEL, ANESTHESIA_PHYSICIAN, GUIDE_PHYSICIAN, OPERATION_LEVEL, STAT_SIGN, OPERATION_FLAG, OPERATION_DEPT, STATUS' ;
 
	--set @strye='婴儿ID,病案ID,APG评分,性别,身长,体重,出生日期,年龄,出生体重,入院体重,胎次,产次,胎别,孕周,产出情况,分娩方式,出院情况,
	-- 疾病编码,疾病名称,甲低,PKU,听力,CH,CAH,G6PD,七日,胎心,死亡日期,呼吸,评分,卡介苗,乙肝疫苗,TSH,感染次数,感染部位,
	-- 抢救次数,成功次数,疾病编码2,疾病名称2,疾病编码3,疾病名称3,死亡原因,半小时饱奶'   
	--set @stryeCIS='BABY_ID,MRD_REGSTER_ID,APG_SCORE,SEX,BODY_LENGTH,WEIGHT,BIRTH_DATE,AGE,BIRTH_WEIGHT,HOSPITAL_WEIGHT,FETUX_NUMBERS,PRODUCTION_TIMES,FETUX_SEX,GESTATIONAL_WEEKS,HOSPITAL_SITUATION,DELIVERY_WAY,HOSPITAL_SITUATION,
	-- DISEASE_CODE,DISEASE_NAME,A_LOW,PKU,HEAR,CH,CAH,G6PD,SEVEN_DAYS,FETUX_HEART,DEATH_DATE,BREATH,SCORE,BCG_VACCINE,HEPATITIS_B_VACCINE,TSH,INFECTION_NUMBERS,INFECTION_SITE,
	-- SAVE_NUMBERS,SUCCESS_NUMBERS,DISEASE_CODE2,DISEASE_NAME2,DISEASE_CODE3,DISEASE_NAME3,DEATH_CAUSE,HALF_AN_HOUR_FULL_MILK'  

	--
	set @djsj=(select 1 from  FGHIS5_ZY..病史_病史登记表 where HIS病案ID=@baID)  
	IF (@djsj>0)     
	begin        
		delete FGHIS5_ZY..病史_病史登记表 where HIS病案ID=@baID    
	end  
	--
	set @zdsj= (select top 1 1 from  FGHIS5_ZY..病史_病史诊断表 where HIS病案ID=@baID) 
	IF (@zdsj>0)  
	begin        
		delete FGHIS5_ZY..病史_病史诊断表 where HIS病案ID=@baID     
	end  
	--
	set @sssj=(select top 1 1 from  FGHIS5_ZY..病史_病史手术表 where HIS病案ID=@baID)  
	IF  (@sssj>0)       
	begin        
		delete FGHIS5_ZY..病史_病史手术表 where HIS病案ID=@baID     
	end  
	--
	--set @yesj=(select top 1 1 from  FGHIS5_ZY..病史_病史婴儿表 where HIS病案ID= @baID)  
	--IF  (@yesj>0)       
	--BEGIN        
		--delete FGHIS5_ZY..病史_病史婴儿表 where HIS病案ID=@baID    
	--end  
		  		    
	select @dj= 'insert into FGHIS5_ZY..病史_病史登记表( '+@strdjHis+' )'+ 'select '+@strdjHisCIS+' from mrd_clinical_regster where MRD_REGSTER_IDID='+@baID  
	select @dj=@dj+' update FGHIS5_ZY..病史_病史登记表 set 借阅标志=0,完整性标志=0 where 病案ID='+CONVERT(varchar,@baID)     
	exec (@dj)        
	select @zd='insert into FGHIS5_ZY..病史_病史诊断表( '+@strzdHis+' )'+'select '+@strzdHisCIS+ ' From mrd_clinical_diagnosis where MRD_REGSTER_ID='+@baID     
	exec (@zd)      
	select @ss='insert into FGHIS5_ZY..病史_病史手术表( '+@strssHis+' )'+'select '+@strssHisCIS+ ' From mrd_clinical_operation where MEDICAL_RECORD_ID='+@baID     
	exec (@ss)  
	--select @ye='insert into FGHIS5_ZY..病史_病史婴儿表( '+@strye+' )'+'select '+@stryeCIS+ ' From mrd_clinical_baby where MEDICAL_RECORD_ID='+@baID     
	--exec (@ye)  
      
       
	if @type='1'  --病案管理入库时执行      
	begin       
		set @djsj=(select 1 from  FGHIS5_ZY..统计_病史登记表 where 病案ID=CONVERT(varchar,@baID))  
		IF (@djsj>0)     
		BEGIN        
			select @qkdj= 'delete FGHIS5_ZY..统计_病史登记表 where 病案ID='+CONVERT(varchar,@baID)     
			exec (@qkdj)       
		end  
		set @zdsj= (select top 1 1 from  FGHIS5_ZY..病史_病史诊断表 where 病案ID=CONVERT(varchar,@baID))     
		IF (@zdsj>0)  
		BEGIN        
			select @qkzd= 'delete FGHIS5_ZY..统计_病史诊断表 where 病案ID='+CONVERT(varchar,@baID)     
			exec (@qkzd)         
		end   
		set @sssj=(select top 1 1 from  FGHIS5_ZY..统计_病史手术表 where 病案ID=CONVERT(varchar,@baID))  
		IF  (@sssj>0)       
		BEGIN        
			select @qkss= 'delete FGHIS5_ZY..统计_病史手术表 where 病案ID='+CONVERT(varchar,@baID)     
			exec (@qkss)         
		end  
		   
		select @dj= 'insert into FGHIS5_ZY..统计_病史登记表( '+@strdj+' )'+ 'select '+@strdj+' from 病史_病史登记表 where 病案ID='+CONVERT(varchar,@baID)
		exec (@dj)     
		select @zd='insert into FGHIS5_ZY..统计_病史诊断表( '+@strzd+' )'+'select '+@strzd+ ' From 病史_病史诊断表 where 病案ID='+CONVERT(varchar,@baID)  
		exec (@zd)  
		select @ss='insert into FGHIS5_ZY..统计_病史手术表( '+@strss+' )'+'select '+@strss+ ' From 病史_病史手术表 where 病案ID='+CONVERT(varchar,@baID) 
		exec (@ss)      
	end      
	      
     
	------ZHANGWEI:20170223修改，增加 新字段
	--IF @baID=0 RETURN      
	--declare @strdj varchar(3000)      
	--declare @strzd varchar(1000)      
	--declare @strss varchar(1000)      
	--declare @dj varchar(3000)      
	--declare @zd varchar(1000)      
	--declare @ss varchar(1000)    
	--declare @qkdj varchar(3000)      
	--declare @qkzd varchar(1000)      
	--declare @qkss varchar(1000)    
	--declare  @djsj int    
	--declare  @zdsj int   
	--declare  @sssj int   
	--set @strdj='病案ID, 住院ID, 附加ID, 条形码, 主病案号, 病案号, 住院号, 病案状态, 病案类型, 存放地址, 健康卡号,       
	-- 医疗付款方式, 住院次数, 门诊号, 记帐代码, 姓名, 性别, 出生日期, 年龄, 婚姻, 职业代码, 民族, 国籍,        
	-- 身份证号, 出生地址, 籍贯, 家庭地址, 家庭电话, 家庭邮编, 户口地址, 户口邮编, 单位名称, 单位电话,        
	-- 单位邮编, 联系姓名, 联系关系, 联系地址, 联系电话, 入院途径, 入院日期, 入院科室, 入院病区, 入院床号,       
	-- 转科情况, 出院日期, 出院科室, 所属病区, 出院床号, 住院天数, 入院确诊日期, 外地病人, 出院待查,        
	-- 门诊与出院, 入院与出院, 手术前后, 临床与病理, 放射与病理, 有无药物过敏, 药物过敏, HBsAg, HCVAb,        
	-- HIVAb, 抢救次数, 成功次数, 血型, Rh, 输血反应, 尸检, 妊娠梅毒筛查, 医源性手术, 医源性本院,        
	-- 是否产后出血, 产后出血量, 科主任ID, 主任医师ID, 主治医师ID, 住院医师ID, 责任护士ID, 进修医师ID,        
	-- 实习医师ID, 编码员ID, 质控医师ID, 质控护士ID, 质控日期, 病案质量, 死亡日期, 离院方式, 转院接收医院,        
	-- 转院接收卫生院, 再住院, 再住院目的, 入院前昏迷时间, 入院后昏迷时间, 治疗类别, 自制中药, 实施临床路径,        
	-- 使用医疗机构中药制剂, 使用中医诊疗设备, 使用中医诊疗技术, 辨证施护, 打印次数, 备注, 借阅标志, 完整性标志,        
	-- 借阅ID, 销毁号'      
	--set @strzd=' 病案ID, 序号, 诊断类型, 诊断编码, 诊断名称, 治疗结果, 统计码, 入院病情, 病理号'      
	--set @strss=' 病案ID, 序号, 手术编码, 手术名称, 手术日期, 主刀医师, 一助, 二助,       
	-- 麻醉, 切口等级, 愈合级别, 麻醉医师, 指导医师, 手术级别, 统计标志, 是否手术, 手术科室, 状态'      
	--if @type='0'       
	--begin    
	    
	--	  set @djsj=(select 1 from  病史_病史登记表 where 病案ID=CONVERT(varchar,@baID))  
	--	  IF (@djsj>0)     
	--	  BEGIN        
	--		 select @qkdj= 'delete 病史_病史登记表 where 病案ID='+CONVERT(varchar,@baID)     
	--		 exec (@qkdj)       
	--	  end  
		   
	--	  set @zdsj= (select top 1 1 from  病史_病史诊断表 where 病案ID=CONVERT(varchar,@baID))     
	--	  IF (@zdsj>0)  
	--	  BEGIN        
	--		 select @qkzd= 'delete 病史_病史诊断表 where 病案ID='+CONVERT(varchar,@baID)     
	--		 exec (@qkzd)         
	--	  end  
		    
	--	  set @sssj=(select top 1 1 from  病史_病史手术表 where 病案ID=CONVERT(varchar,@baID))  
	--	  IF  (@sssj>0)       
	--	  BEGIN        
	--		 select @qkss= 'delete 病史_病史手术表 where 病案ID='+CONVERT(varchar,@baID)     
	--		 exec (@qkss)         
	--	  end  
		    
		    
	--	 select @dj= 'insert into 病史_病史登记表( '+@strdj+' )'+ 'select '+@strdj+' from 临床_病史登记表 where 病案ID='+CONVERT(varchar,@baID)      
	--	 select @dj=@dj+' update 病史_病史登记表 set 借阅标志=0,完整性标志=0 where 病案ID='+CONVERT(varchar,@baID)     
	--	 exec (@dj)        
	--	 select @zd='insert into 病史_病史诊断表( '+@strzd+' )'+'select '+@strzd+ ' From 临床_病史诊断表 where 病案ID='+CONVERT(varchar,@baID)      
	--	 exec (@zd)      
	--	 select @ss='insert into 病史_病史手术表( '+@strss+' )'+'select '+@strss+ ' From 临床_病史手术表 where 病案ID='+CONVERT(varchar,@baID)      
		 
	--	 exec (@ss)      
	--  end      
	        
	--if @type='1'  --病案管理入库时执行      
	--begin      
		  
	--	  set @djsj=(select 1 from  统计_病史登记表 where 病案ID=CONVERT(varchar,@baID))  
	--	  IF (@djsj>0)     
	--	  BEGIN        
	--		 select @qkdj= 'delete 统计_病史登记表 where 病案ID='+CONVERT(varchar,@baID)     
	--		 exec (@qkdj)       
	--	  end  
		   
	--	  set @zdsj= (select top 1 1 from  病史_病史诊断表 where 病案ID=CONVERT(varchar,@baID))     
	--	  IF (@zdsj>0)  
	--	  BEGIN        
	--		 select @qkzd= 'delete 统计_病史诊断表 where 病案ID='+CONVERT(varchar,@baID)     
	--		 exec (@qkzd)         
	--	  end  
		    
	--	  set @sssj=(select top 1 1 from  统计_病史手术表 where 病案ID=CONVERT(varchar,@baID))  
	--	  IF  (@sssj>0)       
	--	  BEGIN        
	--		 select @qkss= 'delete 统计_病史手术表 where 病案ID='+CONVERT(varchar,@baID)     
	--		 exec (@qkss)         
	--	  end  
		   
	--	 select @dj= 'insert into 统计_病史登记表( '+@strdj+' )'+ 'select '+@strdj+' from 病史_病史登记表 where 病案ID='+CONVERT(varchar,@baID)      
	--	 exec (@dj)        
	--	 select @zd='insert into 统计_病史诊断表( '+@strzd+' )'+'select '+@strzd+ ' From 病史_病史诊断表 where 病案ID='+CONVERT(varchar,@baID)      
	--	 exec (@zd)      
	--	 select @ss='insert into 统计_病史手术表( '+@strss+' )'+'select '+@strss+ ' From 病史_病史手术表 where 病案ID='+CONVERT(varchar,@baID)      
	--	 exec (@ss)      
	--end      

go

