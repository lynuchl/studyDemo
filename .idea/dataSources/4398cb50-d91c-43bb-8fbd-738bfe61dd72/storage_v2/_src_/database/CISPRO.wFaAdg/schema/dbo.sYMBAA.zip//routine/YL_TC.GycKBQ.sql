CREATE   proc [dbo].[YL_TC](@RQ char(8)='')  --FG_WD_TB_CIS_LH_Summary_30 '20230316'        
as   

declare @start_date date ,@end_date date
if LEN(@RQ)<1
	BEGIN
		SELECT @start_date=CONVERT(VARCHAR(10),GETDATE(),120),@end_date=CONVERT(VARCHAR(10),GETDATE()+1,120)
	END
ELSE
    BEGIN
	    SELECT @start_date=CAST(@RQ AS date),@end_date=DATEADD(DAY,1, CAST(@RQ AS date))
	END

--------查询病历格式信息
--select * from CISEMR.dbo.REC_DICT t where t.REC_NAME like '%小结%'

-------查询病历对应的文书信息
--select a.REC_ID,a.REC_NAME,b.DOC_ID,b.DOC_NAME from cisemr.dbo.REC_DICT a
--inner join cisemr.dbo.REC_DOCUMENT_INFO b on a.REC_ID=b.REC_ID
--where a.REC_NAME like '%小结%'

------查询病历文书所对应的数据元
--select a.rec_id,a.DOC_NAME,a.DOC_ID,a.STATUS,a.CREATE_TIME,a.inpat_no,b.ele_id,b.name,c.ele_name,b.ele_value from cisemr.dbo.rec_document_info a
--left join cisemr.dbo.rec_doc_element_value b on a.doc_id=b.doc_id
--left join cisemr.dbo.rec_data_element c on b.ele_id=c.ele_id
--where a.REC_ID='1625683607458680834' and a.STATUS=0 and a.INPAT_NO='0386056';

CREATE TABLE #TB_CIS_LH_Summary(
    REC_ID numeric(20,0),DOC_ID numeric(20,0),JYH [varchar](32) NULL,
	[JZLSH] [varchar](64) NOT NULL,
	ADDITIONAL_ID INT, 
	[YLJGDM] [varchar](11) NOT NULL,
	[BQ] [varchar](15) NULL,
	[CH] [varchar](16)  NULL,
	[RYZZTZ] [varchar](4000) ,
	[JCHZ] [varchar](2048),
	[TSJC] [varchar](1024),
	[ZLGC] [varchar](4000),
	[HBZ] [varchar](1024),
	[CYSQK] [varchar](1024),
	[CYYZ] [varchar](1024),
	[ZLJGMS] [varchar](1024),
	[ZZYS_DM] [varchar](16),
	[ZZYSXM] [varchar](32),
	[ZYYS_DM] [varchar](16),
	[ZYYSXM] [varchar](32),
	[YYZTBBT1] [varchar](32) NULL,
	[YYZTB1] [varchar](512) NULL,
	[YYZTBBT2] [varchar](32) NULL,
	[YYZTB2] [varchar](512) NULL
	)

--------查询当前出院小结文书记录 床号、出院情况、卡号、卡类型
insert into #TB_CIS_LH_Summary(	REC_ID, DOC_ID,JYH ,[JZLSH],ADDITIONAL_ID ,[YLJGDM],[CH])
select B.REC_ID,B.DOC_ID,A.INP_ID,a.IN_HOSPITAL_ID JZLSH,ISNULL(A.ADDITIONAL_ID,0),'42506408500' YLJGDM
,a.BED_NO
 
from ciscomm.dbo.CIS_HOSTPITAL_INFO a
inner join cisemr.dbo.REC_DOCUMENT_INFO b on a.INP_ID=b.INPAT_NO and b.REC_ID='1625683607458680834'
left join cisemr.dbo.rec_doc_element_value c on b.doc_id=c.doc_id
left join cisemr.dbo.rec_data_element d on c.ele_id=d.ele_id
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date and b.STATUS=0
group by B.REC_ID,B.DOC_ID,a.INP_ID,a.BED_NO,IN_HOSPITAL_ID
,a.ADDITIONAL_ID
 

-----------入院时主要症状及体征
UPDATE A SET a.RYZZTZ=c.ELE_VALUE
--select b.INPAT_NO,c.ELE_VALUE RYZZTZ 
from #TB_CIS_LH_Summary a
inner join CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1000921
print '入院时主要症状及体征'

-----------实验室检查及主要会诊
UPDATE A SET a.JCHZ=C.ELE_VALUE
--select b.INPAT_NO,c.ELE_VALUE JCHZ 
from #TB_CIS_LH_Summary a
inner join CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1627586710973976577
print '实验室检查及主要会诊'

-----------诊疗过程
--select b.INPAT_NO,c.ELE_VALUE ZLGC 
UPDATE A SET a.ZLGC=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join  CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1627963613912240130
print '诊疗过程'

-----------合并症
--select b.INPAT_NO,c.ELE_VALUE HBZ 
UPDATE A SET a.HBZ=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join  CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1001237
print '合并症'

-----------出院时情况

--select b.INPAT_NO,c.ELE_VALUE CYSQK 
UPDATE A SET a.CYSQK=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join  CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1001119
print '出院时情况'

-----------出院医嘱
--select b.INPAT_NO,c.ELE_VALUE CYYZ 
UPDATE A SET a.CYYZ=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1001120
print '出院医嘱'

-----------治疗结果描述
--select b.INPAT_NO,c.ELE_VALUE ZLJGMS 
UPDATE A SET a.ZLJGMS=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join  CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1001121	
print '治疗结果描述'

-----------主治医师工号、主治医师姓名、主治医生身份证号
--select b.INPAT_NO,f.OPERATE_NO ZZYSGH,c.ELE_VALUE ZZYSXM ,h.ID_NUMBER ZZYSSFZ
UPDATE A SET a.ZZYS_DM=f.ID ,a.ZZYSXM=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join  CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
left join CISCOMM.dbo.AUTH_OPERATOR f on cast(c.ELE_VALUE as varchar)=f.OPERATE_NAME
left join CISCOMM.dbo.AUTH_OPERATOR_INFO h on f.ID=h.ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1001158	
print '主治医师工号、主治医师姓名、主治医生身份证号'

-----------住院医师工号、住院医师姓名、住院医生身份证号
--select b.INPAT_NO,f.OPERATE_NO ZYYSGH,c.ELE_VALUE ZYYSXM ,h.ID_NUMBER ZYYSSFZ
UPDATE A SET a.ZYYS_DM=f.ID ,a.ZYYSXM=C.ELE_VALUE
from #TB_CIS_LH_Summary a
inner join  CISEMR.dbo.REC_DOCUMENT_INFO b on A.REC_ID=B.REC_ID AND A.DOC_ID=B.DOC_ID AND A.JYH=B.INPAT_NO
inner join CISEMR.dbo.rec_doc_element_value c on b.REC_ID=c.REC_ID and b.DOC_ID=c.DOC_ID
left join CISCOMM.dbo.AUTH_OPERATOR f on cast(c.ELE_VALUE as varchar)=f.OPERATE_NAME
left join CISCOMM.dbo.AUTH_OPERATOR_INFO h on f.ID=h.ID
where b.CREATE_TIME>@start_date and b.CREATE_TIME<@end_date  and b.STATUS=0 and c.ELE_ID=1627602026575695874	
print '住院医师工号、住院医师姓名、住院医生身份证号'


-- [dbo].[FG_WD_TB_CIS_LH_Summary_30]
insert into TC
select  JYH
      ,[YLJGDM] JGDM
      ,[BQ] BQ
      ,CH
      ,isnull(RYZZTZ,'-') [RYZZTZ]
      ,isnull(JCHZ,'-') [JCHZ]
      ,isnull(TSJC,'-') [TSJC]
      ,isnull(ZLGC,'-') [ZLGC]
      ,isnull(HBZ,'-') [HBZ]
      ,isnull(CYSQK,'-') [CYQK]
      ,isnull(CYYZ,'-') [CYYZ]
      ,isnull(ZLJGMS,'-') ZLJG
      ,isnull(ZZYS_DM,'-') [ZZYS_DM]
      ,isnull(ZZYSXM,'-') [ZZYSXM]
      ,isnull(ZYYS_DM,'-') [ZYYSGH]
      ,isnull(ZYYSXM,'-') [ZYYSXM]
      ,[YYZTBBT1]
      ,[YYZTB1]
      ,[YYZTBBT2]
      ,[YYZTB2]
	  ,convert(varchar(8),b.结算时间,112) BatchId
	  ,GETDATE() InTime
	  ,0 IsUp
	  ,GETDATE() CheckTime
	  ,0 CheckFlag
	  ,'' CheckMsg
	  ,GETDATE() UpTime
	  ,0 UpFlag
	  ,'' UpData
	  ,'' UpReturnData
	  from #TB_CIS_LH_Summary A
	  INNER JOIN fghis5_zy.dbo.住院_结算发票表 b on a.JYH=b.住院号 and a.ADDITIONAL_ID<>1
	  where B.结算时间>=@start_date and b.结算时间<@end_date

	   drop table #TB_CIS_LH_Summary

go

