CREATE   PROCEDURE [dbo].[ZY_YS_GETYPINFOR](@bqid			int,
											@deptId         int,
											@uid            int,
											@itemClass      int,
											@advAttr        varchar(1),--医嘱属性：0-长期 1-临时 2-出院带药 3-中草药
											@DRUG_CODE_LIST varchar(1000)) AS
-- CIS住院药品查询                

SELECT *
  INTO #herb_medicine_temp
  FROM (SELECT DISTINCT A.药品类别 AS itemClass,
                        A.类别名称 AS className,
                        A.报销类型 AS rmbFlag,
                        R.REIMBURSE_NAME AS rmbName,
                        A.药品ID AS itemCode,
                        A.药品名称 AS itemName,
                        A.药品规格 AS spec,
                        A.基本剂量 AS basicDosage,
                        A.剂量单位 AS basicDosageUnit,
                        A.包装量 AS wholeQuantity,
                        A.包装量 AS packingQuantity,
                        A.包装单位 AS packingUnit,
                        A.常规包装量 AS convPackingQuantity,
                        A.常规包装单位 AS convPackingUnit,
                        A.药典规格 AS convPackingSpec,
                        A.零售价 AS price,
                        '【高警示】' AS drugShow,
                        A.库存量 AS stockQuantity,
                        A.部门ID AS deptId,
                        (SELECT DEPT_NAME
                           FROM CISCOMM .. AUTH_DEPT
                          WHERE ID = A.部门ID) AS deptName,
                        I.REMARK AS indicationRemarks,
                        A.药品产地 AS productPlace,
                        A.输入码1 AS inputCode,
                        I.IS_INDICATION indicationFlag,
                        A.精麻毒药 AS fineHempPoisonFlag,
                        '' AS highPriceDrugFlag,
                        CASE
                          WHEN a.药品ID IN (SELECT aa.药品ID
                                            FROM FGKJYW.dbo.抗菌_药品通用名对应表 tt
                                           inner join fghis5_yp.dbo.代码_药品基本信息表 aa
                                              on tt.HIS_药品代码 = aa.药品条码
                                           WHERE tt.状态 = '1') THEN
                           '1'
                          ELSE
                           ''
                        END AS antibioticsFlag,
                        CASE
                          WHEN A.上柜状态 = '统一上' THEN
                           '1'
                          ELSE
                           '0'
                        END AS upLowCabFlag
          FROM 药品_基本信息门诊视图 A
          LEFT JOIN CISCOMM .. CODE_REIMBURSE_INFO R
            ON R.REIMBURSE_CODE = A.报销类型
           AND R.STATE = 1
		  LEFT JOIN CISPRO..V_DOC_DRUG_INDIC_INFO I
			ON I.DRUG_CODE = A.药品ID
     --    INNER JOIN CISCOMM .. AUTH_WARD_VS_PHARMACY B
     --       ON A.部门ID = B.PHARMACY_ID
		   --AND B.STATUS = '1'
         WHERE (@itemClass is null or @itemClass = 3)
		   AND A.部门ID = 30
           AND A.上柜状态 = '统一上'
		   AND A.药品状态='1'
        
        UNION ALL
        
        SELECT DISTINCT A.药品类别 AS itemClass,
                        A.类别名称 AS className,
                        A.报销类型 AS rmbFlag,
                        R.REIMBURSE_NAME AS rmbName,
                        A.药品ID AS itemCode,
                        A.药品名称 AS itemName,
                        A.药品规格 AS spec,
                        A.基本剂量 AS basicDosage,
                        A.剂量单位 AS basicDosageUnit,
                        A.包装量 AS wholeQuantity,
                        A.包装量 AS packingQuantity,
                        A.包装单位 AS packingUnit,
                        A.常规包装量 AS convPackingQuantity,
                        A.常规包装单位 AS convPackingUnit,
                        A.药典规格 AS convPackingSpec,
                        A.零售价 AS price,
                        '【高警示】' AS drugShow,
                        A.库存量 AS stockQuantity,
                        null AS deptId,
                        '' AS deptName,
                        I.REMARK AS indicationRemarks,
                        A.药品产地 AS productPlace,
                        D.输入码2 AS inputCode,
                        I.IS_INDICATION indicationFlag,
                        A.精麻毒药 AS fineHempPoisonFlag,
                        '' AS highPriceDrugFlag,
                        CASE
                          WHEN a.药品ID IN (SELECT aa.药品ID
                                            FROM FGKJYW.dbo.抗菌_药品通用名对应表 tt
                                           inner join fghis5_yp.dbo.代码_药品基本信息表 aa
                                              on tt.HIS_药品代码 = aa.药品条码
                                           WHERE tt.状态 = '1') THEN
                           '1'
                          ELSE
                           ''
                        END AS antibioticsFlag,
                        CASE
                          WHEN A.上柜状态 = '统一上' THEN
                           '1'
                          ELSE
                           '0'
                        END AS upLowCabFlag
          FROM 药品_基本信息门诊视图 A
          LEFT JOIN CISCOMM .. CODE_REIMBURSE_INFO R
            ON R.REIMBURSE_CODE = A.报销类型
           AND R.STATE = 1
		  LEFT JOIN CISPRO..V_DOC_DRUG_INDIC_INFO I
			ON I.DRUG_CODE = A.药品ID
		  INNER JOIN FGHIS5_YP.[dbo].[代码_药品别名信息表] D
			ON D.药品ID = A.药品ID
     --    INNER JOIN CISCOMM .. AUTH_WARD_VS_PHARMACY B
     --       ON A.部门ID = B.PHARMACY_ID
		   --AND B.STATUS = '1'
         WHERE (@itemClass is null or @itemClass = 3)
		   AND A.部门ID = 30
           AND A.上柜状态 = '统一上'
		   AND A.药品状态='1') C

SELECT *
  INTO #temp
  FROM (SELECT DISTINCT A.药品类别 AS itemClass,
                        A.类别名称 AS className,
                        A.报销类型 AS rmbFlag,
                        R.REIMBURSE_NAME AS rmbName,
                        A.药品ID AS itemCode,
                        A.药品名称 AS itemName,
                        A.药品规格 AS spec,
                        A.基本剂量 AS basicDosage,
                        A.剂量单位 AS basicDosageUnit,
                        A.包装量 AS wholeQuantity,
                        A.包装量 AS packingQuantity,
                        A.包装单位 AS packingUnit,
                        A.常规包装量 AS convPackingQuantity,
                        A.常规包装单位 AS convPackingUnit,
                        A.药典规格 AS convPackingSpec,
                        A.零售价 AS price,
                        '【高警示】' AS drugShow,
                        A.库存量 AS stockQuantity,
                        A.部门ID AS deptId,
                        (SELECT DEPT_NAME
                           FROM CISCOMM .. AUTH_DEPT
                          WHERE ID = A.部门ID) AS deptName,
                       I.REMARK AS indicationRemarks,
                        A.药品产地 AS productPlace,
                        A.输入码1 AS inputCode,
                       I.IS_INDICATION indicationFlag,
                        A.精麻毒药 AS fineHempPoisonFlag,
                        '' AS highPriceDrugFlag,
                        CASE
                          WHEN a.药品ID IN (SELECT aa.药品ID
                                            FROM FGKJYW.dbo.抗菌_药品通用名对应表 tt
                                           inner join fghis5_yp.dbo.代码_药品基本信息表 aa
                                              on tt.HIS_药品代码 = aa.药品条码
                                           WHERE tt.状态 = '1') THEN
                           '1'
                          ELSE
                           ''
                        END AS antibioticsFlag,
                        CASE
                          WHEN A.上柜状态 = '统一上' THEN
                           '1'
                          ELSE
                           '0'
                        END AS upLowCabFlag
          FROM 药品_基本信息住院视图 A
          LEFT JOIN CISCOMM .. CODE_REIMBURSE_INFO R
            ON R.REIMBURSE_CODE = A.报销类型
           AND R.STATE = 1
		  LEFT JOIN CISPRO..V_DOC_DRUG_INDIC_INFO I
			ON I.DRUG_CODE = A.药品ID
     --    INNER JOIN CISCOMM .. AUTH_WARD_VS_PHARMACY B
     --       ON A.部门ID = B.PHARMACY_ID
		   --AND B.STATUS = '1'
         WHERE (@itemClass is null or @itemClass != 3)
		   AND A.部门ID = 28
           AND A.上柜状态 = '统一上'
		   AND A.药品状态='1'
        
        UNION ALL
        
        SELECT DISTINCT A.药品类别 AS itemClass,
                        A.类别名称 AS className,
                        A.报销类型 AS rmbFlag,
                        R.REIMBURSE_NAME AS rmbName,
                        A.药品ID AS itemCode,
                        A.药品名称 AS itemName,
                        A.药品规格 AS spec,
                        A.基本剂量 AS basicDosage,
                        A.剂量单位 AS basicDosageUnit,
                        A.包装量 AS wholeQuantity,
                        A.包装量 AS packingQuantity,
                        A.包装单位 AS packingUnit,
                        A.常规包装量 AS convPackingQuantity,
                        A.常规包装单位 AS convPackingUnit,
                        A.药典规格 AS convPackingSpec,
                        A.零售价 AS price,
                        '【高警示】' AS drugShow,
                        A.库存量 AS stockQuantity,
                        null AS deptId,
                        '' AS deptName,
                        I.REMARK AS indicationRemarks,
                        A.药品产地 AS productPlace,
                        D.输入码2 AS inputCode,
                        I.IS_INDICATION indicationFlag,
                        A.精麻毒药 AS fineHempPoisonFlag,
                        '' AS highPriceDrugFlag,
                        CASE
                          WHEN a.药品ID IN (SELECT aa.药品ID
                                            FROM FGKJYW.dbo.抗菌_药品通用名对应表 tt
                                           inner join fghis5_yp.dbo.代码_药品基本信息表 aa
                                              on tt.HIS_药品代码 = aa.药品条码
                                           WHERE tt.状态 = '1') THEN
                           '1'
                          ELSE
                           ''
                        END AS antibioticsFlag,
                        CASE
                          WHEN A.上柜状态 = '统一上' THEN
                           '1'
                          ELSE
                           '0'
                        END AS upLowCabFlag
          FROM 药品_基本信息住院视图 A
          LEFT JOIN CISCOMM .. CODE_REIMBURSE_INFO R
            ON R.REIMBURSE_CODE = A.报销类型
           AND R.STATE = 1
		  LEFT JOIN CISPRO..V_DOC_DRUG_INDIC_INFO I
			ON I.DRUG_CODE = A.药品ID
		  INNER JOIN FGHIS5_YP.[dbo].[代码_药品别名信息表] D
			ON D.药品ID = A.药品ID
     --    INNER JOIN CISCOMM .. AUTH_WARD_VS_PHARMACY B
     --       ON A.部门ID = B.PHARMACY_ID
		   --AND B.STATUS = '1'
         WHERE (@itemClass is null or @itemClass != 3)
		   AND A.部门ID = 28
           AND A.上柜状态 = '统一上'
		   AND A.药品状态='1') C


BEGIN

	  -----控制只能某些医生开某些药
	 IF((SELECT OPERATE_NO FROM CISCOMM..AUTH_OPERATOR WHERE ID=@UID) not in('5001','5002','5003','5004','5005','5006','5007','5008','5009','5010','5011',
		'5012','5013','5014','5015','5016','5017','5018','5019','5020','5021','5022',
		'5023','5024','5026','1003','5030','5033','5035','5036','5037','5038','5039','5040','5041','5042','0298','0057','0298','0359','0034','0377'))  -----需要添加权限的医生,逗号隔开
	 BEGIN

		DELETE FROM #temp WHERE itemCode in('000000842','080101001','000001235','000001364','140101003','108125','070201001',
		 '211201001','000001040','200519010','108158','108267','108365','108366',
		 '108368','108375','108364','108371','108376','108377','108383','108384','108389',
		 '108390','108398','108399','108363','108382','108397','108422','108391','108393',
		 '108408','108409','108410','108411','108404','108423','108424','108421','000000981','000000064',
		 '000000980','000001578','000000057','000000604','108369','108374','108378','108381','108361','108386','108388','108402',
		 '108387','108437','108439','108445','108401','108448','108403','108438','108447','108460','110119005','500401001')  
		 -----需要添加权限的药物代码也叫药品条码,逗号隔开

	 END;

    IF @DRUG_CODE_LIST IS NOT NULL AND LEN(@DRUG_CODE_LIST) > 0 BEGIN
         SELECT * FROM #temp T WHERE T.itemCode IN (select * from F_STRSPLIT(@DRUG_CODE_LIST))
		 UNION ALL 
		 SELECT * FROM #herb_medicine_temp T WHERE T.itemCode IN (select * from F_STRSPLIT(@DRUG_CODE_LIST));
	END;
    ELSE IF @itemClass IS NOT NULL BEGIN
		IF @itemClass = 3 BEGIN --草药查草药房
			SELECT * FROM #herb_medicine_temp T;
		END;
		ELSE
			SELECT * FROM #temp T WHERE T.itemClass = @itemClass;
	END;
	ELSE
         SELECT * FROM #temp T;
  END;
go

