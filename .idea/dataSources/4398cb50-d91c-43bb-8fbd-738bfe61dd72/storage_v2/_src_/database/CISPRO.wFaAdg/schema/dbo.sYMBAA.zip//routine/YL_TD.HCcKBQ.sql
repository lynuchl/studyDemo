CREATE   proc [dbo].[YL_TD](@RQ char(8)='')  --FG_WD_TB_CIS_LH_Summary_30 '20230316'        
as   

declare @start_date date ,@end_date date
if LEN(@RQ)<1
	BEGIN
		SELECT @start_date=CONVERT(VARCHAR(10),GETDATE()-1,120),@end_date=CONVERT(VARCHAR(10),GETDATE(),120)
	END
ELSE
    BEGIN
	    SELECT @start_date=DATEADD(DAY,-1, CAST(@RQ AS date)),@end_date=CAST(@RQ AS date)
	END

INSERT INTO  TD( JGDM, YZID, JYH, LSH, CXBZ, BQ, XDKSBM, XDRGH, XDRXM, YZXDSJ, ZXKSBM, ZXRGH, ZXRXM, YZZXSJ, YZZZSJ, YZSM, YZZH, YZLB, YZBMYB, YZMXMC, YZLX, YPGG, BZGGDW, BZGGXS, YPYF, YYPDDM, YYPD, JL, DW, MCSL, MCDW, YF, YYTS, SFPS, YPSL, YPDW, BZ, BatchId, InTime, IsUp, CheckTime, CheckFlag, CheckMsg, UpTime, UpFlag, UpData, UpReturnData)

SELECT 
'42506408500' 医保医疗机构代码,
b.ADVICE_ID YZID,
a.住院号 JYH,
isnull((select top 1 d.中心流水号 from fghis5_yb..上海_医保住院收费表 d where d.结算ID=a.结算ID and d.记帐标志=1 ),'0000000000000000') 中心交易流水号,--LSH	
'1' 撤销标志,--CXBZ
h.WARD_ID,--BQ
AA.统计名称 下达科室编码,--XDKSBM
--b.开方医生 医嘱下达人医保医师代码,--XDRGH	
isnull((select top  1 执业医师医保标识码  from   fghis5_yb..医保_医生信息表 where  医生姓名=(SELECT top 1 人员姓名 FROM fghis5..系统_工作人员表 WHERE 人员工号=h.ADV_DOC_NO)),h.ADV_DOC_NO) 医嘱下达人医保医师代码,

(SELECT top 1 人员姓名 FROM fghis5..系统_工作人员表 WHERE 人员工号=h.ADV_DOC_NO) 医嘱下达人医保医师姓名,--XDRXM　
--CONVERT(VARCHAR(32),录入时间,120) 录入时间,--YZXDSJ
h.ADV_SUBMIT_DATE 录入时间,----医嘱下达时间 YZXDSJ 字符 18 必填 格式：yyyy-MM-dd HH:mm:ss

'' 执行科室编码,--ZXKSBM
h.EXECUTE_NO 医嘱执行人工号,--ZXRGH
(SELECT top 1 人员姓名 FROM fghis5..系统_工作人员表 WHERE 人员工号=h.CONFIRM_NO) 医嘱执行人姓名,---ZXRXM	　
CONVERT(VARCHAR(32),EXECUTE_DATE,120) 医嘱执行时间,--YZZXSJ
h.CONFIRM_STOP_DATE 医嘱终止时间,--YZZZSJ
'' 医嘱说明,--YZSM
'' 医嘱组号 ,--YZZH	　
CASE WHEN b.ADVICE_ATTR='1' THEN '2' WHEN b.ADVICE_ATTR='0' THEN '1' WHEN b.ADVICE_ATTR='2' THEN '3'  ELSE '9' END 医嘱类别 ,--YZLB	
isnull(D.YB60,'ZZZZZZZZZZZZZZZ')  医嘱明细医保编码,---YZBMYB

b.ADVICE_NAME ,--YZMXMC	　
CASE WHEN b.ADVICE_CLASS IN ('1','2','3') THEN '1' ELSE  '0' END 是否药品,--YZLX
case when isnull(SUBSTRING(d.药品规格,1,16),'')='' then '-' 
else SUBSTRING(d.药品规格,1,16) end 药品包装规格,--YPGG
case when isnull(d.规格单位,'')='' then '-' else d.规格单位 end 药品包装规格单位,--BZGGDW
case when isnull(d.转换因子,'')='' then 1 else d.转换因子 end 药品包装规格系数,--BZGGXS
USAGE,--YPYF	
--b.频次,--YYPDDM	
case when b.FREQ='QD' then 'QD' when b.FREQ='BID' then 'BID' when b.FREQ='TID' then 'TID' when b.FREQ='QID' then 'QID' when b.FREQ='QW' then 'QW' when b.FREQ='BIW' then 'BIW' when b.FREQ='TIW' then 'TIW' when b.FREQ='Q1H' then 'Q1H' when b.FREQ='Q2H' then 'Q2H' when b.FREQ='Q3H' then 'Q3H' when b.FREQ='Q4H' then 'Q4H' when b.FREQ='Q5H' then 'Q5H' when b.FREQ='Q6H' then 'Q6H' when b.FREQ='Q8H' then 'Q8H' when b.FREQ='Q12H' then 'Q12H' when b.FREQ='QN' then 'QN' when b.FREQ='ST' then 'ST' when b.FREQ='Q0D' then 'Q0D' when b.FREQ='Q5D' then 'Q5D' when b.FREQ='Q10D' then 'Q10D' when b.FREQ='C12H' then 'C12H' when b.FREQ='C24H' then 'C24H' when b.FREQ='PRN' then 'PRN' when b.FREQ='AC' then 'AC' when b.FREQ='AM' then 'AM' ELSE '' end,

'' 用药频度,--YYPD
b.ONE_DOSAGE,--JL	　
b.BASIC_DOSAGE_UNIT,--DW	　
'' 每次使用数量,--MCSL	　
'' 每次使用数量单位,--MCDW	　
b.USAGE 给药途径,--YF　
'' 用药天数,--YYTS
'' 皮试判别,--SFPS
''发药数量,--YPSL
''发药数量单位,--YPDW
a.发票编号 备注,--BZ
convert(varchar(8),a.结算时间,112) BatchId,
GETDATE() InTime,0 IsUp,GETDATE() CheckTime,
0 CheckFlag,'' CheckMsg,GETDATE() UpTime,0 UpFlag,'' UpData,'' UpReturnData
 FROM fghis5_zy.dbo.住院_结算发票表 a ,fghis5_zy.dbo.住院_住院登记表 c ,cisdoct.dbo.DOC_ADVICE_EXTEND h,cisdoct.dbo.DOC_ADVICE b 
 left join fghis5.dbo.基本_收费项目药品字典表 d  on  b.ADVICE_CODE=d.项目代码,
 (select distinct a.科室ID,b.Code 统计名称,b.Name from fghis5.dbo.代码_科室信息表 a,fghis5.dbo.Com_KB b where a.统计名称=b.Code) AA
 
 WHERE a.住院号=b.INPAT_NO
 and b.advice_id=h.ADVICE_ID
 and a.住院号=c.住院号
 AND a.附加ID=c.附加ID
 AND a.结算时间>=@start_date and a.结算时间<@end_date
 AND a.发票状态='2'
 AND c.所属科室=AA.科室ID
 and a.附加ID<>'1'
 and a.结算工号<>'0000'

go

