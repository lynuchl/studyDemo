-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-申请检验组合表(APPLY_EXAMINE_COMPOSE)
-- Description:	 通过作业定时去同步his中新增或者修改的申请检验组合表
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_EXAMINE_COMPOSE]
	 
AS
BEGIN  
     if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP'))
		   BEGIN
				DROP TABLE #TEMP_COMPOSE;
		   END

     select t.组合id compose_id, 
			t.组合代码 compose_code, 
			t.组合名称 compose_name, 
			null old_his_code, 
			null remarks, 
			-1 create_id, 
			GETDATE() create_date, 
			null update_id, 
			null update_date, 
			'71' dept_id,   ----需要取对应的检验科室
			0 support_radio, 
			null  category_id,  ------需要通过组合代码前几位拆解找到对应类别id
			null english_name, 
			t.显示序号 seq, 
			'10001' org_id
			into #TEMP_COMPOSE 
			from  fghis5_mz.dbo.代码_申请检验组合表 t 
			where not exists(select * from ciseapp..APPLY_EXAMINE_COMPOSE a where a.COMPOSE_ID=t.组合id)

      
         
		 -----由于HIS组合代码中没有与类别代码对应关系，只能手动处理更新其对应的 category_id
		 update #temp set category_id=92 where SUBSTRING(compose_code,1,2)='LX'
		 update #temp set category_id=91 where SUBSTRING(compose_code,1,2)='LJ'
		 update #temp set category_id=94 where SUBSTRING(compose_code,1,2)='LH'
		 update #temp set category_id=95 where SUBSTRING(compose_code,1,2)='MY'
		 update #temp set category_id=93 where SUBSTRING(compose_code,1,3)='WSW'
		 update #temp set category_id=96 where SUBSTRING(compose_code,1,2)='WS' AND category_id IS NULL
		 update #temp set category_id=91 where SUBSTRING(compose_code,1,2)='ZH' AND category_id IS NULL

		 insert into ciseapp..APPLY_EXAMINE_COMPOSE 
		 select * from #TEMP_COMPOSE ;

	     DROP TABLE #TEMP_COMPOSE;
END


go

