





CREATE  VIEW [dbo].[V_CODE_CHARGE_ITEM] AS

select t.项目id item_id,
       t.项目类别 item_class,
       a.类别名称 class_name,
       t.项目代码 item_code,
       t.项目名称 item_name,
       t.输入码1 input_code,
       t.规格 spec,
       t.单位 unit,
       t.成本价 cost_price,
       t.单价 price,
       t.医嘱属性 adv_attr,
       t.医嘱标志 adv_flag,
       t.状态  status,
       t.报销标志 rmb_flag,
       t.门诊住院标志 outp_flag,
       t.启用时间 start_date,
       t.停用时间 stop_date,
       '' remark,
      t.默认执行科室 def_dept_id,
       null serial_no,
       null org_id,
       1 create_id,
       t.更新时间 create_date,
       null update_id,
       t.更新时间 update_date,
       t.对应病案大类 dybadl,
       t.对应病案小类 dybaxl,
	   国家码 NATION_SUBJECT_CODE
  from FGHIS5.DBO.代码_收费项目表  t
 left join FGHIS5.DBO.代码_项目基本类别表  a on t.项目类别=a.项目类别 
 where t.状态=1;
go

