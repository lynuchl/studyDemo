-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-申请医技小类字典表(APPLY_MED_SUB_CATEGORY)
-- Description:	 由于HIS无医技小类，只能获取医技项目中部位信息，当做小类信息，获取CIS中APPLY_MED_POSITION医技部位信息
--   ，部位信息是获取his信息
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_MED_SUB_CATEGORY]
	 
AS
BEGIN
		
      merge ciseapp..APPLY_MED_SUB_CATEGORY as A
	  using(
	  select t.POSITION_ID subclass_id, 
			t.POSITION_ID subclass_code, 
			t.POSITION_NAME subclass_name, 
			create_id, 
			create_date, 
			update_id, 
			update_date, 
			org_id, 
			[state], 
			seq from CISEAPP..APPLY_MED_POSITION t where t.TYPE=0
			)B ON A.subclass_id=B.subclass_id
			when not matched then 
			INSERT (SUBCLASS_ID
					,SUBCLASS_CODE
					,SUBCLASS_NAME
					,CREATE_ID
					,CREATE_DATE
					,UPDATE_ID
					,UPDATE_DATE
					,ORG_ID
					,ENABLED
					,SEQ) 
		values(b.SUBCLASS_ID
			,b.SUBCLASS_CODE
			,b.SUBCLASS_NAME
			,b.CREATE_ID
			,b.CREATE_DATE
			,b.UPDATE_ID
			,b.UPDATE_DATE
			,b.ORG_ID
			,b.[state]
			,b.SEQ )	;

END
go

