
CREATE  PROCEDURE [dbo].[ZY_COST_BATCH_UPDATE](@ids  varchar(500)) AS

BEGIN

    update t set
		t.STATUS = t1.STATUS
  from [DBLINK_HISPRODEV]..[HISPRO].[NUR_COST] t
  inner join cisnurs..nur_cost t1 on t.id = t1.id
  where t1.id in (select * from F_STRSPLIT(@ids))

END;
go

