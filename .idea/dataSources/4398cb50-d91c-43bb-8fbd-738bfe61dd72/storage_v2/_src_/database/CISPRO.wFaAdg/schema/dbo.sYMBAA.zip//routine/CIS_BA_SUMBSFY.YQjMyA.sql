-- **********************************************************************************----    
--1)功能描述：病案费用
-- ********************************************************************************----

CREATE   PROCEDURE [dbo].[CIS_BA_SUMBSFY](@V_BAID INT,@V_ZYID INT)
AS

--ZYH VARCHAR2(20);
--V_CNT INTEGER:=0;
--V_FYMX INTEGER:=0;
--ZYFY INTEGER:=0;
declare @总费用1  numeric(12,2);
declare @自付金额1  numeric(12,2);
declare @自费金额1 numeric(12,2);
declare @其它支付1 numeric(12,2);
--综合医疗服务类
declare @一般医疗服务费1 numeric(12,2);
declare @中医辩证论治费1 numeric(12,2);
declare @中医辩证论治会诊费1 numeric(12,2);
declare @一般治疗操作费1 numeric(12,2);
declare @护理费1 numeric(12,2);
declare @其他费用1 numeric(12,2);
--诊断类
declare @病理诊断费1 numeric(12,2);
declare @实验室诊断费1 numeric(12,2);
declare @影像学诊断费1 numeric(12,2);
declare @临床诊断项目费1 numeric(12,2);
--治疗类
declare @非手术治疗项目费1 numeric(12,2);
declare @临床物理治疗费1 numeric(12,2);
declare @手术治疗费1 numeric(12,2);
declare @麻醉费1 numeric(12,2);
declare @手术费1 numeric(12,2);
--康复类
declare @康复费1 numeric(12,2);
--中医类
declare @中医诊断1 numeric(12,2);
declare @中医治疗费1 numeric(12,2);
declare @中医外治1  numeric(12,2);
declare @中医骨伤1 numeric(12,2);
declare @针刺与灸法1 numeric(12,2);
declare @中医推拿治疗1 numeric(12,2);
declare @中医肛肠治疗1 numeric(12,2);
declare @中医特殊治疗1 numeric(12,2);
declare @中医其他1 numeric(12,2);
declare @中医特殊调配加工1 numeric(12,2);
declare @辩证施膳1 numeric(12,2);
  --西药类
declare @西药费1 numeric(12,2);
declare @抗菌药物费用1 numeric(12,2);
  --中药类
declare @中成药费1 numeric(12,2);
declare @医疗结构中药制剂费1 numeric(12,2);
declare @中草药费1 numeric(12,2);
--血液和血液制品费
declare @血费1 numeric(12,2);
declare @白蛋白类制品费1 numeric(12,2);
declare @球蛋白类制品费1 numeric(12,2);
declare @凝血因子类制品费1 numeric(12,2);
declare @细胞因子类制品费1 numeric(12,2);
--耗材类
declare @检查用一次性材料费1 numeric(12,2);
declare @治疗用一次性材料费1 numeric(12,2);
declare @手术用一次性材料费1 numeric(12,2);
--其他类
declare @其他费1 numeric(12,2);
declare @V_医疗付款方式 VARCHAR(50);

declare @V_记帐代码 VARCHAR(5);
declare @V_自费金额2 numeric(12,2);
declare @V_自费金额3 numeric(12,2);

declare @V_ROWCOUNT INTEGER;

BEGIN

  Delete From CISDOCT..MRD_CLINICAL_COST Where INPAT_NO=@V_ZYID ;
  --DELETE FROM 病史_病史住院费用表_上传 WHERE 住院ID=V_ZYID;

  ----1、清除临时表
  --DELETE FROM  病史_计算费用临时表 WHERE 住院ID=V_ZYID;
  --EXECUTE IMMEDIATE 'DELETE FROM MRD_CLINICAL_COST_TEMP';
  DELETE FROM CISDOCT..MRD_CLINICAL_COST_TEMP;

  ----2、是否存在数据，有数据就进去，没有就退出
  --SELECT COUNT(费用日期) INTO V_FYMX FROM 住院_费用流水帐  WHERE 住院ID=V_ZYID AND 附加ID=V_FJID AND 状态 NOT IN (0, 99) AND ROWNUM <=1;
  SELECT @V_医疗付款方式=MEDICAL_MODE,@V_记帐代码=ACCOUNT_CODE FROM CISDOCT..MRD_CLINICAL_REGSTER WHERE mrd_regster_id =@V_BAID;


  ---进入语句
  --IF V_FYMX>0 THEN

  --1、费用类  伙食费不算在总费用中
  INSERT INTO CISDOCT..MRD_CLINICAL_COST_TEMP(INPAT_NO,ITEM_CLASS,AMOUNT,REIMBURSEMENT_AMOUNT,SELFCARE_AMOUNT,OUTOFPOCKET_AMOUNT,MRD_MAX_CLASS,MRD_MIN_CLASS)
  SELECT
    A.INP_ID,
    A.ITEM_CLASS,
    isnull(SUM(a.amount),0.0)费用,
    isnull(SUM(A.REIMBURSEMENT_AMOUNT),0.0)报销金额,
    isnull(SUM(A.SELFCARE_AMOUNT),0.0)自理金额,
    isnull(SUM(A.OUTOFPOCKET_AMOUNT),0.0)自费金额,
    B.MRD_MAX_CLASS AS 病案大类,
    B.Mrd_Min_Class AS 病案小类
  FROM CISNURS..NUR_COST A
    LEFT JOIN CISCOMM..CODE_CHARGE_ITEM B ON A.ITEM_ID=B.ITEM_ID
    WHERE
      A.INP_ID=@V_ZYID
      AND A.STATUS  IN (1,2,3)
      AND A.ITEM_CLASS NOT IN (1,2,3,34)
      GROUP BY B.MRD_MAX_CLASS,B.Mrd_Min_Class ,A.INP_ID,A.ITEM_CLASS;

  --2、药品费
  INSERT INTO CISDOCT..MRD_CLINICAL_COST_TEMP(INPAT_NO,ITEM_CLASS,AMOUNT,REIMBURSEMENT_AMOUNT,SELFCARE_AMOUNT,OUTOFPOCKET_AMOUNT,MRD_MAX_CLASS)
  SELECT
    A.INP_ID,
    A.ITEM_CLASS,
    isnull(SUM(a.amount),0.0)费用,
    isnull(SUM(A.REIMBURSEMENT_AMOUNT),0.0)报销金额,
    isnull(SUM(A.SELFCARE_AMOUNT),0.0)自理金额,
    isnull(SUM(A.OUTOFPOCKET_AMOUNT),0.0)自费金额,
    CASE
      WHEN A.ITEM_CLASS=1 THEN '6_1' -- 西药费
      WHEN A.ITEM_CLASS=2 THEN '7_1' --中成药费
      WHEN A.ITEM_CLASS=3 THEN '7_2'
      ELSE ' '
      END 病案大类
  FROM CISNURS..NUR_COST  A
    WHERE
      A.INP_ID=@V_ZYID
      AND A.STATUS  IN (1,2,3)
      AND ITEM_CLASS IN (1,2,3)
      GROUP BY ITEM_CLASS,INP_ID;

  select @V_ROWCOUNT=count(0) from CISDOCT..MRD_CLINICAL_COST_TEMP;

  --DBMS_OUTPUT.put_line(V_ROWCOUNT||' 住院号： '||V_ZYID||' 总费用： '||总费用1);

  if @V_ROWCOUNT>0 begin
    --select nvl(sum(amount),0.0) into 总费用1 from MRD_CLINICAL_COST_TEMP where inpat_no=V_ZYID;
    --SELECT NVL(SUM(AMOUNT),0.0) INTO 总费用1 FROM MRD_CLINICAL_COST_TEMP WHERE INPAT_NO=V_ZYID;
    --获取自付金额
    SELECT @自付金额1=isnull(SUM(SELFCARE_AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE INPAT_NO=@V_ZYID;
    --获取自费金额
    SELECT @自费金额1=isnull(SUM(OUTOFPOCKET_AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE INPAT_NO=@V_ZYID;
    --获取其他支付
    SELECT @其它支付1=isnull(SUM(REIMBURSEMENT_AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE INPAT_NO=@V_ZYID;
    --一般医疗服务费
    SELECT @一般医疗服务费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS ='1_1' AND INPAT_NO=@V_ZYID;
    --一般治疗操作费
    SELECT @一般治疗操作费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='1_2' AND INPAT_NO=@V_ZYID;
    --护理费
    SELECT @护理费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='1_3' AND INPAT_NO=@V_ZYID;
    --其他费用   伙食费不统计
    SELECT @其他费用1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='1_4' AND ITEM_CLASS<>34 AND INPAT_NO=@V_ZYID;
    --病理诊断费
    SELECT @病理诊断费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='2_1' AND INPAT_NO=@V_ZYID;
    --实验室诊断费
    SELECT @实验室诊断费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='2_2' AND INPAT_NO=@V_ZYID;
    --影像学诊断费
    SELECT @影像学诊断费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS ='2_3' AND INPAT_NO=@V_ZYID;
    --临床诊断项目费
    SELECT @临床诊断项目费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS ='2_4' AND INPAT_NO=@V_ZYID;
    --非手术治疗项目费
    SELECT @非手术治疗项目费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='3_1' AND INPAT_NO=@V_ZYID;

    --获取临床物理治疗费
    SELECT
      @临床物理治疗费1=isnull(SUM(A.amount),0.0)
    FROM
      CISNURS..NUR_COST A
      LEFT JOIN CISCOMM..CODE_CHARGE_ITEM B ON A.ITEM_ID=B.ITEM_ID
      WHERE A.INP_ID=@V_ZYID   AND A.STATUS NOT IN (0, 99) AND isnull(B.MRD_MAX_CLASS,' ')='3_1_1';--临床物理治疗费

    --手术治疗费
    SELECT @手术治疗费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS ='3_2' AND INPAT_NO=@V_ZYID;

    --获取麻醉费
    SELECT @麻醉费1=isnull(SUM(A.AMOUNT),0.0)
    FROM CISNURS..NUR_COST A
       LEFT JOIN CISCOMM..CODE_CHARGE_ITEM B ON A.ITEM_ID=B.ITEM_ID
     WHERE A.INP_ID=@V_ZYID   AND A.STATUS NOT IN (0, 99)
    AND B.MRD_MIN_CLASS='3_2_1';

    --获取手术费
    select @手术费1 =isnull(@手术治疗费1,0.0)-isnull(@麻醉费1,0.0);
    --康复费
    SELECT @康复费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='4_1' AND INPAT_NO=@V_ZYID;
    --中医治疗费
    SELECT @中医治疗费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='5_1' AND INPAT_NO=@V_ZYID;
    --西药费
    SELECT @西药费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='6_1' AND INPAT_NO=@V_ZYID;

    --获取抗菌药物费用
    SELECT
      @抗菌药物费用1=isnull(SUM(A.AMOUNT),0.0)
    FROM CISNURS..NUR_COST A
      WHERE A.INP_ID=@V_ZYID   AND A.STATUS NOT IN (0, 99) AND A.ITEM_CLASS IN (1,2,3)
           AND A.ITEM_ID IN
           (
             SELECT DISTINCT HIS_药品代码 FROM FGKJYW..抗菌_药品通用名对应表
           );

    --中成药费
    SELECT @中成药费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='7_1' AND INPAT_NO=@V_ZYID;
    --中草药费
    SELECT @中草药费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='7_2' AND INPAT_NO=@V_ZYID;
    --血费
    SELECT @血费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='8_1' AND INPAT_NO=@V_ZYID;
    --白蛋白类制品费
    SELECT @白蛋白类制品费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='8_2' AND INPAT_NO=@V_ZYID;
    --球蛋白类制品费
    SELECT @球蛋白类制品费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='8_3' AND INPAT_NO=@V_ZYID;
    --凝血因子类制品费
    SELECT @凝血因子类制品费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='8_4' AND INPAT_NO=@V_ZYID;
    --细胞因子类制品费
    SELECT @细胞因子类制品费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS='8_5' AND INPAT_NO=@V_ZYID;
    --检查用一次性医用材料费
    SELECT @检查用一次性材料费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS = '9_1' AND INPAT_NO=@V_ZYID;
    --治疗用一次性医用材料费
    SELECT @治疗用一次性材料费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS = '9_2' AND INPAT_NO=@V_ZYID;
    --手术用一次性医用材料费
    SELECT @手术用一次性材料费1=isnull(SUM(AMOUNT),0.0) FROM CISDOCT..MRD_CLINICAL_COST_TEMP WHERE MRD_MAX_CLASS = '9_3' AND INPAT_NO=@V_ZYID;

    select @总费用1=isnull(sum(amount),0) from CISDOCT..MRD_CLINICAL_COST_TEMP;

    SELECT @其他费1=@总费用1 - isnull(@一般医疗服务费1, 0.0) - isnull(@一般治疗操作费1, 0.0) - isnull(@护理费1, 0.0) -
         isnull(@其他费用1, 0.0) - isnull(@病理诊断费1, 0.0) - isnull(@实验室诊断费1, 0.0) -
         isnull(@影像学诊断费1, 0.0) - isnull(@临床诊断项目费1, 0.0) - isnull(@非手术治疗项目费1, 0.0) -
         isnull(@手术治疗费1, 0.0) - isnull(@康复费1, 0.0) - isnull(@中医治疗费1, 0.0) -
         isnull(@西药费1, 0.0) - isnull(@中成药费1, 0.0) - isnull(@中草药费1, 0.0) - isnull(@血费1, 0.0) -
         isnull(@白蛋白类制品费1, 0.0) - isnull(@球蛋白类制品费1, 0.0) - isnull(@凝血因子类制品费1, 0.0) -
         isnull(@细胞因子类制品费1, 0.0) - isnull(@检查用一次性材料费1, 0.0) -
         isnull(@治疗用一次性材料费1, 0.0) - isnull(@手术用一次性材料费1, 0.0); /*- isnull(@其他费1, 0.0)*/
  end;


  --SELECT 住院号 INTO V_住院号 FROM FGHIS5_ZY.临床_病史登记表 WHERE 病案ID=V_BAID;
/*  SELECT
    COUNT(1) INTO V_CNT
  FROM FGHIS5_ZY.住院_结算发票表@FGHIS A,
    FGHIS5_YB.上海_医保住院收费表@FGHIS B
    WHERE A.结算ID=B.结算ID AND A.发票状态=2  AND A.住院号=V_ZYID;
  IF V_CNT >0 THEN
    BEGIN
      SELECT
        SUM(附加段帐户支付数) +SUM(起付段现金支付数)+SUM(统筹段现金支付数) ,
        SUM(自费费用总额) INTO 自付金额1,
        V_自费金额2
      FROM FGHIS5_ZY.住院_结算发票表@FGHIS A,FGHIS5_YB.上海_医保住院收费表@FGHIS B
      WHERE A.结算ID=B.结算ID AND A.发票状态=2  AND A.住院号=V_ZYID;

      --V_自费金额3 伙食费
      SELECT
        NVL(SUM(OUTOFPOCKET_AMOUNT), 0.0) INTO V_自费金额3
      FROM NUR_COST
        WHERE INP_ID = V_ZYID  AND STATUS NOT IN (0, 99)  AND ITEM_CLASS = 34;

       --病案中自费金额不含伙食费
       自费金额1 := V_自费金额2-V_自费金额3;
    END;
  END IF;*/

  --已结算的病人自付和自费金额取医保表 ADD END BY HONGQIANG 20181219
  IF (@V_医疗付款方式<>'6')
    BEGIN select @其它支付1=0.0;
  END;

  IF (@自付金额1<0)
    BEGIN select @自付金额1=0.0;
  END;

  IF (@V_医疗付款方式 ='7')
    BEGIN
    select @自费金额1 =@总费用1;
    select @其它支付1 =0.0;
    select @自付金额1 =0.0;  --ADD BEGIN BY HONGQIANG 20181213  自费病人自付金额为0
  END;

  --ADD BEGIN BY HONGQIANG 20181213  异地医保 按自费病人处理
  IF (@V_医疗付款方式 ='9') AND @V_记帐代码='84' BEGIN
      select @自付金额1 =0.0;
      select @自费金额1 =@总费用1;
      select @其它支付1 =0.0;
  END;
  --ADD END BY HONGQIANG 20181213  异地医保 按自费病人处理

  --ADD BEGIN BY HQ 20200108  HIS费用明细金额中存在合计为 -0.01 的数据
  IF @其他费1<0 BEGIN
    select @其他费1 =@其他费1-@其他费1;
    select @总费用1 =@总费用1-@其他费1;
  END;
  --ADD END BY HQ 20200108

  --dbms_output.put_line('总费用：'||总费用1);

  Insert Into CISDOCT..MRD_CLINICAL_COST
    (MRD_REGSTER_ID
    ,INPAT_NO, TOTAL_COST,SELF_PAY_FEE
     ,SELF_FEE,OTHER_PAY,GENERAL_FEE,TREAT_HANDLE_FEE,CN_DIALECTICAL_FEE
    ,CN_DIALECTICAL_H_FEE,NURSING_COST,OTHER_COST
     ,PATHOLOGY_COST, LAB_DIAGNOSIS_COST,IMAGE_DIAG_FEE,DIAGNOSIS_COST
     ,UNOPERATION_COST,TREAT_COST,OPERATION_TREAT_COST,ANAESTHESIA_COST
    ,OPERATION_COST,RECURE_COST,CN_DIAGNOSIS,CN_TREAT,CN_EXTERNAL_TREAT
     ,CN_BONE_FEE,PROD_MOXIBUSTION,CN_MASSAGE_TREAT,CN_ANORECTAL_TREAT
     ,CN_SPECIAL_TREAT, CN_OTHER,CN_DEPLOY_FEE,MEDICINE_FEE,ANTIBIOTICS_COST
     ,CH_MEDICINE_FEE,ORG_CN_PREPARATION,CN_HERBAL_FEE,BLOOD_FEE,ALBUMIN_COST
     ,GLOBULIN_COST,FACTOR_COST,CELL_FACTOR_FEE, DISPOSABLE_MATERIALS_COSST
     ,TREAT_DISPOSABLE_COST,OPERA_DISPOSABLE_COST,OTHER_FEE
     )
  Select @V_BAID
      ,@V_ZYID,isnull(@总费用1,0.00),@自付金额1
      ,@自费金额1,@其它支付1,@一般医疗服务费1,@一般治疗操作费1,@中医辩证论治费1
       ,@中医辩证论治会诊费1,@护理费1,@其他费用1
       ,@病理诊断费1,@实验室诊断费1,@影像学诊断费1,@临床诊断项目费1
       ,@非手术治疗项目费1,@临床物理治疗费1,@手术治疗费1,@麻醉费1
       ,@手术费1,@康复费1,@中医诊断1,@中医治疗费1,@中医外治1
       ,@中医骨伤1,@针刺与灸法1,@中医推拿治疗1,@中医肛肠治疗1
       ,@中医特殊治疗1,@中医其他1,@中医特殊调配加工1,@西药费1,@抗菌药物费用1
       ,@中成药费1,@医疗结构中药制剂费1,@中草药费1,@血费1,@白蛋白类制品费1
       ,@球蛋白类制品费1,@凝血因子类制品费1,@细胞因子类制品费1,@检查用一次性材料费1
       ,@治疗用一次性材料费1,@手术用一次性材料费1,@其他费1;

  --END IF;

  select MRD_REGSTER_ID,
       INPAT_NO, TOTAL_COST,SELF_PAY_FEE,
       SELF_FEE,OTHER_PAY,GENERAL_FEE,TREAT_HANDLE_FEE,CN_DIALECTICAL_FEE,
       CN_DIALECTICAL_H_FEE,NURSING_COST,OTHER_FEE,
       PATHOLOGY_COST, LAB_DIAGNOSIS_COST,IMAGE_DIAG_FEE,DIAGNOSIS_COST,
       UNOPERATION_COST,TREAT_COST,OPERATION_TREAT_COST,ANAESTHESIA_COST,
       OPERATION_COST,RECURE_COST,CN_DIAGNOSIS,CN_TREAT,CN_EXTERNAL_TREAT,
       CN_BONE_FEE,PROD_MOXIBUSTION,CN_MASSAGE_TREAT,CN_ANORECTAL_TREAT,
       CN_SPECIAL_TREAT, CN_OTHER,CN_DEPLOY_FEE,MEDICINE_FEE,ANTIBIOTICS_COST,
       CH_MEDICINE_FEE,ORG_CN_PREPARATION,CN_HERBAL_FEE,BLOOD_FEE,ALBUMIN_COST,
       GLOBULIN_COST,FACTOR_COST,CELL_FACTOR_FEE, DISPOSABLE_MATERIALS_COSST,
       TREAT_DISPOSABLE_COST,OPERA_DISPOSABLE_COST,OTHER_FEE
    FROM CISDOCT..MRD_CLINICAL_COST WHERE MRD_REGSTER_ID = @V_BAID;

END;
go

