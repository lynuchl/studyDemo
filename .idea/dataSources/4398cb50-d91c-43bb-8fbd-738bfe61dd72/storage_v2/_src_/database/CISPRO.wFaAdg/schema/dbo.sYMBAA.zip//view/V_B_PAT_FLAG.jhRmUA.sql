




CREATE VIEW [dbo].[V_PAT_FLAG] AS
SELECT T.标识分类 PAT_FLAG_CODE,T.标识名称 PAT_FLAG_NAME FROM [FGHIS5].[dbo].代码_病人标识定义表 T
go

