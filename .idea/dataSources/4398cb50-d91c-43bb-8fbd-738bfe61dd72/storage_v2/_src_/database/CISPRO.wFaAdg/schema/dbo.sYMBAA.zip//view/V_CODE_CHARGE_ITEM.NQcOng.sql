-- dbo.V_CODE_CHARGE_ITEM source

-- dbo.V_CODE_CHARGE_ITEM source

-- dbo.V_CODE_CHARGE_ITEM source

-- dbo.V_CODE_CHARGE_ITEM source

CREATE VIEW dbo.V_CODE_CHARGE_ITEM
AS
SELECT item_id AS item_id,
       a.SERIAL_NO AS item_class,
       a.CLASS_NAME AS class_name,
       t.ITEM_CODE AS item_code,
       t.ITEM_NAME AS item_name,
       t.INPUT_CODE AS input_code,
       t.ITEM_SPEC AS spec,
       t.UNITS AS unit,
       '0' AS cost_price,
       t.PRICE AS price,
       '0' AS adv_attr,
       '0' AS adv_flag,
       '1' AS status,
       '0' AS rmb_flag,
       '0' AS outp_flag,
       t.START_DATE AS start_date,
       t.STOP_DATE AS stop_date,
       '' AS remark,
       case when t.PERFORMED_BY is not null then replace(t.PERFORMED_BY,'*','0') else '0' end  def_dept_id,
       '0' AS serial_no,
       '0' AS org_id,
       1 AS create_id,
       GETDATE() AS create_date,
       1 AS update_id,
       GETDATE() AS update_date,
       t.CLASS_ON_MR AS dybadl,
       '0' AS dybaxl,
       t.NATION_SUBJECT_CODE AS NATION_SUBJECT_CODE
   FROM (select * from  openquery([DBLINK_HISPRODEV],'select * from COMM.PRICE_LIST')) t
  LEFT OUTER JOIN (select * from  openquery([DBLINK_HISPRODEV],'select * from COMM.BILL_ITEM_CLASS_DICT')) a ON t.ITEM_CLASS = a.CLASS_CODE
   left outer join (select * from  openquery([DBLINK_HISPRODEV],'select * from HISPRO.PRICE_LIST_ADD_C')) b on t.item_class=b.item_class and  t.item_code=b.item_code and t.ITEM_SPEC=b.ITEM_SPEC
 WHERE item_id IS NOT null
 and GETDATE()>=t.START_DATE and (GETDATE()<t.STOP_DATE or t.STOP_DATE is null);
go

