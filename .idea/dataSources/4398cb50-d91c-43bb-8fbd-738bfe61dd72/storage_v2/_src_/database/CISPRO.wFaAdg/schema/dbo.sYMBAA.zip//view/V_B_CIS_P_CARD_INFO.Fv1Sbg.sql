
CREATE VIEW [dbo].[V_CIS_P_CARD_INFO] AS 
/*select ID,OUTP_NO,NAME,CARD_NUMBER,POSTING_KEY,POSTING_TYPE,PATIENT_ID,CABINET_NUMBER,EFFECTIVE_DATE,CREATE_NAME,CREATE_DATE,STATE,DEFAULT_TYPE,CARD_TYPE from ciscomm..CIS_CARD_INFO; 
*/SELECT
t.卡信息id id,
t.门诊号 outp_no,
a.姓名 name,
t.卡号 card_number,
t.记帐代码 posting_key,
t.参保类型 posting_type,
a.门诊号 patient_id,
t.卡柜号 cabinet_number,
null effective_date,
t.操作员ID create_name,
t.操作时间 create_date,
( CASE WHEN t.状态 = 1 THEN 0 WHEN t.状态 = 0 THEN 1 END ) state,
NULL default_type,
t.卡类型 card_type 
FROM
	FGHIS5.dbo.系统_病人卡信息表 t
	INNER JOIN FGHIS5.dbo.系统_病人基本信息表 a ON t.门诊号 = a.门诊号

go

