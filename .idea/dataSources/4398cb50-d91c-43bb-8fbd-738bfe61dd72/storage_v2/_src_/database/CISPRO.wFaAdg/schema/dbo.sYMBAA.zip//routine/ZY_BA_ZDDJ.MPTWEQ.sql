-- **********************************************************************************----    
--1)功能描述：病案诊断
-- ********************************************************************************----

CREATE   procedure [dbo].[ZY_BA_ZDDJ](@BAID INT, @Dept INT) AS

declare @inpatNo INT

begin

  if @Dept=0  begin

	select @inpatNo=inpat_no FROM CISDOCT..mrd_clinical_regster WHERE mrd_regster_id=@BAID;

    --删除业务来源数据
    delete from CISDOCT..MRD_CLINICAL_DIAGNOSIS where MRD_REGSTER_ID=@BAID and DATA_SOURCE='2' and OPERATIONFLAG is null;

    --从 临床_住院诊断信息表 同步数据
    insert into CISDOCT..mrd_clinical_diagnosis
    ( DIAGNOSIS_ID,MRD_REGSTER_ID,INPAT_NO
	,PATHOLOGY_NO,INP_CONDITION,STATISTICAL_CODE,SERIAL_NUM,DIAGNOSIS_CODE,
      DIAGNOSIS_SUPPLY,DIAGNOSIS_TYPE,DIAGNOSIS_NAME,DIAGNOSIS_PREFIX,DIAGNOSIS_FULL_NAME,DIAGNOSIS_NATURE,
      TREAT_RESULT,TUMOR_CODE,TUMOR_NAME,DIAGNOSIS_CLASS,DATA_SOURCE,EXTERNAL_ID
    )
     select
	  (next value for CISPRO..SEQ_ID_MRD_CLINICAL_DIAGNOSIS) as DIAGNOSIS_ID,
      --病案ID
      regster.mrd_regster_id,
      --住院ID
      regster.inpat_no,
      --病理号
      regster.PATHOLOGY_NO,
      --入院情况
      regster.INP_CONDITION,
      --统计码
      '' as STATISTICAL_CODE,
      --序号
	  ISNULL(diag.DIAG_SEQ,-1) as SERIAL_NUM,
      --诊断编码
      diag.DIAG_CODE as DIAGNOSIS_CODE,
      --诊断补充
      diag.SUFFIX as DIAGNOSIS_SUPPLY,
      --诊断类型 TODO
      case diag.DIAG_CATE
        when '出院诊断' then
          case diag.DIAG_TYPE
            when 'WEST' then
              case diag.diag_seq
                when 1 then '1' else '2'
              end
            end
        when '门诊诊断' then '9'
        when '入院诊断' then '10'
        when '损伤中毒' then '5'
        when '病理诊断' then '6'
        else
          null
        end as DIAGNOSIS_TYPE,
      --诊断名称
      diag.DIAG_NAME as DIAGNOSIS_NAME,
      --诊断前缀
      diag.PROS as DIAGNOSIS_PREFIX,
      --诊断全称
      '' as DIAGNOSIS_FULL_NAME,
      --诊断性质
      '' as DIAGNOSIS_NATURE,
      --治疗结果
      '1' as TREAT_RESULT,
      --肿瘤编码
      diag.TUMOUR_CODE as TUMOR_CODE,
      --肿瘤名称
      diag.TUMOUR_NAME as TUMOR_NAME,
      --西医、中医
      case diag.DIAG_TYPE when 'CN' then '2' else '1' end as DIAGNOSIS_CLASS,
      '2' as DATA_SOURCE,
      diag.diag_id as EXTERNAL_ID
      from CISDOCT..mrd_clinical_regster regster
      inner join CISCOMM..CIS_DIAG_INFO diag on regster.inpat_no=diag.inpat_no
      where regster.inpat_no=@inpatNo  and (diag.status='1' or diag.status is null) 
      and diag.DIAG_CATE in ('出院诊断','门诊诊断','入院诊断','损伤中毒','病理诊断')
      and diag.diag_id not in 
	  (select diag.EXTERNAL_ID from CISDOCT..mrd_clinical_diagnosis diag where diag.inpat_no=@inpatNo and DATA_SOURCE='2' and diag.OPERATIONFLAG is not null);
  end;

       select DIAGNOSIS_ID,MRD_REGSTER_ID,INPAT_NO,PATHOLOGY_NO,INP_CONDITION,STATISTICAL_CODE,SERIAL_NUM,DIAGNOSIS_CODE,
        DIAGNOSIS_SUPPLY,DIAGNOSIS_TYPE,DIAGNOSIS_NAME,DIAGNOSIS_PREFIX,DIAGNOSIS_FULL_NAME,DIAGNOSIS_NATURE,
        TREAT_RESULT,TUMOR_CODE,TUMOR_NAME,TUMOR_ADD_CODE,TUMOR_ADD_NAME,FIGO_CODE,FIGO_NAME,TNM_CODE,TNM_NAME,
        PATHOLOGY_DIAG_DESC,CHINESE_MEDICINE_CODE,CHINESE_MEDICINE_NAME,
        DIAGNOSIS_CLASS,DIAGNOSIS_AFTER,DATA_SOURCE,OPERATIONFLAG,EXTERNAL_ID from CISDOCT..MRD_CLINICAL_DIAGNOSIS 
        where MRD_REGSTER_ID=@BAID and (OPERATIONFLAG!='2' or OPERATIONFLAG is null) ORDER BY SERIAL_NUM;
end;
go

