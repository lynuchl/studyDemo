CREATE PROCEDURE [dbo].[PUB_SS_GETSEED](
	@count	    int=1 ,
	@detail_count int=1,
	@diagnosis_count int=1,
	@is_special int=0) 
AS
BEGIN

if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#SEED_TABLE'))
begin
	DROP TABLE #SEED_TABLE;
end
   begin
       CREATE TABLE #SEED_TABLE (
						mc VARCHAR(30) NULL,
						lsh  INT NULL)
					 
   end


--@count 手术申请单数量  @detail_count 手术明细取种子数量  @diagnosis_count 诊断明细取种子数量
		begin 
       
			BEGIN TRAN
			UPDATE [CISPRO].[dbo].[系统_编码流水号] SET 流水号=流水号+@count WHERE 分类='新手术管理' and 名称='手术_手术登记ID'
			--IF @@ERROR <> 0 GOTO ERR
			insert into #SEED_TABLE
			SELECT 
			'手术登记ID' mc,
			ISNULL(MAX(流水号),@count) lsh
			FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类='新手术管理' and 名称='手术_手术登记ID'
			
			UPDATE [CISPRO].[dbo].[系统_编码流水号] SET 流水号=流水号+@count WHERE 分类='新手术管理' and 名称='手术_手术ID'
			--IF @@ERROR <> 0 GOTO ERR
			insert into #SEED_TABLE
			SELECT 
			'手术ID' mc,
			ISNULL(MAX(流水号),@count) lsh
			FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类='新手术管理' and 名称='手术_手术ID'
			
			UPDATE [CISPRO].[dbo].[系统_编码流水号] SET 流水号=流水号+@count WHERE 分类='新手术管理' and 名称='手术_麻醉ID'
			--IF @@ERROR <> 0 GOTO ERR
			insert into #SEED_TABLE
			SELECT 
			'麻醉ID' mc,
			ISNULL(MAX(流水号),@count) lsh
			FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类='新手术管理' and 名称='手术_麻醉ID'
			
			UPDATE [CISPRO].[dbo].[系统_编码流水号] SET 流水号=流水号+@detail_count WHERE 分类='新手术管理' and 名称='手术_手术明细ID'
			--IF @@ERROR <> 0 GOTO ERR
			insert into #SEED_TABLE
			SELECT 
			'手术明细ID' mc,
			ISNULL(MAX(流水号),@detail_count) lsh
			FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类='新手术管理' and 名称='手术_手术明细ID'
			
			UPDATE [CISPRO].[dbo].[系统_编码流水号] SET 流水号=流水号+@diagnosis_count WHERE 分类='新手术管理' and 名称='手术_诊断明细ID'
			--IF @@ERROR <> 0 GOTO ERR
			insert into #SEED_TABLE
			SELECT 
			'诊断明细ID' mc,
			ISNULL(MAX(流水号),@diagnosis_count) lsh
			FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类='新手术管理' and 名称='手术_诊断明细ID'
			
			UPDATE [CISPRO].[dbo].[系统_编码流水号] SET 流水号=流水号+@is_special WHERE 分类='新手术管理' and 名称='非计划手术'
			--IF @@ERROR <> 0 GOTO ERR
			insert into #SEED_TABLE
			SELECT 
			'非计划手术' mc,
			ISNULL(MAX(流水号),@is_special) lsh
			FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类='新手术管理' and 名称='非计划手术'
			
			--IF @@ERROR <> 0 GOTO ERR
			COMMIT TRAN
		end
      
	   
 	 select * from #SEED_TABLE
	 DROP TABLE #SEED_TABLE;

END
go

