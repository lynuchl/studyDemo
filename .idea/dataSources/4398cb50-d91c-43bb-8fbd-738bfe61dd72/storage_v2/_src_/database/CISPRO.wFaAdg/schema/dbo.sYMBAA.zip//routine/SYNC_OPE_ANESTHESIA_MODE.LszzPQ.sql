-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步手术申请-麻醉方式(OPE_ANESTHESIA_MODE)
-- Description:	 通过作业定时去同步his中新增或者修改的麻醉方式信息
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_OPE_ANESTHESIA_MODE]
	 
AS
BEGIN 
 
      merge CISEAPP..OPE_ANESTHESIA_MODE as A
	  using(
			SELECT t.麻醉方式ID [ANAESTHESIA_ID]
				   ,t.方式名称 [ANAESTHESIA_NAME]
				   ,t.输入码1 [INPUT_CODE]
				   ,t.输入码2 [FIVE_STROKES]
				   ,t.收费项目 [CHARGE_ITEM]
				   ,t.备注 [REMARKS]
				   ,0 [STATE]
		   from [FGHIS5_ZY].[dbo].手术_麻醉方式表 t
			)B ON A.ANAESTHESIA_ID=B.ANAESTHESIA_ID
			when not matched then 
			INSERT ([ANAESTHESIA_ID]
           ,[ANAESTHESIA_NAME]
           ,[INPUT_CODE]
           ,[FIVE_STROKES]
           ,[CHARGE_ITEM]
           ,[REMARKS]
           ,[CREATE_ID]
           ,[CREATE_DATE]
           ,[UPDATE_ID]
           ,[UPDATE_DATE]
           ,[ORG_ID]
           ,[STATE]) 
		values(b.[ANAESTHESIA_ID]
           ,b.[ANAESTHESIA_NAME]
           ,b.[INPUT_CODE]
           ,b.[FIVE_STROKES]
           ,b.[CHARGE_ITEM]
           ,b.[REMARKS]
           ,-1  
			,GETDATE() 
			,null  
			,null  
			,'10001' 
			,[STATE])	;

			update ciseapp..OPE_ANESTHESIA_MODE set STATE=1 where not exists(select * from [FGHIS5_ZY].[dbo].[手术_麻醉方式表] t where  t.麻醉方式ID=ANAESTHESIA_ID)
END


go

