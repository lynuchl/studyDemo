





CREATE VIEW [dbo].[V_test] AS
/***测试***/
SELECT [ID]
      ,[DEPT_CODE]
      ,[DEPT_NAME]
      ,[DEPT_ABBRE]
      ,[SUB_CLASS]
      ,[DEPT_ATTR]
      ,[PARENT_ID]
      ,[INPUT_CODE]
      ,[ORDERED]
      ,[STATUS]
      ,[DEPT_TYPE]
      ,[IDENTIFY]
      ,[ORG_ID]
      ,[CREATE_ID]
      ,[CREATE_DATE]
      ,[UPDATE_ID]
      ,[UPDATE_DATE]
      ,[DEPT_CLASS_ATTR]
      ,[DEPT_SPECIAL_ATTR]
      ,[OUTP_INP_ATTR]
      ,[DEPT_STOCK_ATTR]
      ,[DEPT_ADDRESS] FROM [ciscomm].[dbo].AUTH_DEPT T
go

