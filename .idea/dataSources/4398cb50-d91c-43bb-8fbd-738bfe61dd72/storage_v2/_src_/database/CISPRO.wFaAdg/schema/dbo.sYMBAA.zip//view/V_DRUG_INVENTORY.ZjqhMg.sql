-- dbo.V_DRUG_INVENTORY source

-- dbo.V_DRUG_INVENTORY source

CREATE  VIEW [dbo].[V_DRUG_INVENTORY] AS
SELECT 
	pri.ITEM_ID drug_id,
	stock.STORAGE dept_id,
	curr.ITEM_NAME drug_name,
	curr.ITEM_SPEC drug_spec,
	sum(stock.QUANTITY) inventory,
	CASE WHEN stock.SUPPLY_INDICATOR = 1 THEN '统一上' ELSE '0' END  counter_status,
	'1' drug_status
FROM
	[DBLINK_HISPRODEV]..[PHARMACY].[DRUG_STOCK] stock
LEFT JOIN [DBLINK_HISPRODEV]..[COMM].[CURRENT_PRICE_LIST]  curr ON
	stock.DRUG_CODE = curr.ITEM_CODE
	AND stock.PACKAGE_SPEC + stock.FIRM_ID = curr.ITEM_SPEC 
LEFT JOIN [DBLINK_HISPRODEV]..[HISPRO].[PRICE_LIST_ADD_C] pri ON
	stock.DRUG_CODE = pri.ITEM_CODE
	AND stock.PACKAGE_SPEC + stock.FIRM_ID = pri.ITEM_SPEC 
	WHERE curr.ITEM_NAME IS NOT null
	GROUP BY pri.ITEM_ID,
	stock.STORAGE,
	curr.ITEM_NAME,
	curr.ITEM_SPEC,
	stock.SUPPLY_INDICATOR
;
go

