CREATE PROCEDURE [dbo].[ZY_YS_dischargeAfterCostCheck](@inpId varchar(20),
                                                       @dischargeTime varchar(50),
                                                       @count Int OUTPUT) AS


--出院检查，校验是否存在出院时间后的费用
BEGIN

    --住院id
    DECLARE @IN_HOSPITAL_ID varchar(50)
    select @IN_HOSPITAL_ID = IN_HOSPITAL_ID from CISCOMM..CIS_HOSTPITAL_INFO t where t.INP_ID = @inpId;

    select @count = count(1)
    from (
             select t.INP_ID,
                    t.PATIENT_ID,
                    t.IN_HOSPITAL_ID,
                    t.ADVICE_ID,
                    t.DEPT_ID,
                    t.WARD_ID,
                    t.ADDITIONAL_ID,
                    t.STATUS,
                    t.ITEM_ID,
                    t.ITEM_CLASS
             from V_INP_FEE_WASTE t
             where t.IN_HOSPITAL_ID = @IN_HOSPITAL_ID
               and convert(datetime,
                           FORMAT(CONVERT(bigint, t.EXPENSES_DATE + t.EXPENSES_TIME), '####-##-## ##:##:##'), 120)
                 >
                   convert(datetime, FORMAT(CONVERT(bigint, @dischargeTime), '####-##-## ##:##:##'), 120)
               and t.STATUS =1 --1已计费，2已结算
--              group by t.INP_ID, t.PATIENT_ID, t.IN_HOSPITAL_ID, t.ADVICE_ID, t.DEPT_ID, t.WARD_ID, t.ADDITIONAL_ID,
 --                       t.STATUS, t.ITEM_ID, t.ITEM_CLASS
--              having sum(t.QUANTITY) > 0
         ) t;
    return @count;
END;
go

