-- dbo.V_CIS_P_CONTACT_INFO source

CREATE VIEW dbo.V_CIS_P_CONTACT_INFO
AS
SELECT null AS id,
       t.PATIENT_ID AS outp_no,
       t.NEXT_OF_KIN AS name,
      CASE 
         WHEN t.RELATIONSHIP = '1' THEN
          '夫妻'
		WHEN t.RELATIONSHIP = '2' THEN
         '子女'
         WHEN t.RELATIONSHIP = '3'THEN
          '(外)孙子女'
         WHEN t.RELATIONSHIP = '4' THEN
         '(岳)父母'
         WHEN t.RELATIONSHIP = '5' THEN
          '(外)祖父母'
         WHEN t.RELATIONSHIP = '6' THEN
          '兄弟姐妹'
         WHEN t.RELATIONSHIP = '7' THEN
          '亲属'
         WHEN t.RELATIONSHIP = '8' THEN
          '朋友'
         WHEN t.RELATIONSHIP = '9' THEN
          '同事'
         WHEN t.RELATIONSHIP = '10' THEN
          '其他'
         WHEN t.RELATIONSHIP = '11' THEN
          '寄养'
         ELSE
         ''
       END AS relation,
       t.PHONE_NUMBER_HOME AS telephone,
       t.NEXT_OF_KIN_PHONE AS mobile_phone,
       t.NEXT_OF_KIN_ZIP_CODE AS email,
       t.INSERT_DATE AS create_date,
       t.VIP_INDICATOR AS state,
       t.NEXT_OF_KIN_ADDR AS addr,
       1 AS default_info,
       null AS remarks
  FROM DBLINK_HISPRODEV..MEDREC.PAT_MASTER_INDEX T;
go

