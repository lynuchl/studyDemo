CREATE   PROCEDURE [dbo].[ZY_YS_GETYPINFOR](@bqid			int,
											@deptId         int,
											@uid            int,
											@itemClass      int,
											@advAttr        varchar(1),--医嘱属性：0-长期 1-临时 2-出院带药 3-中草药
											@DRUG_CODE_LIST varchar(1000)) AS
-- CIS住院药品查询                
SELECT
	 d.SERIAL_NO itemClass,
	 d.CLASS_NAME className,
	 hvic.FEE_GRADE rmbFlag,
	CASE
		WHEN hvic.FEE_GRADE = '1' THEN
                   	'甲类'
		WHEN hvic.FEE_GRADE = '2' THEN
                   	'乙类'
		WHEN hvic.FEE_GRADE = '3' THEN
                   	'丙'
		ELSE
                   	''
	END AS rmbName,
	 c.ITEM_ID itemCode,
	 a.DRUG_NAME itemName,
	 c.ITEM_SPEC  spec,
	 a.DOSE_PER_UNIT basicDosage,
	 a.DOSE_UNITS  basicDosageUnit,
	 b.AMOUNT_PER_PACKAGE  wholeQuantity,
	 a.DOSE_PER_UNIT packingQuantity,
	 b.UNITS  packingUnit,
	 b.AMOUNT_PER_PACKAGE convPackingQuantity,
	 b.UNITS  convPackingUnit,
	 '0' convPackingSpec,
	 b.RETAIL_PRICE AS price,
	  '【高警示】' AS drugShow,
	 sum(stock.QUANTITY) stockQuantity,
	 stock.STORAGE  AS deptId,
     dept.DEPT_NAME AS deptName,
     '0' AS indicationRemarks,
     '0' AS productPlace,
     a.input_code AS inputCode,
     '0' indicationFlag,
     '0' AS fineHempPoisonFlag,
     '0' AS highPriceDrugFlag,
	 '0' AS upLowCabFlag,
	 a.DRUG_FORM  drugDosageForm
FROM
[DBLINK_HISPRODEV]..[COMM].[DRUG_DICT] a
left JOIN [DBLINK_HISPRODEV]..[COMM].[DRUG_PRICE_LIST]  b ON a.DRUG_CODE = b.DRUG_CODE AND a.DRUG_SPEC = b.MIN_SPEC 
LEFT JOIN [DBLINK_HISPRODEV]..[HISPRO].[PRICE_LIST_ADD_C] c ON b.DRUG_CODE = c.ITEM_CODE  AND b.DRUG_SPEC + b.FIRM_ID  = c.ITEM_SPEC 
LEFT JOIN [DBLINK_HISPRODEV]..[COMM].[BILL_ITEM_CLASS_DICT] d ON c.ITEM_CLASS = d.class_code
LEFT JOIN [DBLINK_HISPRODEV]..[PHARMACY].[DRUG_STOCK] stock ON stock.drug_code = b.drug_code and stock.PACKAGE_SPEC = b.drug_spec and stock.firm_id = b.firm_id
LEFT JOIN [DBLINK_HISPRODEV]..[HISPRO].[HIS_VS_INSUR_CATALOG] hvic ON hvic.CODE_HIS  = c.ITEM_CODE + c.ITEM_SPEC
LEFT JOIN [DBLINK_HISPRODEV]..[COMM].[DEPT_DICT] dept on stock.STORAGE  = dept.DEPT_CODE
where c.ITEM_CLASS is not null
 and stock.QUANTITY >0
 and dept.STORAGE_TYPE = 1
 AND GETDATE() >=start_date and (GETDATE()<stop_date or stop_date is null)
GROUP BY d.SERIAL_NO,
		 d.CLASS_NAME,
		 c.ITEM_ID,
		 hvic.FEE_GRADE,
		 a.DRUG_NAME,
		 c.ITEM_SPEC,
		 b.MIN_SPEC,
		 a.DOSE_UNITS,
		 a.DOSE_PER_UNIT,
		 b.AMOUNT_PER_PACKAGE,
		 b.AMOUNT_PER_PACKAGE,
		 b.UNITS,
		 b.AMOUNT_PER_PACKAGE,
		 b.MIN_UNITS,
		 b.RETAIL_PRICE,
	     a.input_code,
	     stock.STORAGE,
	     dept.DEPT_NAME ,
		 a.DRUG_FORM
		 ;
go

