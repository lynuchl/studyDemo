CREATE PROCEDURE [dbo].[SYNC_OPERATION_MASTER]
(@v_inpatno varchar(20), @v_ope_register_id INT) 
AS
BEGIN
	-- routine body goes here, e.g.
	-- SELECT 'Navicat for SQL Server'
	declare @num int,@count  int,@person_num int,@person_count int
	DECLARE @Start_date DATE,@End_date date
  set @Start_date=convert(varchar(10),GETDATE(),120)
  set @End_date=convert(varchar(10),GETDATE()+1,120)
	set @num=0
  set @count=1
	set @person_num=0
  set @person_count=1
	
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_ADVICE_GROUP'))
begin
	DROP TABLE #TEMP_ADVICE_GROUP;
	DROP TABLE #TEMP_ADVICE_NEW;
	DROP TABLE #TEMP_OPE_PERSON_NEW;
end
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_ADVICE'))
   BEGIN
		DROP TABLE #TEMP_ADVICE;
   END
   else
   begin
       CREATE TABLE #TEMP_ADVICE (
						OPE_REG_ID numeric(20, 0) NULL,
						ADVICE_ID numeric(20, 0) NULL,
						INP_ID varchar(50) NULL,
						APPLY_TIME datetime NULL,
						SEQ numeric(20,0) NULL,
						PRESC_ID INT 
					)
					 
   end
	 
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_OPE_PERSON'))
BEGIN
		DROP TABLE #TEMP_OPE_PERSON;
   END
   else
   begin
       CREATE TABLE #TEMP_OPE_PERSON (
						OPE_REG_ID numeric(20, 0) NULL,
						OPERATE_NO varchar(50) NULL,
						ROLE_ID INT,
						CREATE_ID INT,
						remarks varchar(50) NULL,
						ID INT
					)			 
   end


	  if @v_inpatno<>'' and @v_ope_register_id>0
	     begin
		   insert into #TEMP_ADVICE
			select B.ID OPE_REG_ID, T.ADVICE_ID,B.INP_ID,B.APPLY_TIME,D.SEQ,NULL PRESC_ID from CISDOCT..DOC_ADVICE_EXTEND t
			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
			INNER JOIN CISEAPP..OPE_PAT_REGISTER B ON T.EXTE_NUM=B.ID
			left join CISEAPP..OPE_DETAIL_INFO D ON B.ID = D.OPE_REGIST_ID
			where B.ID=@v_ope_register_id and a.INPAT_NO=@v_inpatno and (T.CONFIRM_DATE>=@Start_date and T.CONFIRM_DATE<@End_date) and t.EXTE_APP = '手术' AND A.STATUS IN(2,3,4,7) AND B.STATE in (1,2)
			and not exists(select * from CISEAPP..OPE_PAT_REG_RECORD r where r.OPE_REG_ID=B.ID and r.SEQ = D.SEQ);
         end
	   else
	     begin
		    insert into #TEMP_ADVICE
		      select B.ID OPE_REG_ID, T.ADVICE_ID,B.INP_ID,B.APPLY_TIME,D.SEQ,NULL PRESC_ID from CISDOCT..DOC_ADVICE_EXTEND t
			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
			INNER JOIN CISEAPP..OPE_PAT_REGISTER B ON T.EXTE_NUM=B.ID 
						left join CISEAPP..OPE_DETAIL_INFO D ON B.ID = D.OPE_REGIST_ID
			where (T.CONFIRM_DATE>=@Start_date and T.CONFIRM_DATE<@End_date) and t.EXTE_APP = '手术' AND A.STATUS IN(2,3,4,7) AND B.STATE in (1,2)
			and not exists(select * from CISEAPP..OPE_PAT_REG_RECORD r where r.OPE_REG_ID=B.ID and r.SEQ = D.SEQ);
		 end
	
	
	     -----手术明细医嘱ID取种子
		  select @count=count(0) from #TEMP_ADVICE 
   		 if @count>0
		 begin
		       BEGIN TRAN
					UPDATE [FGHIS5_ZY].[dbo].[住院_编码流水号] SET 流水号=流水号+@count WHERE 分类 = '病区护士' and 名称='S_医嘱ID'
					--IF @@ERROR <> 0 GOTO ERR
					SELECT @num=ISNULL(MAX(流水号),@count) FROM [FGHIS5_ZY].[dbo].[住院_编码流水号] with (nolock)  WHERE 分类 = '病区护士' and 名称='S_医嘱ID'
					--IF @@ERROR <> 0 GOTO ERR
			   COMMIT TRAN
		 end
		 
		 			 select OPE_REG_ID,ADVICE_ID,INP_ID,APPLY_TIME,SEQ,@num-(row_number() over(order by OPE_REG_ID)-1) PRESC_ID into #TEMP_ADVICE_NEW from #TEMP_ADVICE
		   select DISTINCT OPE_REG_ID into #TEMP_ADVICE_GROUP from #TEMP_ADVICE
		 
		 ----组装手术排班人员表
		 INSERT into #TEMP_OPE_PERSON
		     SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
	       3 ROLE_ID,
	       p.CREATE_ID CREATE_ID,
				 case when p.OPE_DEPT_ID is not null then '手术排班' else '麻醉排班' end as remarks,
				 NULL ID
	       from #TEMP_ADVICE t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.KNIFE_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.KNIFE_ID = o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
	       4 ROLE_ID,
	       p.CREATE_ID CREATE_ID,
				 case when p.OPE_DEPT_ID is not null then '手术排班' else '麻醉排班' end as remarks,
				 NULL ID
	       from #TEMP_ADVICE t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.ONE_HELP_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.ONE_HELP_ID= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
	       6 ROLE_ID,
	       p.CREATE_ID CREATE_ID,
				 case when p.OPE_DEPT_ID is not null then '手术排班' else '麻醉排班' end as remarks,
				 NULL ID
	       from #TEMP_ADVICE t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.SECOND_HELP_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.SECOND_HELP_ID= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
	       1 ROLE_ID,
	       p.CREATE_ID CREATE_ID,
				 case when p.OPE_DEPT_ID is not null then '手术排班' else '麻醉排班' end as remarks,
				 NULL ID
	       from #TEMP_ADVICE t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.TOUR_NURSE > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.TOUR_NURSE= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
	       7 ROLE_ID,
	       p.CREATE_ID CREATE_ID,
				 case when p.OPE_DEPT_ID is not null then '手术排班' else '麻醉排班' end as remarks,
				 NULL ID
	       from #TEMP_ADVICE t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.SECOND_TOUR_NURSE > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.SECOND_TOUR_NURSE= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
	       2 ROLE_ID,
	       p.CREATE_ID CREATE_ID,
				 case when r.OPE_DEPT_ID is not null then '手术排班' else '麻醉排班' end as remarks,
				 NULL ID
	       from #TEMP_ADVICE t
	       left join CISEAPP..OPE_ANESTHESIA_REGIST p ON t.OPE_REG_ID = p.OPE_REGIST_ID and p.DOCTOR_ID > 0
				 left join CISEAPP..OPE_PAT_REGISTER r ON t.OPE_REG_ID = r.ID
	       left join CISCOMM..AUTH_OPERATOR o on p.DOCTOR_ID= o.ID
				 
				 -----手术排班人员表取种子
				 select @person_count=count(0) from #TEMP_OPE_PERSON
   		 if @person_count>0
		 begin
		       BEGIN TRAN
					UPDATE [FGHIS5_ZY].[dbo].[住院_编码流水号] SET 流水号=流水号+@person_count WHERE 分类 = '手术' and 名称='排班人员ID'
					--IF @@ERROR <> 0 GOTO ERR
					SELECT @person_num=ISNULL(MAX(流水号),@person_count) FROM [FGHIS5_ZY].[dbo].[住院_编码流水号] with (nolock)  WHERE 分类 = '手术' and 名称='排班人员ID'
					--IF @@ERROR <> 0 GOTO ERR
			   COMMIT TRAN
		 end
		 
		 			 select OPE_REG_ID,OPERATE_NO,ROLE_ID,CREATE_ID,remarks,@person_num-(row_number() over(order by OPE_REG_ID)-1) ID into #TEMP_OPE_PERSON_NEW from #TEMP_OPE_PERSON
				 
		 
	
	begin tran
	
	--插入手术登记表
	INSERT INTO [FGHIS5_ZY].[dbo].[手术_登记表]
	([手术登记ID],[住院号],[住院ID],[申请医生],[附加ID],[病人ID],[门诊号],[就诊ID],[病人姓名],
	[性别],[年龄],[出生日期],[手术性质],[所属病区],[所属科室],[所属床位],[是否紧急],[手术部位],[体重],[身高],[申请时间],[预约时间],[审核标志],[手术科室],[手术房间],[手术台次],[安排时间],[安排人],[预计费用],[手术排班],[麻醉排班],[血型],[是否急救],[手术状态],[备注],[是否植入],[操作时间],[操作医生],[手术日期],[手术时间],[申请类型],[记帐类型],[入院诊断名称],[冰冻病理],[病情],[护理等级],[住院状态],[麻醉方式],[特殊需求],[手术台],[麻醉状态],[麻醉科室],[申请科室],[登记部门],[审核状态],[关联登记ID],[健康卡号],[医生状态])
	select 
	p.ID [手术登记ID],
	P.inp_id [住院号],
	c.IN_HOSPITAL_ID [住院ID],
	creater.OPERATE_NO [申请医生],
	c.ADDITIONAL_ID [附加ID],
	p.PATIENT_ID [病人ID],
	p.PATIENT_ID [门诊号],
	p.VISIT_NO [就诊ID],
	c.NAME [病人姓名],
	c.GENDER [性别],
	CONVERT(VARCHAR(10),DATEDIFF(YEAR,c.BIRTHDAY,@Start_date)) + 'Y' [年龄],
	convert(varchar(10),c.BIRTHDAY,120) [出生日期],
	case when p.OPE_NATURE = '0' then '1' when p.OPE_NATURE = '1' then '0' else '2' end as [手术性质],
	p.WARD_ID [所属病区],
	p.DEPT_ID [所属科室],
	c.BEDS_ID [所属床位],
	p.IS_URGENT [是否紧急],
	'' [手术部位],
	p.WEIGHT [体重],
	p.HEIGHT [身高],
	p.APPLY_TIME [申请时间],
	p.APPOINTMENT_DATE [预约时间],
	p.EXAMINE_SIGN [审核标志],
	p.OPE_DEPT_ID [手术科室],
	d.ROOM_ID [手术房间],
	d.OPE_TABLE_TIMES [手术台次],
	null [安排时间],
	null [安排人],
	null [预计费用],
	0 [手术排班],
	0 [麻醉排班],
	p.BLOOD_TYPE [血型],
	p.IS_EMERG [是否急救],
	0 [手术状态],
	p.REMARKS [备注],
	p.IMPLANT_EQUIPMENT [是否植入],
	p.CREATE_DATE [操作时间],
	p.CREATE_ID [操作医生],
	CONVERT(varchar(20),d.OPE_TIME,112) [手术日期],
	p.APPOINTMENT_DATE [手术时间],
	p.APPLY_TYPE [申请类型],
	c.ACCOUNT_CODE [记帐类型],
	c.INP_DIAGNOSIS_NAME [入院诊断名称],
	p.cryopathology [冰冻病理],
	c.CURRENT_CONDITION [病情],
	c.CARE_LEVEL [护理等级],
	c.INP_STAT [住院状态],
	p.ANAESTHESIA_ID [麻醉方式],
	p.SPECIAL_NEED [特殊需求],
	null [手术台],
	0 [麻醉状态],
	p.ANESTHESIA_ROOM [麻醉科室],
	p.DEPT_ID [申请科室],
	case when p.OPE_DEPT_ID is not null then '手术' else '麻醉' end as [登记部门],
	null [审核状态],
	null [关联登记ID],
	null [健康卡号],
	null [医生状态]
	from #TEMP_ADVICE_GROUP t 
	left join CISEAPP..OPE_PAT_REGISTER p on t.OPE_REG_ID = p.ID
	left join CISCOMM..cis_hostpital_info c on p.INP_ID = c.inp_id
	left join CISCOMM..AUTH_OPERATOR creater on p.CREATE_ID = creater.ID
	left join CISEAPP..OPE_DOC_REGISTER d on p.ID = D.OPE_REGIST_ID
	left join CISEAPP..OPE_ANESTHESIA_REGIST a on p.ID = a.OPE_REGIST_ID
	;
	
	--插入手术明细表
	INSERT INTO [FGHIS5_ZY].[dbo].[手术_手术明细表]
	([手术登记ID],[序号],[前导词],[后缀词],[登记类型],[手术编码],[手术名称],[手术规模],[切口情况],[手术部位],[肿瘤大小],[状态],[手术体位],[手术等级],[手术类型],[医嘱ID])
	select 
	d.OPE_REGIST_ID [手术登记ID],
	d.SEQ [序号],
	d.PREFIX [前导词],
	d.SUFFIX[后缀词],
	0 [登记类型],
	d.OPE_CODE [手术编码],
	d.OPE_NAME [手术名称],
	d.SCALE_ID [手术规模],
	d.INCISION_ID [切口情况],
	d.POSITION_ID [手术部位],
	'' [肿瘤大小],
	0 [状态],
	d.PLACE_ID [手术体位],
	d.LEVEL_ID [手术等级],
	null [手术类型],
	t.PRESC_ID [医嘱ID]
	from #TEMP_ADVICE_NEW t
	left join CISEAPP..OPE_DETAIL_INFO D ON t.OPE_REG_ID = D.OPE_REGIST_ID and t.SEQ = D.SEQ
	left join CISEAPP..OPE_PAT_REGISTER p on t.OPE_REG_ID = p.ID
	;
	--插入诊断明细表
 INSERT INTO [FGHIS5_ZY].[dbo].[手术_诊断明细表]
	([手术登记ID],[序号],[手术诊断ID],[登记类型],[诊断代码],[诊断名称],[备注],[状态])
	select 
	D.OPE_REGIST_ID [手术登记ID],
	D.SEQ [序号],
	D.DIA_CODE [手术诊断ID],
	0 [登记类型],
	D.DIA_CODE [诊断代码],
	D.DIA_NAME [诊断名称],
	D.REMARKS [备注],
	0 [状态]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_DIA_DETAIL D ON t.OPE_REG_ID = D.OPE_REGIST_ID 
	;
		
 	--插入手术排班表
	INSERT INTO [FGHIS5_ZY].[dbo].[手术_排班人员表]
	 ([排班人员ID],[手术登记ID],[人员工号],[手术角色ID],[操作时间],[操作人],[备注])
	 SELECT
	 t.ID [排班人员ID],
	 t.OPE_REG_ID [手术登记ID],
	 t.OPERATE_NO [人员工号],
	 t.ROLE_ID [手术角色ID],
	 GETDATE() [操作时间],
	 t.CREATE_ID [操作人],
	 t.remarks [备注]
	 from #TEMP_OPE_PERSON_NEW t
	 where t.OPERATE_NO is not null
	;
	
	--插入手术_流程记录表
	INSERT INTO [FGHIS5_ZY].[dbo].[手术_流程记录表](
	[手术登记ID],[操作类型],[操作时间],[操作ID],[备注],[最后操作])
	select
	t.OPE_REG_ID [手术登记ID],
	'申请' [操作类型],
	GETDATE() [操作时间],
	P.CREATE_ID [操作ID],
	'' [备注],
	1 [最后操作]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID
	;
	    --插入手术同步记录表
	    INSERT INTO CISEAPP..OPE_PAT_REG_RECORD
	    select OPE_REG_ID,ADVICE_ID,INP_ID,APPLY_TIME,@Start_date,SEQ
	    from #TEMP_ADVICE t where not exists(select * from CISEAPP..OPE_PAT_REG_RECORD r where r.OPE_REG_ID=t.OPE_REG_ID and r.SEQ = t.SEQ)

	
	
	  IF @@ROWCOUNT=0 AND @@ERROR = 0 GOTO ERR
	    COMMIT TRAN 
		DROP TABLE #TEMP_ADVICE_NEW
		DROP TABLE #TEMP_OPE_PERSON_NEW
  RETURN(0) 
ERR:
  ROLLBACK TRAN
  RAISERROR('保存手术申请数据失败！',1,2) WITH NOWAIT 
 
  RETURN(-1)
END
go

