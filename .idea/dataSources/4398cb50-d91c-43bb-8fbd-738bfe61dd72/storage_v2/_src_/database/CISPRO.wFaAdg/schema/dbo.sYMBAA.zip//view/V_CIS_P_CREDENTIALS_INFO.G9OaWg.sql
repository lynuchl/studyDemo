-- dbo.V_CIS_P_CREDENTIALS_INFO source

CREATE VIEW dbo.V_CIS_P_CREDENTIALS_INFO
AS
SELECT null AS id,
       T.PATIENT_ID AS outp_no,
       null AS credentials_type,
       null AS credentials_name,
       T.ID_NO AS credentials_number,
       null AS remarks,
       T.OPERATOR AS create_name,
       T.CREATE_DATE AS create_date,
       (CASE
         WHEN t.VIP_INDICATOR = 1 THEN
          0
         WHEN t.VIP_INDICATOR = 0 THEN
          1
       END) AS state
  FROM DBLINK_HISPRODEV..MEDREC.PAT_MASTER_INDEX T;
go

