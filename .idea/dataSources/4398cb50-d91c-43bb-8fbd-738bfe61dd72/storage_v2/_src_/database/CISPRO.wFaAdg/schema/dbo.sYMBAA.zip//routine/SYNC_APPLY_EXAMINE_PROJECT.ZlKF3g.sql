-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-申请检验项目表(APPLY_EXAMINE_PROJECT)
-- Description:	 通过作业定时去同步his中新增或者修改的申请检验项目表
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_EXAMINE_PROJECT]
	 
AS
BEGIN   

      merge ciseapp..APPLY_EXAMINE_PROJECT as A
	  using(
			select t.项目id id, 
					a.类别ID category_id, 
					c.标本id specimen_id, 
					t.项目id med_advice_id, 
					t.医嘱名称 med_advice_name, 
					t.费用类别 fee_type, 
					t.费用id fee_id, 
					t.费用代码 fee_code, 
					t.数量 count, 
					t.检验描述 examine_describe, 
					t.绑定标志 bind_flag, 
					t.禁用 enabled, 
					(case when t.使用标志='全院' then 0 when t.使用标志='门诊' then 1 when t.使用标志='住院' then 2  end) used_flag, 
					t.单选标志 single_type, 
					t.预计报告时间 report_time, 
					t.加急标志 urgent_flag, 
					t.输入码 input_code, 
					t.输入码2 five_strokes_code, 
					(case when t.性别限制='不限制' then '0' when t.性别限制='男' then '1' when t.性别限制='女' then '2' end) sex_limit, 
					t.地址 inspect_addr, 
					t.仅急诊可用 only_emergency_treatment, 
					null mutex_item, 
					t.限制科室 limit_dept,
					NULL compose_seq, 
					t.备注 remarks, 
					-1 create_id, 
					getdate() create_date, 
					null update_id, 
					null update_date, 
					71 dept_id,   ----需要取对应的检验科室
					null examine_requirement, 
					t.显示序号 seq, 
					'10001' org_id,t.医嘱代码 MED_ADVICE_CODE from fghis5_mz.dbo.代码_申请检验项目表 t
					left join  fghis5_mz.dbo.代码_申请检验类别表 a on t.类别代码=a.类别代码
					--left join  fghis5_mz.dbo.代码_申请检验项目表 b on t.医嘱代码=b.互斥项目 and len(t.互斥项目)>0
					left join fghis5_mz.dbo.代码_申请检验标本表 c on t.标本代码=c.标本代码
			)B ON A.id=B.id  
			when matched then 
			update set a.count=b.count ,a.examine_describe=b.examine_describe,a.bind_flag=b.bind_flag,a.enabled=b.enabled
			,a.used_flag=b.used_flag, 
					a.single_type=b.single_type,  
					a.urgent_flag=b.urgent_flag, 
					a.sex_limit=b.sex_limit
			when not matched then 
			INSERT (ID
					,CATEGORY_ID
					,SPECIMEN_ID
					,MED_ADVICE_ID
					,MED_ADVICE_NAME
					,FEE_TYPE
					,FEE_ID
					,FEE_CODE
					,COUNT
					,EXAMINE_DESCRIBE
					,BIND_FLAG
					,ENABLED
					,USED_FLAG
					,SINGLE_TYPE
					,REPORT_TIME
					,URGENT_FLAG
					,INPUT_CODE
					,FIVE_STROKES_CODE
					,SEX_LIMIT
					,INSPECT_ADDR
					,ONLY_EMERGENCY_TREATMENT
					,MUTEX_ITEM
					,LIMIT_DEPT
					,COMPOSE_SEQ
					,REMARKS
					,CREATE_ID
					,CREATE_DATE
					,UPDATE_ID
					,UPDATE_DATE
					,DEPT_ID
					,EXAMINE_REQUIREMENT
					,SEQ
					,ORG_ID
					,MED_ADVICE_CODE) 
				values(b.ID
					,b.CATEGORY_ID
					,b.SPECIMEN_ID
					,b.MED_ADVICE_ID
					,b.MED_ADVICE_NAME
					,b.FEE_TYPE
					,b.FEE_ID
					,b.FEE_CODE
					,b.COUNT
					,b.EXAMINE_DESCRIBE
					,b.BIND_FLAG
					,b.ENABLED
					,b.USED_FLAG
					,b.SINGLE_TYPE
					,b.REPORT_TIME
					,b.URGENT_FLAG
					,b.INPUT_CODE
					,b.FIVE_STROKES_CODE
					,b.SEX_LIMIT
					,b.INSPECT_ADDR
					,b.ONLY_EMERGENCY_TREATMENT
					,b.MUTEX_ITEM
					,b.LIMIT_DEPT
					,b.COMPOSE_SEQ
					,b.REMARKS
					,b.CREATE_ID
					,b.CREATE_DATE
					,b.UPDATE_ID
					,b.UPDATE_DATE
					,b.DEPT_ID
					,b.EXAMINE_REQUIREMENT
					,b.SEQ
					,b.ORG_ID
					,b.MED_ADVICE_CODE)	  ; 	
 
END


go

