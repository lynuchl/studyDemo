CREATE PROCEDURE [dbo].[ZY_DRUG_DISCHARGE_EDIT]
  @applyMQuantity AS decimal ,
  @status AS int ,
  @id AS bigint ,
  @type AS int 
AS
BEGIN
if @type = 0 begin
	update [DBLINK_HISPRODEV]..[HISPRO].[DRUG_DISCHARGE_TEMP] set APPLY_M_QUANTITY = @applyMQuantity where ID = @id;
	end;

	if @type = 1 begin
	update [DBLINK_HISPRODEV]..[HISPRO].[DRUG_DISCHARGE_TEMP] set STATUS = @status where ID = @id;
	end;
END
go

