
CREATE  proc [dbo].[BB_HS_BQCRYTJ](@CZLX CHAR(9)='',@RQ varchar(20),@SSBQ VARCHAR(10))                  

AS 

	if @CZLX = '入院'
		begin
			select 住院号,姓名,case when 性别 = '1' then '男' when 性别 = '2' then '女' end 性别,床位号
			,(select 科室名称 from fghis5.dbo.代码_科室信息表 where 科室id = 所属病区)所属病区
			,(select 科室名称 from fghis5.dbo.代码_科室信息表 where 科室id = 所属科室)所属科室 ,入院日期 操作日期
			from fghis5.dbo.住院_住院登记表 
			where 住院状态 = '2' and 入院日期 = @RQ AND 所属病区 = @SSBQ


		end
	else if @CZLX = '出院'
		begin
			select 住院号,姓名,case when 性别 = '1' then '男' when 性别 = '2' then '女' end 性别,床位号
			,(select 科室名称 from fghis5.dbo.代码_科室信息表 where 科室id = 所属病区)所属病区
			,(select 科室名称 from fghis5.dbo.代码_科室信息表 where 科室id = 所属科室)所属科室,出院日期 操作日期
			from fghis5.dbo.住院_住院登记表 
			where 住院状态 = '4' and 出院日期 = @RQ AND 所属病区 = @SSBQ
		end
go

