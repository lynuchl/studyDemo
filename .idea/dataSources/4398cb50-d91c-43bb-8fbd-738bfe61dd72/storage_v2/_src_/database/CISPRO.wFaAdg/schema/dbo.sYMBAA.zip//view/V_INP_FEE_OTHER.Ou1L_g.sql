CREATE VIEW dbo.V_INP_FEE_OTHER
AS
SELECT   费用ID, 住院ID, 附加ID, 记帐代码, 床位号, 病区ID, 科室ID, 医生ID, 医嘱ID, 项目类别, 项目ID, 项目名称, 规格, 单位, 
                单价, 数量, 已退数量, 金额, 折扣比例, 折扣金额, 报销标志, 自理比例, 报销金额, 自理金额, 自费金额, 费用来源, 
                费用日期, 费用时间, 操作员ID, 操作工号, 操作姓名, 操作时间, 执行科室, 结算ID, 原费用ID, 状态, 校验码, 特殊标志, 
                包装量, 包装单位, 外键ID, 套餐ID, 核算人ID, 折扣备注, 上传标志, 检验组合ID, 检验组合代码, 检验组合名称, 批发价, 
                套餐登记ID, 登记明细ID, 套餐分类ID, 操作科室, 特殊组套编号, 开单科室
FROM      OPENQUERY([DBLINK_HISPRODEV], 
                'SELECT  id as 费用ID, inp_id as 住院ID, ADDITIONAL_ID as  附加ID, accounting_code as 记帐代码,BED_NO as 床位号, WARD_ID as 病区ID,DEPT_ID as 科室ID, 
DOCTOR_ID as 医生ID,ADVICE_ID as 医嘱ID, ITEM_CLASS as 项目类别,ITEM_ID as 项目ID, ITEM_NAME as 项目名称, null as 规格, PACKING_UNIT as 单位, 
               PRICE as 单价,QUANTITY as 数量,null as 已退数量, AMOUNT as 金额, DISCOUNT_RATE as 折扣比例,DISCOUNT_AMOUNT as 折扣金额,
               REIMBURSEMENT_FLAG as 报销标志,SELFCARE_RATIO as 自理比例,REIMBURSEMENT_AMOUNT as 报销金额, SELFCARE_AMOUNT as 自理金额, 
               OUTOFPOCKET_AMOUNT as 自费金额,EXPENSES_SOURCE as 费用来源, 
              EXPENSES_DATE as  费用日期,EXPENSES_TIME as 费用时间,OPERATE_ID as 操作员ID,OPERATE_NO as 操作工号,OPERATE_NAME as 操作姓名, 
              OPERATE_TIME as 操作时间, ACT_DEPT_ID as  执行科室,SETTLEMENT_ID as 结算ID,ORIGINAL_ID as  原费用ID,STATUS as 状态,null as 校验码,
              SPECIAL_SIGN as 特殊标志, 
              null as 包装量,PACKING_UNIT as 包装单位, EXTERNAL_ID as 外键ID,PACKAGE_REGISTRATION_ID as 套餐ID,ACCOUNTANT_ID as 核算人ID, 
              DISCOUNT_NOTES as 折扣备注, UPLOAD_FLAG as 上传标志,TEST_COMBINATION_ID as 检验组合ID,TEST_COMBINATION_CODE as 检验组合代码, 
              TEST_COMBINATION_NAME as 检验组合名称,WHOLESALE_PRICE as 批发价, 
             PACKAGE_REGISTRATION_ID as  套餐登记ID,PACKAGE_DETAIL_ID as 登记明细ID, PACKAGE_CLASS_ID as 套餐分类ID, OPERATE_DEPT_ID as 操作科室,
             SPECIAL_SET_NUM as  特殊组套编号,BILLING_DEPT_ID as 开单科室
FROM     hispro.NUR_COST')
                 AS derivedtbl_1
go

