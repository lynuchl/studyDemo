






CREATE VIEW [dbo].[V_DOC_DRUG_INDIC_INFO] AS
select t.药品代码 DRUG_CODE,t.药品名称 DRUG_NAME,1 IS_INDICATION, t.适应说明 REMARK  
from  fgpcdb.dbo.监控_适应症药品表 t

--select * from cisdoct..DOC_DRUG_INDIC_INFO

go

