CREATE PROCEDURE [dbo].[PUB_XT_GETSEED] (
    @type   VARCHAR(12), 
	@mc	    VARCHAR(12), 
	@lsh	Int OUTPUT,
	@count	    int=1 ) 
AS   
BEGIN   
 	set nocount on
 	if (ABS(isnull(@count,0))<=0)
 		set @count =1
     else
 	    set @count =ABS(@count)
 
 	IF @type in ('住院','手术')
 		begin
 			BEGIN TRAN
 				IF NOT EXISTS(SELECT * FROM CISPRO.dbo.住院_编码流水号  WHERE RTrim(分类)=@type AND  RTrim(名称) = @mc)
 					INSERT INTO CISPRO.dbo.住院_编码流水号(分类,名称,流水号,创建时间) VALUES (@type,@mc,0,getdate())
 
 				UPDATE CISPRO.dbo.住院_编码流水号 SET
 					流水号 = 流水号 + @count,更新时间=GETDATE()
 				WHERE RTrim(分类)=@type AND  RTrim(名称)=@mc
 
 				SELECT @lsh = 流水号
 				FROM CISPRO.dbo.住院_编码流水号
 				WHERE RTrim(分类)=@type AND  RTrim(名称)=@mc
 			COMMIT TRAN		
 		end
 

    --if (rtrim(ltrim(@type))='电子申请' and rtrim(ltrim(@mc))='医嘱编号')
      if @type='电子申请'
		begin 
       
			BEGIN TRAN
			UPDATE CISPRO.dbo.系统_编码流水号 SET 流水号=流水号+@count WHERE 分类=@type and 名称=@mc
			--IF @@ERROR <> 0 GOTO ERR
			SELECT @lsh=ISNULL(MAX(流水号),@count) FROM CISPRO.dbo.系统_编码流水号 with (nolock)  WHERE 分类=@type and 名称=@mc
			--IF @@ERROR <> 0 GOTO ERR
			COMMIT TRAN
			return
		end
      
	    -- select * from fghis5.dbo.系统_编码流水号
	   

 	return @lsh;

--select @lsh = NEXT VALUE FOR SEQ_ID_NUR_COST_TEMP;

--return @lsh;

END
go

