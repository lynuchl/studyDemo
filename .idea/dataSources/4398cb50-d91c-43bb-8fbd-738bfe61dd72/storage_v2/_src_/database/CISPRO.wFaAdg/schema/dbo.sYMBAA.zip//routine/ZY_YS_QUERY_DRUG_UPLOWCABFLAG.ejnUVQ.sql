CREATE PROCEDURE [dbo].[ZY_YS_QUERY_DRUG_UPLOWCABFLAG] AS
-- 医生站 查询所有药品上下柜状态

BEGIN

    --定义一个中间表，用于存放放回结果集
    DECLARE @temp_table TABLE
                        (
                            itemCode      varchar(50),
                            upLowCabFlag     varchar(2) --1-上柜 0-下柜
                        )

    insert into @temp_table
    select t.药品ID                                         itemCode,
           case when t.上柜状态 = '统一上' then '1' else '0' end upLowCabFlag
    from (
             select a.药品ID, a.上柜状态
             from [药品_基本信息住院视图] a
             union all
             select b.药品ID, b.上柜状态
             from [药品_基本信息门诊视图] b
         ) t
    group by t.药品ID, t.上柜状态;

    select * from @temp_table;

end ;
go

