-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步手术申请-部位表(OPE_POSITION)
-- Description:	 通过作业定时去同步his中新增或者修改的手术体位信息
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_OPE_POSITION]
	 
AS
BEGIN 
 
      merge ciseapp..OPE_POSITION as A
	  using(
			 select t.部位ID [POSITION_ID]
				  ,t.部位名称 [SCALE_NAME]
				  ,t.输入码1 [INPUT_CODE]
				  ,t.输入码2 [FIVE_STROKES]
				  ,0 [STATE]
				  ,t.备注 [REMARKS]
				  ,t.部位类型 [TYPE]
			   from [FGHIS5_ZY].[dbo].[手术_部位表] t where t.部位类型='体位'
			)B ON A.POSITION_ID=B.POSITION_ID
			when not matched then 
			INSERT ([POSITION_ID]
           ,[SCALE_NAME]
           ,[INPUT_CODE]
           ,[FIVE_STROKES]
           ,[STATE]
           ,[REMARKS]
           ,[TYPE]
           ,[CREATE_ID]
           ,[CREATE_DATE]
           ,[UPDATE_ID]
           ,[UPDATE_DATE]
           ,[ORG_ID]) 
		values(b.[POSITION_ID]
           ,b.[SCALE_NAME]
           ,b.[INPUT_CODE]
           ,b.[FIVE_STROKES]
           ,b.[STATE]
           ,b.[REMARKS]
           ,b.[TYPE]
           ,-1  
			,GETDATE() 
			,null  
			,null  
			,'10001' )	;

			update ciseapp..OPE_POSITION set STATE=1 where not exists(select * from [FGHIS5_ZY].[dbo].[手术_部位表] t where t.部位类型='体位' and t.部位id=POSITION_ID)
END


go

