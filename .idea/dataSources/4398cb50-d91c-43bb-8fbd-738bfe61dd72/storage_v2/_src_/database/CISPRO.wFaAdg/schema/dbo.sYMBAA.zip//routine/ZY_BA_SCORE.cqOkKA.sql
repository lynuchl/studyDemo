-- **********************************************************************************----    
--1)功能描述：病案首页质控评分
-- ********************************************************************************----

CREATE   procedure [dbo].[ZY_BA_SCORE](@BAID INT, @Dept INT) 
AS


declare @RYRQ varchar(30);
declare @CYRQ varchar(30);
declare @v_count INT;

begin

  begin

    --创建临时表 MRD_TEMP：存储校验
	CREATE TABLE #MRD_TEMP(
		mrd_regster_id INT,
        mrd_field varchar(50),
        is_must varchar(2),
        score numeric(4,1),
        description varchar(200)
	);

	--创建临时表 MRD_CLINICAL_REGSTER_TMP：临床_病史登记表
	select * into #MRD_CLINICAL_REGSTER_TMP from CISDOCT..mrd_clinical_regster WHERE mrd_regster_id=@BAID;

	--入院日期、出院日期赋值
	select @RYRQ= CONVERT(VARCHAR(8),INP_DAY,112),@CYRQ= CONVERT(VARCHAR(8),LEAVE_DATE,112) FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID   
    
    --创建临时表 MRD_CLINICAL_DIAGNOSIS_TMP：临床_病史诊断表
	select * into #MRD_CLINICAL_DIAGNOSIS_TMP from CISDOCT..mrd_clinical_diagnosis WHERE mrd_regster_id=@BAID;
    
    --创建临时表 MRD_CLINICAL_OPERATION_TMP：临床_病史手术表
	select * into #MRD_CLINICAL_OPERATION_TMP from CISDOCT..mrd_clinical_operation WHERE medical_record_id=@BAID;

  end;
  

  --医疗付款方式   
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(MEDICAL_MODE,'') NOT IN ('1','2','3','4','5','6','7','8','9'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
  VALUES(@BAID,'医疗付款方式','是',1,'【医疗付款方式】必须填写！并且取值范围为 1-9!')    
 END    
  
  --住院次数 
  IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INPAT_NUM,'')='')    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'住院次数','是',1,'【住院次数】不能为空，请填写！')    
  END   
  
  --病案号 
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(MRD_REGSTER_NO,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'病案号','是',1,'【病案号】不能为空，请填写！')    
 END   
  
  --姓名   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(NAME,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'姓名','是',1,'【姓名】不能为空，请填写！')    
 END  
  
  --性别  
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(GENDER,'') NOT IN ('1','2'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'性别','是',1,'【性别】不能为空，取值范围为 1，2，请填写！')    
 END  
  
  --出生日期   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(BIRTHDAY,'') ='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'出生日期','是',1,'【出生日期】不能为空，请填写！')    
 END   
  
  --年龄   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND     
  DATEDIFF(YEAR,CONVERT(VARCHAR(10),BIRTHDAY,23),CONVERT(VARCHAR(10),@RYRQ,23))>=1 AND ISNULL(AGE ,'')='' )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'年龄','是',1,'【年龄】>=1 岁时，年龄不能为空，请填写！')    
 END  
  
  --月龄   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND    
  DATEDIFF(YEAR,CONVERT(VARCHAR(10),BIRTHDAY,23),CONVERT(VARCHAR(10),@RYRQ,23))<1    
  AND ISNULL(NEWBORN_AGE,'')=''  )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'月龄','是',1,'【年龄】<1 岁时，不满一周岁年龄不能为空，请填写！')    
 END  
  
  --国籍   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID and (ISNULL(NATIONALITY,'') ='' or len(NATIONALITY)=1))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'国籍','是',1,'【国籍】不能为空，请填写！')    
 END 
  
  --出生地省   
     IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(BORN_PROVINCE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'出生地省','是',1,'【出生地省】不能为空，请填写！')    
 END  

  --出生地市
  IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(BORN_CITY,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'出生地市','是',1,'【出生地市】不能为空，请填写！')    
 END  
  
  --出生地县
  IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(BORN_REGION,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'出生地县','是',1,'【出生地县】不能为空，请填写！')    
 END  
  
  --籍贯省   
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(NATIVE_PROVINCE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'籍贯省','是',1,'【籍贯省】不能为空，请填写！')    
 END  
  
  --籍贯市
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(NATIVE_CITY,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'籍贯市','是',1,'【籍贯市】不能为空，请填写！')    
 END  
  
  --民族   
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(NATION,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'民族','是',1,'【民族】不能为空，请填写！')    
 END  
  
  --证件类型   
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(DOCUMENT_TYPE,0)=0)    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'证件类型','是',1,'【证件类型】不能为空，请填写！')    
 END  
  
  --身份证号长度   
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID and DOCUMENT_TYPE=1 AND (len(ID_NUM)>18 or isnull(ID_NUM,'')=''))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'身份证号','是',1,'【身份证号应为18位】，请填写！')    
 END    
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID and DOCUMENT_TYPE<>1 AND  isnull(ID_NUM,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'身份证号','是',1,'【身份证号】不能为空，请填写！')    
 END  
  
  --职业代码     
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(OCCUPATION_CODE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'职业','是',1,'【职业】不能为空，请填写！')    
 END 

  --婚姻状况代码   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(MARRIAGE,'')  NOT IN ('未婚','已婚','其他','离婚','丧偶'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'婚姻','是',1,'【婚姻】值域范围为 未婚,已婚,其他,离婚,丧偶，请规范填写！')    
 END   
  
  --现住址省 
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(HOME_PROVINCE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'现住址省','是',1,'【现住址省】不能为空，请填写！')    
 END 
  
  --现住址市  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(HOME_CITY,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'现住址市','是',1,'【现住址市】不能为空，请填写！')    
 END 

  --现住址县   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(BORN_REGION,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'现住址县','是',1,'【现住址县】不能为空，请填写！')    
 END 
  
  --现住址  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(HOME_ADDRESS,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'现住址','是',1,'【现住址】不能为空，请填写！')    
 END 
  
  --现住址电话   
/*  begin 
    execute immediate REGSTER_SQL || ' WHERE mrd_regster_id=:BAID AND HOME_TELEPHONE is null' into v_count using BAID;
    if v_count>0 then       
      execute immediate TEMP_SQL using BAID,'现住址电话','是',1,'【现住址电话】不能为空！'; 
    end if; 
  end;*/
  
  --现住址邮编   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(HOME_ZIP_CODE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'现住址邮编','是',0.5,'【现住址邮编】不能为空，请填写！')    
 END 
  
  --户口省  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(REGISTER_PROVINCE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'户口省','是',1,'【户口省】不能为空，请填写！')    
 END 
  
  --户口市   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(REGISTER_CITY,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'户口市','是',1,'【户口市】不能为空，请填写！')    
 END 
  
  --户口县   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(REGISTER_REGION,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'户口县','是',1,'【户口县】不能为空，请填写！')    
 END 
  
  --户口地址  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(REGISTER_ADDRESS,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'户口地址','是',1,'【户口地址】不能为空，请填写！')    
 END 
  
  --户口邮编   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(REGISTER_ZIP_CODE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'户口邮编','是',0.5,'【户口邮编】不能为空，请填写！')    
 END 
  
  --联系人姓名  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(CONTACT_NAME,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'联系人姓名','是',1,'【联系人姓名】不能为空，请填写！')    
 END 
  
  --联系人关系   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(CONTACT_RELATION,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'联系人关系','是',1,'【联系人关系】不能为空，请填写！')    
 END 
  
  --联系人电话   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(CONTACT_TELEPHONE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'联系人电话','是',1,'【联系人电话】不能为空，请填写！')    
 END 
  
  --单位邮编   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(UNIT_ZIP_CODE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'单位邮编','是',1,'【单位邮编】不能为空，请填写！')    
 END 
  
  --入院途径   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_WAY,'') NOT IN  ('1','2','3','9'))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'入院途径','是',0.5,'入院途径 值域范围 为 1，2，3，9 请规范填写！')    
 END   
  
  --入院时间   
        IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_DAY,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院时间','是',0.5,'【入院时间】不能为空，请填写！')    
 END 
  
  --出生日期和入院时间比较  
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND CONVERT(VARCHAR(8),BIRTHDAY,112)>CONVERT(VARCHAR(8),INP_DAY,112))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'入院日期','是',0,'【入院日期】应该大于出生日期！')    
 END  
  
  --入院时间和出院时间比较   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND CONVERT(VARCHAR(8),LEAVE_DATE,112)<CONVERT(VARCHAR(8),INP_DAY,112))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)  
   VALUES(@BAID,'出院日期','是',0,'【出院日期】应该大于等于入院日期！')    
 END  
  
  --入院时间 与出院时间 与入院后确诊日期  
   IF NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND CONVERT(VARCHAR(8),INP_MAKE_DATE,112)   
  BETWEEN CONVERT(VARCHAR(8),INP_DAY,112) AND CONVERT(VARCHAR(8),LEAVE_DATE,112))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)  
   VALUES(@BAID,'入院后确诊日期','是',0,'【入院后确诊日期】应该 在 入院日期与出院日期之间！')    
 END   
  
  --入院后确诊日期   
        IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_MAKE_DATE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院后确诊日期','是',0.5,'【入院后确诊日期】不能为空，请填写！')    
 END 
  
  --入院科别  
          IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_DEPT_ID,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院科别','是',0.5,'【入院科别】不能为空，请填写！')    
 END 
  
  --入院病区   
          IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_WARD_ID,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院病区','是',0.5,'【入院病区】不能为空，请填写！')    
 END 
  
  --转科科别   
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_TRANSFER_ID,'')=''  AND    
 ISNULL(INP_DEPT_ID,'')<>ISNULL(LEAVE_DEPT_ID,'') )    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'转科情况','是',0.5,' 存在转科情况，【转科情况】 不能为空！')    
 END    
  
  --出院时间   
          IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(LEAVE_DATE,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'出院时间','是',0.5,'【出院时间】不能为空，请填写！')    
 END 
  
  --出院科别  
          IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(LEAVE_DEPT_ID,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'出院科别','是',0.5,'【出院科别】不能为空，请填写！')    
 END 

  --实际住院天数   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND  INP_DAYS <>DATEDIFF(DAY,CONVERT(VARCHAR(10),INP_DAY,23) ,CONVERT(VARCHAR(10),LEAVE_DATE,23))    
  AND CONVERT(VARCHAR(10),INP_DAY,23) <> CONVERT(VARCHAR(10),LEAVE_DATE,23))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'住院天数','是',0.5,'【住院天数】 计算错误，请核对！')    
 END   
  
  --住院天数为 1 天情况
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND  convert(int,INP_DAYS) <>1    
  AND CONVERT(VARCHAR(10),INP_DAY,23) = CONVERT(VARCHAR(10),LEAVE_DATE,23))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'住院天数','是',0.5,'【住院天数】 计算错误 入院日期=出院日期 住院天数应该为 1 天，请核对！')    
 END    
  
  --诊断符合 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(OUTP_LEAVE,'') NOT IN ('0','1','2','3'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'门诊与出院','是',1,'【门诊与出院】 不能为空,值域范围为 0,1,2,3！')    
 END   
 
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_LEAVE,'') NOT IN ('0','1','2'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院与出院','是',1,'【入院与出院】 不能为空,值域范围为 0,1,2！')    
 END  
  
  --有无药物过敏 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(IS_DRUG_ALLERGY,'') NOT IN ('1','2'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'药物过敏','是',0.5,'【有无药物过敏】 不能为空,值域范围为 1,2！')    
 END  
  
  --过敏药物 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(IS_DRUG_ALLERGY,'') ='2')    
  AND EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(DRUG_ALLERGY,'') in('','-'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'过敏药物','是',0.5,'【有无药物过敏】 为 2 有，请填写 过敏药物！')    
 END   
  
  --再住院  
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(IS_AGAIN_INP,'') NOT IN ('1','2') )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'再住院','是',0.5,'再住院，不能为空，值域范围为 1,2！')    
 END    
  
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(IS_AGAIN_INP,'') ='2' and ISNULL(IS_AGAIN_INP_AIM,'')='')    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'再住院目的','是',0.5,'再住院计划为2（有） ，请填写再住院目的！')    
 END 

  --医师签名
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(SECTION_DIRECTOR_ID,0) =0 )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'科主任','是',0.5,'科主任，不能为空，请填写！(三级医院可由病区负责医师代签)')    
 END   
 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(CHIEF_DOCTOR_ID,0) =0 )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'主任医师','是',0.5,'主任医师，不能为空，请填写！')    
 END    

   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(ATTENDING_DOCTOR_ID,0) =0 )    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'主治医师','是',0.5,'主治医师，不能为空，请填写！')    
 END    

   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(HOSPITAL_DOCTOR_ID,0) =0 )    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'住院医师','是',0.5,'住院医师，不能为空，请填写！')    
 END    
  
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(RESP_NURSE_ID,0) =0 )    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'责任护士','是',0.5,'责任护士，不能为空，请填写！')    
 END    
  
  --抢救次数  成功次数  
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(SUCCESS_TIMES,0) >ISNULL(RESCUE_TIMES,0))    
  BEGIN    
    INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
    VALUES(@BAID,'成功次数','是',0.5,'成功次应该小于等于抢救次数 ！')    
  END    
  
  --离院方式  
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(LEAVE_MODE,'') NOT IN ('1','2','3','4','5','9') )    
   BEGIN    
     INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
     VALUES(@BAID,'离院方式','是',0.5,'离院方式，不能为空，值域范围为 1,2,3,4,5,9！')    
   END  
  
  --肿瘤诊断 肿瘤名称不能为空       
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID   AND (ISNULL(DIAGNOSIS_CODE,'') like 'C%' or ISNULL(DIAGNOSIS_CODE,'') like 'D1%' or ISNULL(DIAGNOSIS_CODE,'') like 'D2%' or ISNULL(DIAGNOSIS_CODE,'') like 'D3%' or ISNULL(DIAGNOSIS_CODE,'') like 'D4%' or ISNULL(DIAGNOSIS_CODE,'') like 'D0%') and isnull(TUMOR_NAME,'')=''  and DIAGNOSIS_TYPE not in (9,10) AND DIAGNOSIS_CLASS=1)  
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'肿瘤诊断名称','是',1,'【肿瘤名称】 不能为空！')    
 END 
  
  --门诊诊断名称 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='9' AND ISNULL(DIAGNOSIS_NAME,'')=''  )  OR   
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='9' )   
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'门急诊断名称','是',1,'【门急诊断名称】 不能为空！')    
 END    

   --门诊诊断编码
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='9' AND ISNULL(DIAGNOSIS_CODE,'')=''  )  OR  
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='9' )   
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'门急诊断编码','是',1,'【门急诊断编码】 不能为空！')    
 END 
  
  --入院诊断名称 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='10' AND ISNULL(DIAGNOSIS_NAME,'')=''  )   OR   
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='10' )   
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院诊断名称','是',1,'【入院诊断名称】 不能为空！')    
 END 
  
  --入院诊断编码
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='10' AND ISNULL(DIAGNOSIS_CODE,'')=''  )    
  OR NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='10' )   
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
  VALUES(@BAID,'入院诊断编码','是',1,'【入院诊断编码】 不能为空！')    
 END 
  
  --主要诊断名称 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1' AND ISNULL(DIAGNOSIS_NAME,'')='')  OR  
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1')  
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'主要诊断','是',2,'【主要诊断名称】 不能为空！') 
 END    
  
  --主要诊断编码
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1' AND ISNULL(DIAGNOSIS_CODE,'')=''  )  OR  
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1')  
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'主要诊断','是',2,'【主要诊断编码】 不能为空！') 
 END  
  
  --入院病情   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_CONDITION,'') NOT IN ('1','2','3','4') AND DIAGNOSIS_TYPE='1')  OR  
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1')  
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'主要诊断','是',1,'【入院病情】 不能为空！值域 范围为 1-4')  
 END 
  
  --出院情况   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(TREAT_RESULT,'') NOT IN ('1','2','3','4','5') AND DIAGNOSIS_TYPE='1')  OR  
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1')  
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'主要诊断','是',1,'【治疗结果】 不能为空！值域 范围为 1-5') 
 END  
  
  -----------------------------------------其它诊断 BEGIN--------------------------------------------------
  --诊断编码  
   SET @v_count=0  
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='2' AND ISNULL(DIAGNOSIS_CODE,'')='')  
 BEGIN    
   SET @v_count=(SELECT COUNT(1) FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='2' AND ISNULL(DIAGNOSIS_CODE,'')='')  
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'其他诊断','是',@v_count,'其他诊断【诊断编码】 不能为空！')   
 END  
  
  --诊断名称   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='2' AND ISNULL(DIAGNOSIS_NAME,'')='')   
 BEGIN    
   SET @v_count=(SELECT COUNT(1) FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='2' AND ISNULL(DIAGNOSIS_NAME,'')='')  
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)
   VALUES(@BAID,'其他诊断','是',@v_count,'其他诊断【诊断名称】 不能为空！')  
 END  
  
  --入院病情   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_CONDITION,'') NOT IN ('1','2','3','4') AND DIAGNOSIS_TYPE='2')   
 BEGIN    
   SET @v_count=(SELECT COUNT(1) FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(INP_CONDITION,'') NOT IN ('1','2','3','4') AND DIAGNOSIS_TYPE='2')  
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)  
   VALUES(@BAID,'其他诊断','是',@v_count,'其他诊断【入院病情】 不能为空！值域 范围为 1-4')    
 END  
  
  --出院情况   
   IF EXISTS (SELECT 1  FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(TREAT_RESULT,'') NOT IN ('1','2','3','4','5') AND DIAGNOSIS_TYPE='2')    
 BEGIN    
   SET @v_count=(SELECT COUNT(1)  FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(TREAT_RESULT,'') NOT IN ('1','2','3','4','5') AND DIAGNOSIS_TYPE='2')  
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)  
   VALUES(@BAID,'其他诊断','是',@v_count,'其他诊断【治疗结果】 不能为空！值域 范围 为 1-5')    
 END  
  
  --损伤中毒
  --诊断编码   
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1' AND LEFT(DIAGNOSIS_TYPE,3) BETWEEN 'S00' AND 'T98' )    
  AND NOT EXISTS(SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='5' AND LEFT(DIAGNOSIS_TYPE,1)  IN ('V','W','X','Y'))    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)  
  VALUES(@BAID,'损伤中毒编码','是',1,'主要诊断以 S00-T98 开头请输入损伤中毒诊断，损伤中中毒诊断以 V,W,X,Y 开头  不能为空！')    
 END 
  
  --诊断名称  
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='1' AND LEFT(DIAGNOSIS_CODE,3) BETWEEN 'S00' AND 'T98' )    
  AND   (EXISTS(SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='5' AND ISNULL(DIAGNOSIS_NAME,'') = '')    
  OR  NOT EXISTS(SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND DIAGNOSIS_TYPE='5'))  
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)   
  VALUES(@BAID,'损伤中毒名称','是',1,'主要诊断以 S00-T98 开头请输入损伤中毒诊断，请填写损伤中毒！')    
 END
  -----------------------------------------其它诊断 END--------------------------------------------------
  
  --尸检  
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(TREAT_RESULT,'') ='4' and SERIAL_NUM=1)    
  AND EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(IS_AUTOPSY,'')  NOT IN ('1','2'))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)   
   VALUES(@BAID,'尸检','是',0.5,'病人主要诊断为死亡，请填写是否尸检 ！')    
 END  

   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(TREAT_RESULT,'') <>'4' and SERIAL_NUM=1 and  DIAGNOSIS_TYPE='1')    
  AND EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(IS_AUTOPSY,'')  IN ('1','2'))    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)     
   VALUES(@BAID,'尸检','是',0.5,'病人主要诊断出院情况不是 【死亡】，不能填写尸检 ！')    
 END  
  
  --死亡病人 治疗结果判断
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(TREAT_RESULT,'') ='4' and SERIAL_NUM=1)    
  AND EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP WHERE mrd_regster_id=@BAID AND ISNULL(DIAGNOSIS_TYPE,'') ='2' AND ISNULL(TREAT_RESULT,'')<>'4')    
 BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)     
   VALUES(@BAID,'主要诊断','是',0.5,'病人主要诊断为死亡，其他诊断也必须是死亡，请检查其他诊断的出院情况 ！')    
 END  

   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(LEAVE_MODE,'') in ('2','3') and ISNULL(TRANS_RECEIVE_HOSPITAL,'') ='' )  AND  
  NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP where DIAGNOSIS_TYPE='1' and SERIAL_NUM=1 and ISNULL(TREAT_RESULT,'')='4')   
  BEGIN    
    INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)     
    VALUES(@BAID,'拟接收医疗机构名称','是',0.5,'离院方式为 2或3 ，请填写 病人转院接收医院！')    
  END   
  
  --判断 主要诊断治疗结果为 死亡时，离院方式 不等于 5 
   IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_DIAGNOSIS_TMP where mrd_regster_id=@BAID and DIAGNOSIS_TYPE='1' and SERIAL_NUM=1 and ISNULL(TREAT_RESULT,'')='4')   
    AND NOT EXISTS (SELECT 1 FROM #MRD_CLINICAL_REGSTER_TMP WHERE mrd_regster_id=@BAID AND ISNULL(LEAVE_MODE,'') ='5')    
  BEGIN    
    INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)     
    VALUES(@BAID,'离院方式','是',0,'病人主要诊断治疗结果为 4 （死亡） ，请填写 病人 离院方式为死亡 5 ！')    
  END   
  
  -------------------手术操作
  --手术编码   
    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(OPERATION_CODE,'') ='' )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'主要手术','是',2,'【手术编码】不能为空！')    
  END    
  
  --手术名称   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(OPERATION_NAME,'') ='' )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'主要手术','是',2,'【手术名称】不能为空！')    
  END    
  
  --手术开始时间  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(OPERATION_START_DATE,'') ='' )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'主要手术','是',1,'【手术开始时间】不能为空！')    
  END    

  --手术结束时间  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(OPERATION_STOP_DATE,'') ='' )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'主要手术','是',1,'【手术结束时间】不能为空！')    
  END    
  
  --手术级别   
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(OPERATION_LEVEL,'') ='' )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'主要手术','是',1,'【手术级别】不能为空！')    
  END    
  
  --主刀医师  
      IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(BUTCHER_PHYSICIAN,0) =0 )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description)    
   VALUES(@BAID,'主要手术','是',1,'【术者】不能为空！')    
  END    
  
 -- --切口等级   
  IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(INCISION_LEVEL,'') ='' AND ISNULL(REMARK,'')='手术' )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description) 
   VALUES(@BAID,'主要手术','是',1,'【切口等级】不能为空！')    
  END       
  
 -- --愈合级别   
  IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND SERIAL_NO=1 AND ISNULL(HEAL_LEVEL,'') ='' AND ISNULL(REMARK,'')='手术'  )    
  BEGIN    
   INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description) 
   VALUES(@BAID,'主要手术','是',1,'【愈合级别】不能为空！')    
  END      
  
 -- --手术日期逻辑性校验   
 IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND  CONVERT(VARCHAR(8),ISNULL(OPERATION_START_DATE,''),112) NOT BETWEEN @RYRQ AND @CYRQ )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description) 
  VALUES(@BAID,'主要手术','是',1,'手术开始时间应该介于 【入院日期】 与 【出院日期】 之间！')    
 END    

    IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID AND  CONVERT(VARCHAR(8),ISNULL(OPERATION_STOP_DATE,''),112) NOT BETWEEN @RYRQ AND @CYRQ )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description) 
  VALUES(@BAID,'主要手术','是',1,'手术结束时间应该介于 【入院日期】 与 【出院日期】 之间！')    
 END  
  
  IF EXISTS (SELECT 1 FROM #MRD_CLINICAL_OPERATION_TMP WHERE medical_record_id=@BAID  AND ISNULL(OPERATION_STOP_DATE,'1900-01-01 00:00:00.000') <=ISNULL(OPERATION_START_DATE,'1900-01-01 00:00:00.000') )    
 BEGIN    
  INSERT INTO #MRD_TEMP (mrd_regster_id,mrd_field,is_must,score,description) 
  VALUES(@BAID,'主要手术','是',1,'手术结束时间不能小于等于手术开始时间,请双击手术信息进行填写！')    
 END
  
  select mrd_regster_id,mrd_field,is_must,score,description from #MRD_TEMP;

end;
go

