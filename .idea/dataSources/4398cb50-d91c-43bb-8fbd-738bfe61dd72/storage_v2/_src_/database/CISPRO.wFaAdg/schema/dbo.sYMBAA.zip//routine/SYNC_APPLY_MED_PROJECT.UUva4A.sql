
-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-申请医技项目(APPLY_MED_PROJECT)
-- Description:	 通过作业定时去同步his中新增或者修改的申请医技项目
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_MED_PROJECT]
	 
AS
BEGIN

         declare @pos_num int
	    -----获取当前部位最大ID
	    select @pos_num= MAX(t.POSITION_ID) from ciseapp.dbo.APPLY_MED_POSITION t
	    -----获取当前部位信息
		select  t.检查部位 position_id,(case when t.申请分类=5 then '3' when t.申请分类=3 then '5' else t.申请分类 end)  apply_type
		  into #temp_position
	    from  fghis5_mz.dbo.代码_申请医技项目表 t group by t.检查部位,t.申请分类
      
	    

		 insert into ciseapp.dbo.APPLY_MED_POSITION
			select ROW_NUMBER() over(order by apply_type,position_id)+@pos_num position_id,null parent_id,null position_code,position_id position_name,cispro.dbo.[f_pinyin](position_id) input_code
			,0 seq ,apply_type,0 STATE,-1 create_id, 
			getdate() create_date, 
			null update_id, 
			null update_date, 
			'10001' org_id from #temp_position a 
			where len(a.position_id)>1 and not exists(select * from ciseapp.dbo.APPLY_MED_POSITION t where t.POSITION_NAME=a.position_id and t.TYPE=a.apply_type) ;



			select t.流水号 med_advice_id, 
			t.医嘱名称 med_advice_name, 
			null english_name, 
			t.科室id dept_id, 
			a.大类id category_id, 
			isnull(c.POSITION_ID,'999') subclass_id, 
			c.POSITION_ID position_id, ----由于暂无数据需要手动更新
			t.部位单选 position_single_choose, 
			isnull(t.仅急诊可用,0) emerge_only, 
			t.包含介质 contain_medium, 
			t.限制次数 limit_number, 
			0 enabled_modify_number, 
			'0'sex_limit, 
			t.禁用 enabled, 
			--(case when t.使用标志='全院' then '0' when t.使用标志='门诊' then '1' when t.使用标志='住院' then '2' end)used_flag, 
			0 used_flag, 
			t.检查要求 requirements, 
			t.检查描述 describe, 
			t.备注 remarks, 
			t.输入码1 input_code, 
			t.输入码2 five_strokes_code, 
			t.地址 inspect_addr, 
			(case when t.申请分类=5 then '3' when t.申请分类=3 then '5' else t.申请分类 end)  apply_type, 
			-1 create_id, 
			getdate() create_date, 
			null update_id, 
			null update_date, 
			null group_flag, 
			t.限制科室 limit_dept, 
			'10001' org_id, 
			t.医嘱显示序号 seq, 
			t.单次计费 multiple_bill, 
			null need_contrast_med, 
			null position_required, 
			null nation_subject_code, 
			t.医嘱代码 med_advice_code
			into #TEMP_PROJECT from  fghis5_mz.dbo.代码_申请医技项目表 t
			left join fghis5_mz.dbo.代码_申请医技大类表 a on t.分类代码=a.大类代码
			left join CISEAPP.dbo.APPLY_MED_POSITION c on t.检查部位=c.POSITION_NAME and c.TYPE=0;

			MERGE CISEAPP.DBO.APPLY_MED_PROJECT AS A
			USING(
			  SELECT * FROM #TEMP_PROJECT
			)B ON A.med_advice_id=B.med_advice_id
			WHEN MATCHED THEN 
			UPDATE SET a.med_advice_name=b.med_advice_name,update_date=getdate()
			when not matched then 
			INSERT ([MED_ADVICE_ID]
           ,[MED_ADVICE_NAME]
           ,[ENGLISH_NAME]
           ,[DEPT_ID]
           ,[CATEGORY_ID]
           ,[SUBCLASS_ID]
           ,[POSITION_ID]
           ,[POSITION_SINGLE_CHOOSE]
           ,[EMERGE_ONLY]
           ,[CONTAIN_MEDIUM]
           ,[LIMIT_NUMBER]
           ,[ENABLED_MODIFY_NUMBER]
           ,[SEX_LIMIT]
           ,[ENABLED]
           ,[USED_FLAG]
           ,[REQUIREMENTS]
           ,[DESCRIBE]
           ,[REMARKS]
           ,[INPUT_CODE]
           ,[FIVE_STROKES_CODE]
           ,[INSPECT_ADDR]
           ,[APPLY_TYPE]
           ,[CREATE_ID]
           ,[CREATE_DATE]
           ,[UPDATE_ID]
           ,[UPDATE_DATE]
           ,[GROUP_FLAG]
           ,[LIMIT_DEPT]
           ,[ORG_ID]
           ,[SEQ]
           ,[MULTIPLE_BILL]
           ,[NEED_CONTRAST_MED]
           ,[POSITION_REQUIRED]
           ,[NATION_SUBJECT_CODE]
           ,[MED_ADVICE_CODE]) 
		values(b.[MED_ADVICE_ID]
           ,b.[MED_ADVICE_NAME]
           ,b.[ENGLISH_NAME]
           ,b.[DEPT_ID]
           ,b.[CATEGORY_ID]
           ,b.[SUBCLASS_ID]
           ,b.[POSITION_ID]
           ,b.[POSITION_SINGLE_CHOOSE]
           ,b.[EMERGE_ONLY]
           ,b.[CONTAIN_MEDIUM]
           ,b.[LIMIT_NUMBER]
           ,b.[ENABLED_MODIFY_NUMBER]
           ,b.[SEX_LIMIT]
           ,b.[ENABLED]
           ,b.[USED_FLAG]
           ,b.[REQUIREMENTS]
           ,b.[DESCRIBE]
           ,b.[REMARKS]
           ,b.[INPUT_CODE]
           ,b.[FIVE_STROKES_CODE]
           ,b.[INSPECT_ADDR]
           ,b.[APPLY_TYPE]
           ,b.[CREATE_ID]
           ,b.[CREATE_DATE]
           ,b.[UPDATE_ID]
           ,b.[UPDATE_DATE]
           ,b.[GROUP_FLAG]
           ,b.[LIMIT_DEPT]
           ,b.[ORG_ID]
           ,b.[SEQ]
           ,b.[MULTIPLE_BILL]
           ,b.[NEED_CONTRAST_MED]
           ,b.[POSITION_REQUIRED]
           ,b.[NATION_SUBJECT_CODE]
           ,b.[MED_ADVICE_CODE] )	;


		   update CISEAPP.dbo.APPLY_MED_PROJECT set ENABLED=1 where not exists(select * from #TEMP_PROJECT t where t.med_advice_id=med_advice_id)



		   drop table #temp_position
		   drop table #TEMP_PROJECT
END
go

