





CREATE VIEW [dbo].[V_ELE_FILED_COLUMNS] AS

select 
'V_CIS_PATIENT_INFO' as tableName,
'基本信息' as tableNameDesc,
UPPER(c.[name]) columnName,
p.value as comments
from cispro.sys.views s 
inner join cispro.sys.syscolumns c on s.object_id=c.id
left join cispro.sys.sysindexkeys i on c.id=i.id and c.colid=i.colid
left join cispro.sys.extended_properties p on c.id=p.major_id and c.colid=p.minor_id
where s.[name] = 'V_CIS_PATIENT_INFO' and c.[name] not in ('id')

union all

SELECT
'CIS_HOSTPITAL_INFO' as tableName,
'住院' as tableNameDesc,
UPPER(c.[name]) columnName,
p.value as comments
from ciscomm.sys.tables s 
inner join ciscomm.sys.syscolumns c on s.object_id=c.id
left join ciscomm.sys.sysindexkeys i on c.id=i.id and c.colid=i.colid
left join ciscomm.sys.extended_properties p on c.id=p.major_id and c.colid=p.minor_id
WHERE s.[name] = 'CIS_HOSTPITAL_INFO'
and c.[name] not in ( 'ID','NAME','GENDER','BIRTHDAY','BLOOD_TYPE','WEIGHT','HEIGHT')


--union all
--select
--'V_OUTP_REGISTER_INFO' as tableName,
--'挂号' as tableNameDesc,
--c.[name] columnName,
--p.value as comments
--from ciscomm.sys.views s 
--inner join ciscomm.sys.syscolumns c on s.object_id=c.id
--left join ciscomm.sys.sysindexkeys i on c.id=i.id and c.colid=i.colid
--left join ciscomm.sys.extended_properties p on c.id=p.major_id and c.colid=p.minor_id
--WHERE s.[name] = 'V_OUTP_REGISTER_INFO'
--and c.[name] not in ( 'ID','NAME','SEX','BIRTHDAY','AGE')


union all

select
'OPE_HOS_OPEINFO' as tableName,
'手术' as tableNameDesc,
--c.[name],
lower(substring(c.[name],1,1)) + substring(REPLACE([dbo].[InitCap](c.[name]),'_',''),2,50) as columnName,
p.value as comments
from [CISEAPP].sys.tables s 
inner join [CISEAPP].sys.syscolumns c on s.object_id=c.id
left join [CISEAPP].sys.extended_properties p on c.id=p.major_id and c.colid=p.minor_id
where s.[name]='OPE_HOS_OPEINFO'
and c.[name] != 'ID'

go

