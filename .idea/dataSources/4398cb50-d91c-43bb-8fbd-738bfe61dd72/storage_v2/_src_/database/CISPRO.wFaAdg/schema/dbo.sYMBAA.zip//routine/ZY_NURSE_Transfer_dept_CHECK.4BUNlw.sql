CREATE PROCEDURE [dbo].[ZY_NURSE_Transfer_dept_CHECK](
    @inp_id varchar(50)) AS

-- 护士站 患者转科检查
BEGIN


    --定义中间表，有用存储返回结果集
    DECLARE @temp_table TABLE
                        (
                            typeName      varchar(200),
                            itemName      varchar(200),
                            deptName      varchar(200),
                            status        varchar(200),
                            operationTime datetime,
                            checkType     varchar(200)
                        )

    --查询当前患者附加id
    DECLARE @ADDITIONAL_ID varchar(200)
    select @ADDITIONAL_ID = t.ADDITIONAL_ID
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id

    --查询当前患者的住院id
    DECLARE @IN_HOSPITAL_ID varchar(200)
    select @IN_HOSPITAL_ID = t.IN_HOSPITAL_ID
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id


--校验是否是在病区状态
    DECLARE @CHKE1 INT
    select @CHKE1 = count(1)
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id
      and t.INP_STAT = '2'
    if @CHKE1 < 1
        begin
            insert into @temp_table (typeName, itemName, deptName, status, operationTime, checkType)
            values ('当前患者不是在病区状态，不能进行操作！', '', '', '', null, '');
        end

--校验是否存在包床
    DECLARE @CHKE2 INT
    select @CHKE2 = count(1)
    from CISCOMM..cis_hostpital_info i
             left join CISNURS..nur_hospital_beds b on i.id = b.hospital_id
             left join CISNURS..nur_beds_info t on b.beds_id = t.id
    where b.is_delete = '0'
      and t.using_state = '2'
      and i.inp_id = @inp_id
    if @CHKE2 > 0
        begin
            insert into @temp_table (typeName, itemName, deptName, status, operationTime, checkType)
            values ('存在包床，请先撤销包床！', '', '', '', null, '');
        end


    insert into @temp_table
        --未完全停止的医嘱
    select '[未完全停用的医嘱]: ' + adviceAttr.STATI_DETAIL_NAME typeName,
           advice.ADVICE_NAME                            itemName,
           dept.DEPT_NAME as                             deptName,
           status.STATI_DETAIL_NAME                      status,
           case
               when advice.status = 0 then ext.CREATE_DATE
               when advice.status = 1 then ext.ADV_SUBMIT_DATE
               when advice.status = 2 then ext.CONFIRM_DATE
               when advice.status = 3 then ext.EXECUTE_DATE
               else null end                             operationTime,
           ''             as                             checkType
    from CISDOCT..DOC_ADVICE advice
             inner join CISDOCT..DOC_ADVICE_EXTEND ext on advice.advice_id = ext.advice_id
             left join CISCOMM..AUTH_DEPT dept on ext.execute_dept_id = dept.id
             left join CISCOMM..code_reimburse_info reimburse
                       on advice.rmb_flag = CONVERT(varchar(2), reimburse.reimburse_code) and reimburse.state = 1
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT adviceAttr
                       ON adviceAttr.STATIC_CODE = 'adv_attr' AND
                          adviceAttr.STATI_DETAIL_CODE = convert(varchar, advice.ADVICE_ATTR)
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
                       ON status.STATIC_CODE = 'advice_status' AND status.STATI_DETAIL_CODE = advice.status
    where advice.INPAT_NO = @inp_id
      and ext.INPAT_NO = @inp_id
      and (advice.status in (1, 2, 3) or
           (advice.status = 6 and ext.STOP_DATE < getdate())) --0:暂存;1:提交;2:护士确认;3:护士执行;4:停止;5:全停;6:预停;7:护士停止确认;8:作废;9:护士作废确认;10:撤销

    union all


    --检查
    --明细状态 ：
    select '[未停止的电子申请]: ' + convert(varchar, apply_inspect_detail.APPLY_ID) + '检查' as typeName,
           apply_inspect_detail.MED_ADVICE_NAME                                    as itemName,
           AUTH_DEPT.dept_name                                                     as deptName,
           status.STATI_DETAIL_NAME                                                as status,
           apply_inspect_detail.update_date                                        as operationTime,
           ''                                                                      as checkType
    from CISEAPP..apply_inspect_detail apply_inspect_detail
             left join CISEAPP..apply_inspect_master apply_inspect_master
                       on apply_inspect_master.apply_id = apply_inspect_detail.apply_id
             left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_inspect_master.accept_dept_id = AUTH_DEPT.id
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
                       ON status.STATIC_CODE = 'inspect_status' AND
                          status.STATI_DETAIL_CODE = apply_inspect_detail.apply_state
    where apply_inspect_master.INP_ID = @inp_id
      and apply_inspect_detail.apply_state in (0, 7, 22) --0是新申请，7医技登记，22取消登记
      and apply_inspect_master.APPLY_STATE != 0         --排除主单暂存状态

    union all

    --检验
    --明细表状态：
    select distinct '[未停止的电子申请]: ' + convert(varchar, apply_examine_detail.apply_id) + '检验' as typeName,
                    apply_examine_detail.MED_ADVICE_NAME                                    as itemName,
                    AUTH_DEPT.dept_name                                                     as deptName,
                    status.STATI_DETAIL_NAME                                                as status,
                    apply_examine_detail.update_date                                        as operationTime,
                    ''                                                                      as checkType
    from CISEAPP..apply_examine_detail apply_examine_detail
             left join CISEAPP..APPLY_EXAMINE_MASTER APPLY_EXAMINE_MASTER
                       on APPLY_EXAMINE_MASTER.apply_id = apply_examine_detail.apply_id
             left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_examine_detail.excute_dept_id = AUTH_DEPT.id
             left join CISEAPP..apply_examine_compose apply_examine_compose
                       on apply_examine_compose.compose_id = apply_examine_detail.compose_id
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
                       ON status.STATIC_CODE = 'examine_status' AND
                          status.STATI_DETAIL_CODE = APPLY_EXAMINE_MASTER.apply_state
    where APPLY_EXAMINE_MASTER.INP_ID = @inp_id
      and apply_examine_detail.apply_state in (0, 23,24,17,27) --0 新申请，23 条码打印，24 撤销打印，17 标本采集，27 取消采集
      and APPLY_EXAMINE_MASTER.APPLY_STATE != 0 --排除主单暂存状态

--     union all

      --病理
      --病理状态配置,状态： 0暂存、1新申请、2护士确认、4科室接收、5科室取消（第三方回传）、6报告审核、7报告完成、8退费（仅门诊）、99作废
--     select '[未停止的电子申请]: ' + convert(varchar, apply_pathology_master.apply_id) + '病理' as typeName,
--            apply_pathology_detail.med_advice_name                                    as itemName,
--            AUTH_DEPT.dept_name                                                       as deptName,
--            status.STATI_DETAIL_NAME                                                  as status,
--            apply_pathology_master.update_date                                        as operationTime
--     from CISEAPP..apply_pathology_master apply_pathology_master
--              left join CISEAPP..apply_pathology_detail apply_pathology_detail
--                        on apply_pathology_master.apply_id = apply_pathology_detail.apply_id
--              left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_pathology_master.accept_dept_id = AUTH_DEPT.id
--              LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
--                        ON status.STATIC_CODE = 'pathology_status' AND
--                           status.STATI_DETAIL_CODE = apply_pathology_master.apply_state
--     where apply_pathology_master.INP_ID = @inp_id
--       and apply_pathology_master.apply_state in (1, 4, 6)

--     union all

--     --治疗
--     select '[未停止的电子申请]: ' + convert(varchar, apply_treatment_master.apply_id) + '治疗' as typeName,
--            apply_treatment_detail.med_advice_name                                    as itemName,
--            AUTH_DEPT.dept_name                                                       as deptName,
--            status.STATI_DETAIL_NAME                                                  as status,
--            apply_treatment_master.update_date                                        as operationTime
--     from CISEAPP..apply_treatment_master apply_treatment_master
--              left join CISEAPP..apply_treatment_detail apply_treatment_detail
--                        on apply_treatment_master.apply_id = apply_treatment_detail.apply_id
--              left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_treatment_master.accept_dept_id = AUTH_DEPT.id
--              LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
--                        ON status.STATIC_CODE = 'treatment_status' AND
--                           status.STATI_DETAIL_CODE = apply_treatment_master.apply_state
--     where apply_treatment_master.INP_ID = @inp_id
--       and apply_treatment_master.apply_state in (1, 2, 4, 8)
--
--     union all
-- 
-- 
--     --手术校验 ，走第三方his
--     select '[未停止的电子申请]: ' + convert(varchar, A.手术登记ID) + '手术' as typeName,
--            B.手术名称                                             as itemName,
--            ''                                                 as deptName,
--            case
--                when A.手术状态 = '0' then '申请'
--                when A.手术状态 = '1' then '排班'
--                when A.手术状态 = '2' then '登记'
--                when A.手术状态 = '3' then '审核'
--                when A.手术状态 = '4' then '术中'
--                when A.手术状态 = '5' then '完成'
--                when A.手术状态 = '6' then '记账'
--                when A.手术状态 = '8' then '归档'
--                when A.手术状态 = '9' then '入帐' end
--                                                               as status,
--            A.申请时间                                             as operationTime,
--            ''                                                    checkType
--     from FGHIS5.dbo.手术_登记表 A
--              JOIN FGHIS5.dbo.手术_手术明细表 B on A.手术登记ID = B.手术登记ID
--     where B.序号 = 1
--       AND A.登记部门 Like '手术%'
--       AND B.登记类型 = 0
--       AND 住院ID = @IN_HOSPITAL_ID
--       AND (@ADDITIONAL_ID = -1 or 附加ID = @ADDITIONAL_ID)
--       AND A.手术状态 NOT in (5, 7, 8)
--     union all
--     select '[未停止的电子申请]: ' + convert(varchar, A.手术登记ID) + '麻醉' as typeName,
--            B.手术名称                                             as itemName,
--            ''                                                 as deptName,
--            case
--                when A.手术状态 = '0' then '申请'
--                when A.手术状态 = '1' then '排班'
--                when A.手术状态 = '2' then '登记'
--                when A.手术状态 = '3' then '审核'
--                when A.手术状态 = '4' then '术中'
--                when A.手术状态 = '5' then '完成'
--                when A.手术状态 = '6' then '记账'
--                when A.手术状态 = '8' then '归档'
--                when A.手术状态 = '9' then '入帐' end                as status,
--            A.申请时间                                             as operationTime,
--            ''                                                    checkType
--     from FGHIS5.dbo.手术_登记表 A
--              JOIN FGHIS5.dbo.手术_手术明细表 B on A.手术登记ID = B.手术登记ID
--     where B.序号 = 1
--       AND A.登记部门 Like '%麻醉'
--       AND B.登记类型 = 0
--       AND 住院ID = @IN_HOSPITAL_ID
--       AND (@ADDITIONAL_ID = -1 or 附加ID = @ADDITIONAL_ID)
--       AND A.手术状态 NOT in (7)
--       AND A.麻醉状态 NOT in (5, 7, 8)

--     --手术
--     --手术状态配置, 状态：0暂存 1新申请 2-科主任审核 3登记 4排班 5记账 6入帐 7审核 8完成 10作废 11预约-1失效 12待审核
--        select '[未停止的电子申请]: ' + convert(varchar, ope_pat_register.id) + '手术' as typeName,
--            (stuff((select distinct ',' + T2.OPE_NAME
--                    FROM CISEAPP..ope_detail_info T2
--                    WHERE T2.ope_regist_id = ope_pat_register.id
--                    for xml path('')), 1, 1, ''))                         as itemName,
--            null                                                          as deptName,
--            status.STATI_DETAIL_NAME                                      as status,
--            ope_doc_register.update_date                                     operationTime
--     from CISEAPP..ope_pat_register ope_pat_register
--              left join CISEAPP..ope_doc_register ope_doc_register
--                        on ope_pat_register.id = ope_doc_register.ope_regist_id
--              left join CISCOMM..AUTH_DEPT AUTH_DEPT on ope_doc_register.dept_id = AUTH_DEPT.id
--              LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
--                        ON status.STATIC_CODE = 'ope_status' AND
--                           status.STATI_DETAIL_CODE = ope_pat_register.state
--     where INP_ID = @inp_id
--       and ope_pat_register.state in (1, 3, 4, 5, 7)

    union all

    --排药
    --排药
    select '[已排药申请]: ' + cast(t.ADVICE_ID as VARCHAR) typeName,
           t.drug_name as                             itemName,
           p.dept_name as                             deptName,
           '病区申请'      as                             status,
           t.gen_time  as                             operationTime,
           ''                                         checkType
    from CISPRO..V_DRUG_DISCHARGE_TEMP t
             left join CISDOCT..DOC_ADVICE d on t.advice_id = d.advice_id
             left join CISCOMM..AUTH_DEPT p on t.Pharmacy_Id = p.id
             left join CISCOMM..CIS_HOSTPITAL_INFO h on t.INP_ID = h.IN_HOSPITAL_ID
    where h.INP_ID = @inp_id
      and t.status = 0
      and t.DOC_TYPE = 0
      and t.APPLY_M_QUANTITY > 0

    union all
    --退药
    select '[已退药申请]: ' + cast(t.ADVICE_ID as VARCHAR) typeName,
           t.drug_name as                             itemName,
           p.dept_name as                             deptName,
           '病区申请'      as                             status,
           t.gen_time  as                             operationTime,
           ''                                         checkType
    from CISPRO..V_DRUG_DISCHARGE_TEMP t
             left join CISDOCT..DOC_ADVICE d on t.advice_id = d.advice_id
             left join CISCOMM..AUTH_DEPT p on t.Pharmacy_Id = p.id
             left join CISCOMM..CIS_HOSTPITAL_INFO h on t.INP_ID = h.IN_HOSPITAL_ID
    where h.INP_ID = @inp_id
      and t.status = 0
      and t.DOC_TYPE = 2
    union all

    --查询 提示有不在住院时间范围的费用

    select '[存在非住院时间范围的费用]： '                                                                              as typeName,
           a.ITEM_NAME                                                                                     as itemName,
           a.DEPT_NAME                                                                                     as deptName,
           '已计费'                                                                                           as status,
           convert(datetime,
                   FORMAT(CONVERT(bigint, a.EXPENSES_DATE + a.EXPENSES_TIME), '####-##-## ##:##:##'),
                   120)                                                                                    as operationTime,
           ''                                                                                                 checkType
    from (
             select t.INP_ID,
                    t.PATIENT_ID,
                    t.IN_HOSPITAL_ID,
                    t.ADVICE_ID,
                    t.DEPT_ID,
                    t.WARD_ID,
                    t.ADDITIONAL_ID,
                    t.STATUS,
                    t.EXPENSES_DATE,
                    t.EXPENSES_TIME,
                    dept.DEPT_NAME,
                    t.ITEM_NAME,
                    t.ITEM_CLASS,
                    t.ITEM_ID
             from CISPRO..V_INP_FEE_WASTE t
                      left join CISCOMM..CIS_HOSTPITAL_INFO t1
                                on t.INP_ID = t1.INP_ID

                      left join CISCOMM..AUTH_DEPT dept on t.DEPT_ID = dept.ID
             where t.IN_HOSPITAL_ID = @IN_HOSPITAL_ID
               and (
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t.EXPENSES_DATE + t.EXPENSES_TIME), '####-##-## ##:##:##'), 120)
                         <
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t1.INP_TIME), '####-##-## ##:##:##'), 120)
                     or
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t.EXPENSES_DATE + t.EXPENSES_TIME), '####-##-## ##:##:##'), 120)
                             > getdate()
                 )
               and t.STATUS in (1,2)
             group by t.INP_ID, t.PATIENT_ID, t.IN_HOSPITAL_ID, t.ADVICE_ID, t.DEPT_ID, t.WARD_ID, t.ADDITIONAL_ID,
                      t.STATUS, t.EXPENSES_DATE, t.EXPENSES_TIME, dept.DEPT_NAME, t.ITEM_NAME, t.ITEM_CLASS, t.ITEM_ID
             having sum(t.QUANTITY) > 0
         ) a
    select * from @temp_table;
end ;
go

