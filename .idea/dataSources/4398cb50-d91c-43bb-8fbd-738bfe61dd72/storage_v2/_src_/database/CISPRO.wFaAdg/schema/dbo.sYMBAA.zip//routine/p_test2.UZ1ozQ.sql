CREATE proc [dbo].[p_test2]
 
as
 
 
  --开启事务
 
  begin transaction
 
    INSERT INTO FGHIS5.DBO.AAAAA(TI) VALUES('AAA');
	--INSERT INTO [192.168.8.13].FGHIS5.DBO.aaa VALUES(1);
 
 
    commit transaction

go

