
-- **********************************************************************************----    
--1)功能描述：CIS住院医生，开立的医技医嘱，将数据插入至HIS申请单表中
--由于目前无法与第三检验直接对接，所以才采用当前这模式，将数据插入至HIS申请单表中
-- ********************************************************************************----
CREATE   PROCEDURE [dbo].[SYNC_APPLY_EXAMINE_MASTER]
(@v_inpatno varchar(20), @v_apply_id INT) 
AS
begin

begin tran
 INSERT INTO [FGHIS5_MZ].dbo.申请_检验申请单([申请单号]
           ,[病人类型]
           ,[门诊号]
           ,[住院号]
           ,[姓名]
           ,[性别]
           ,[年龄]
           ,[记帐代码]
           ,[就诊ID]
           ,[挂号代码]
           ,[所属病区]
           ,[所属科室]
           ,[床位号]
           ,[结账ID]
           ,[处方ID]
           ,[申请日期]
           ,[申请时间]
           ,[申请ID]
           ,[申请工号]
           ,[费用状态]
           ,[申请状态]
           ,[备注]
           ,[住院ID]
           ,[附加ID]
           ,[医嘱ID])

SELECT T.APPLY_ID 申请单号
      ,T.PATIENT_TYPE 病人类型
      ,T.PATIENT_ID 门诊号
      ,T.INP_ID 住院号
      ,A.NAME 姓名
      ,(CASE WHEN A.GENDER=1 THEN '男' 
		     WHEN A.GENDER=2 THEN '女'
	     ELSE '未说明的性别' END) 性别
      ,A.INP_AGE 年龄
      ,A.ACCOUNT_CODE 记帐代码
      ,0 就诊ID
      ,0 挂号代码
      ,A.WARD_ID 所属病区
      ,A.DEPT_ID 所属科室
      ,A.BED_NO 床位号
      ,0 结账ID
      ,0 处方ID
      ,CONVERT(varchar(8),t.APPLY_TIME,112) 申请日期
      ,replace(CONVERT(varchar(8),t.APPLY_TIME,108),':','') 申请时间
      ,T.APPLY_ID 申请ID
      ,B.OPERATE_NO 申请工号
      ,T.CHARGE_STATE 费用状态
     ------HIS医技申请状态： 新申请 = 0,预约 = 1,病区取消 = 2,科室取消 = 3,科室确认病区取消 = 4,科室接收 = 5,科室完成 = 6,报告修改 = 7,报告完成 = 8
	 ------CIS医技申请状态：申请状态： 0暂存、1新申请、2护士确认、3条码打印（护士打印）、4标本接收(接收)（第三方回传）、5科室取消（第三方回传）、6报告审核、7报告完成、99作废、8退费（仅门诊）
      ,(case when t.APPLY_STATE='1' then '0'
			when t.APPLY_STATE IN('2','3','4') then '5'
			when t.APPLY_STATE='5' then '3'
			when t.APPLY_STATE='6' then '6'
			when t.APPLY_STATE='7' then '8'
	  END) 申请状态 
      ,T.REMARKS 备注
      ,A.IN_HOSPITAL_ID 住院ID
      ,A.ADDITIONAL_ID 附加ID
      ,NULL 医嘱ID FROM CISEAPP..APPLY_EXAMINE_MASTER T 
	  INNER JOIN CISCOMM..CIS_HOSTPITAL_INFO A ON T.INP_ID=A.INP_ID
	  LEFT JOIN CISCOMM..AUTH_OPERATOR B ON T.CREATE_ID=B.ID 
	  WHERE T.APPLY_ID=@v_apply_id AND T.INP_ID=@v_inpatno ;


INSERT INTO [FGHIS5_MZ].[dbo].[申请_检验申请单明细]
           ([申请单号]
           ,[申请序号]
           ,[处方ID]
           ,[类别代码]
           ,[组合代码]
           ,[组合名称]
           ,[医嘱代码]
           ,[医嘱名称]
           ,[费用ID]
           ,[费用类别]
           ,[费用代码]
           ,[单价]
           ,[数量]
           ,[金额]
           ,[标本类型]
           ,[费用状态]
           ,[申请状态]
           ,[备注]
           ,[医嘱ID]
           ,[登记明细ID]
           ,[套餐分类ID]
           ,[地址])	  
select T.APPLY_ID 申请单号
      ,T.APPLY_SEQ 申请序号
      ,0 处方ID
      ,D.CATEGORY_CODE 类别代码
      ,E.COMPOSE_CODE 组合代码
      ,E.COMPOSE_NAME 组合名称
      ,A.MED_ADVICE_CODE 医嘱代码
      ,T.MED_ADVICE_NAME 医嘱名称
      ,A.FEE_ID 费用ID
      ,A.FEE_TYPE 费用类别
      ,A.FEE_CODE 费用代码
      ,T.PRICE 单价
      ,T.COUNT 数量
      ,T.AMOUNT 金额
      ,B.SPECIMEN_CODE 标本类型
      ,t.CHARGE_STATE 费用状态  ------his费用状态： 初始 = 0,已收费 = 1,退费 = 2

------HIS医技申请状态： 新申请 = 0,预约 = 1,病区取消 = 2,科室取消 = 3,科室确认病区取消 = 4,科室接收 = 5,科室完成 = 6,报告修改 = 7,报告完成 = 8
------CIS医技申请状态：申请状态： 0暂存、1新申请、2护士确认、3条码打印（护士打印）、4标本接收(接收)（第三方回传）、5科室取消（第三方回传）、6报告审核、7报告完成、99作废、8退费（仅门诊）
      ,(case when t.APPLY_STATE='1' then '0'
			when t.APPLY_STATE IN('2','3','4') then '5'
			when t.APPLY_STATE='5' then '3'
			when t.APPLY_STATE='6' then '6'
			when t.APPLY_STATE='7' then '8'
	  END) 申请状态    
      ,T.REMARKS 备注
      ,C.TEAM_ID 医嘱ID
      ,0 登记明细ID
      ,0 套餐分类ID
      ,NULL 地址 from CISEAPP..APPLY_EXAMINE_DETAIL T
	  INNER JOIN CISEAPP..APPLY_EXAMINE_MASTER C ON T.APPLY_ID=C.APPLY_ID
	  LEFT JOIN CISEAPP..APPLY_EXAMINE_PROJECT A ON T.MED_ADVICE_ID=A.ID
	  LEFT JOIN CISEAPP..APPLY_EXAMINE_SPECIMEN B ON T.SPECIMEN_ID=B.SPECIMEN_ID
	  LEFT JOIN CISEAPP..APPLY_EXAMINE_CATEGORY D ON T.CATEGORY_ID=D.CATEGORY_ID
	  LEFT JOIN CISEAPP..APPLY_EXAMINE_COMPOSE E ON T.COMPOSE_ID=E.COMPOSE_ID
	  where T.APPLY_ID=@v_apply_id ;



   IF @@ROWCOUNT=0 AND @@ERROR = 0 GOTO ERR
	    COMMIT TRAN 
  RETURN(0) 
ERR:
  ROLLBACK TRAN
  RAISERROR('保存检验申请数据失败！',1,2) WITH NOWAIT 
  RETURN(-1)
END
go

