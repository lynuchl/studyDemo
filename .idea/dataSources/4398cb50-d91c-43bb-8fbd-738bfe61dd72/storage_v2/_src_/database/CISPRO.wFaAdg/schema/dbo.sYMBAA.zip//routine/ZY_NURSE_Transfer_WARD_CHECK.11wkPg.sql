CREATE PROCEDURE [dbo].[ZY_NURSE_Transfer_WARD_CHECK](
    @inp_id varchar(50)) AS
-- 护士站 患者转区检查


BEGIN


    --定义中间表，有用存储返回结果集
    DECLARE @temp_table TABLE
                        (
                            typeName      varchar(200),
                            itemName      varchar(200),
                            deptName      varchar(200),
                            status        varchar(200),
                            operationTime datetime,
                            checkType     varchar(200)
                        )


    --查询当前患者的住院id
    DECLARE @IN_HOSPITAL_ID varchar(200)
    select @IN_HOSPITAL_ID = t.IN_HOSPITAL_ID
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id

--校验是否是在病区状态
    DECLARE @CHKE1 INT
    select @CHKE1 = count(1)
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id
      and t.INP_STAT = '2'
    if @CHKE1 < 1
        begin
            insert into @temp_table (typeName, itemName, deptName, status, operationTime, checkType)
            values ('当前患者不是在病区状态，不能进行操作！', '', '', '', null, '');
        end

--校验是否存在包床
    DECLARE @CHKE2 INT
    select @CHKE2 = count(1)
    from CISCOMM..cis_hostpital_info i
             left join CISNURS..nur_hospital_beds b on i.id = b.hospital_id
             left join CISNURS..nur_beds_info t on b.beds_id = t.id
    where b.is_delete = '0'
      and t.using_state = '2'
      and i.inp_id = @inp_id
    if @CHKE2 > 0
        begin
            insert into @temp_table (typeName, itemName, deptName, status, operationTime, checkType)
            values ('存在包床，请先撤销包床！', '', '', '', null, '');
        end


    insert into @temp_table
        --排药
    select '[已排药申请]: ' + t.export_doc_no typeName,
           d.advice_name as              itemName,
           p.dept_name   as              deptName,
           '病区申请'        as              status,
           t.gen_time    as              operationTime,
           ''            as              checkType
    from CISNURS..NUR_DRUG_DISCHARGE t
             left join CISDOCT..DOC_ADVICE d on t.advice_id = d.advice_id
             left join CISCOMM..AUTH_DEPT p on t.dept_id = p.id
    where t.inp_id = @inp_id
      and t.status = 0
      and t.DOC_TYPE = 0

    union all
    --退药
    select '[已退药申请]: ' + t.export_doc_no typeName,
           d.advice_name as              itemName,
           p.dept_name   as              deptName,
           '病区申请'        as              status,
           t.gen_time    as              operationTime,
           ''            as              checkType
    from CISNURS..NUR_DRUG_DISCHARGE t
             left join CISDOCT..DOC_ADVICE d on t.advice_id = d.advice_id
             left join CISCOMM..AUTH_DEPT p on t.dept_id = p.id
    where t.inp_id = @inp_id
      and t.status = 0
      and t.DOC_TYPE = 2

    union all

    --存在非住院时间范围的费用
    select '[存在非住院时间范围的费用]： '                                                                              as typeName,
           a.ITEM_NAME                                                                                     as itemName,
           a.DEPT_NAME                                                                                     as deptName,
           '已计费'                                                                                           as status,
           convert(datetime,
                   FORMAT(CONVERT(bigint, a.EXPENSES_DATE + a.EXPENSES_TIME), '####-##-## ##:##:##'),
                   120)                                                                                    as operationTime,
           ''                                                                                                 checkType
    from (
             select t.INP_ID,
                    t.PATIENT_ID,
                    t.IN_HOSPITAL_ID,
                    t.ADVICE_ID,
                    t.DEPT_ID,
                    t.WARD_ID,
                    t.ADDITIONAL_ID,
                    t.STATUS,
                    t.EXPENSES_DATE,
                    t.EXPENSES_TIME,
                    dept.DEPT_NAME,
                    t.ITEM_NAME,
                    t.ITEM_ID,
                    t.ITEM_CLASS
             from CISPRO..V_INP_FEE_WASTE t
                      left join CISCOMM..CIS_HOSTPITAL_INFO t1
                                on t.INP_ID = t1.INP_ID
                      left join CISCOMM..AUTH_DEPT dept on t.DEPT_ID = dept.ID
             where t.IN_HOSPITAL_ID = @IN_HOSPITAL_ID
               and (
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t.EXPENSES_DATE + t.EXPENSES_TIME), '####-##-## ##:##:##'), 120)
                         <
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t1.INP_TIME), '####-##-## ##:##:##'), 120)
                     or
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t.EXPENSES_DATE + t.EXPENSES_TIME), '####-##-## ##:##:##'), 120)
                             > getdate()
                 )
               and t.STATUS =1
             group by t.INP_ID, t.PATIENT_ID, t.IN_HOSPITAL_ID, t.ADVICE_ID, t.DEPT_ID, t.WARD_ID, t.ADDITIONAL_ID,
                      t.STATUS, t.EXPENSES_DATE, t.EXPENSES_TIME, dept.DEPT_NAME, t.ITEM_NAME, t.ITEM_ID,
                      t.ITEM_CLASS
             having sum(t.QUANTITY) > 0
         ) a

    select * from @temp_table;
end ;
go

