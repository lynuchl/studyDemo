CREATE PROCEDURE [dbo].[SYNC_OPERATION_MASTER_NEW]
(@v_inpatno varchar(20), @v_ope_register_id INT) 
AS
BEGIN
	-- routine body goes here, e.g.
	-- SELECT 'Navicat for SQL Server'
	declare @person_num int,@person_count int
	DECLARE @Start_date DATE,@End_date date
  set @Start_date=convert(varchar(10),GETDATE(),120)
  set @End_date=convert(varchar(10),GETDATE()+1,120)
	set @person_num=0
  set @person_count=1
	
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_ADVICE_GROUP'))
begin
	DROP TABLE #TEMP_ADVICE_GROUP;
	DROP TABLE #TEMP_OPE_PERSON_NEW;
end
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_ADVICE'))
   BEGIN
		DROP TABLE #TEMP_ADVICE;
   END
   else
   begin
       CREATE TABLE #TEMP_ADVICE (
						OPE_REG_ID numeric(20, 0) NULL,
						ADVICE_ID numeric(20, 0) NULL,
						INP_ID varchar(50) NULL,
						APPLY_TIME datetime NULL,
						SEQ numeric(20,0) NULL,
						PRESC_ID INT 
					)
					 
   end
	 
if exists(select * from tempdb..sysobjects where id=object_id('tempdb..#TEMP_OPE_PERSON'))
BEGIN
		DROP TABLE #TEMP_OPE_PERSON;
   END
   else
   begin
       CREATE TABLE #TEMP_OPE_PERSON (
						OPE_REG_ID numeric(20, 0) NULL,
						OPERATE_NO varchar(50) NULL,
						OPERATE_NAME varchar(50) NULL,
						ROLE_ID INT,
						ROLE_NAME varchar(50) NULL,
						CREATE_ID INT,
						ID INT
					)			 
   end


	  if @v_inpatno<>'' and @v_ope_register_id>0
	     begin
		   insert into #TEMP_ADVICE
			select B.ID OPE_REG_ID, T.ADVICE_ID,B.INP_ID,B.APPLY_TIME,D.SEQ,NULL PRESC_ID from CISDOCT..DOC_ADVICE_EXTEND t
			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
			INNER JOIN CISEAPP..OPE_PAT_REGISTER B ON T.EXTE_NUM=B.ID
			left join CISEAPP..OPE_DETAIL_INFO D ON B.ID = D.OPE_REGIST_ID
			where B.ID=@v_ope_register_id and a.INPAT_NO=@v_inpatno and (T.CONFIRM_DATE>=@Start_date and T.CONFIRM_DATE<@End_date) and t.EXTE_APP = '手术' AND A.STATUS IN(2,3,4,7) AND B.STATE in (1,2)
			and not exists(select * from CISEAPP..OPE_PAT_REG_RECORD r where r.OPE_REG_ID=B.ID and r.SEQ = D.SEQ);
         end
	   else
	     begin
		    insert into #TEMP_ADVICE
		      select B.ID OPE_REG_ID, T.ADVICE_ID,B.INP_ID,B.APPLY_TIME,D.SEQ,NULL PRESC_ID from CISDOCT..DOC_ADVICE_EXTEND t
			inner join CISDOCT..DOC_ADVICE A ON t.ADVICE_ID=A.ADVICE_ID
			INNER JOIN CISEAPP..OPE_PAT_REGISTER B ON T.EXTE_NUM=B.ID 
						left join CISEAPP..OPE_DETAIL_INFO D ON B.ID = D.OPE_REGIST_ID
			where (T.CONFIRM_DATE>=@Start_date and T.CONFIRM_DATE<@End_date) and t.EXTE_APP = '手术' AND A.STATUS IN(2,3,4,7) AND B.STATE in (1,2)
			and not exists(select * from CISEAPP..OPE_PAT_REG_RECORD r where r.OPE_REG_ID=B.ID and r.SEQ = D.SEQ);
		 end
	
		 
		   select DISTINCT OPE_REG_ID into #TEMP_ADVICE_GROUP from #TEMP_ADVICE
		 
		 ----组装手术排班人员表
		 INSERT into #TEMP_OPE_PERSON
		     SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
				 O.OPERATE_NAME OPERATE_NAME,
	       1 ROLE_ID,
				 '手术医生' ROLE_NAME,
	       p.CREATE_ID CREATE_ID,
				 NULL ID
	       from #TEMP_ADVICE_GROUP t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.KNIFE_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.KNIFE_ID = o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
				 O.OPERATE_NAME OPERATE_NAME,
	       4 ROLE_ID,
				 '第一助手' ROLE_NAME,
	       p.CREATE_ID CREATE_ID,
				 NULL ID
	       from #TEMP_ADVICE_GROUP t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.ONE_HELP_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.ONE_HELP_ID= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
				 O.OPERATE_NAME OPERATE_NAME,
	       5 ROLE_ID,
				 '第二助手' ROLE_NAME,
	       p.CREATE_ID CREATE_ID,
				 NULL ID
	       from #TEMP_ADVICE_GROUP t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.SECOND_HELP_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.SECOND_HELP_ID= o.ID
				 union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
				 O.OPERATE_NAME OPERATE_NAME,
	       6 ROLE_ID,
				 '第三助手' ROLE_NAME,
	       p.CREATE_ID CREATE_ID,
				 NULL ID
	       from #TEMP_ADVICE_GROUP t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.THIRD_HELP_ID > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.THIRD_HELP_ID= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
				 O.OPERATE_NAME OPERATE_NAME,
	       7 ROLE_ID,
				 '巡回护士' ROLE_NAME,
	       p.CREATE_ID CREATE_ID,
				 NULL ID
	       from #TEMP_ADVICE_GROUP t
	       left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID and p.TOUR_NURSE > 0
	       left join CISCOMM..AUTH_OPERATOR o on p.TOUR_NURSE= o.ID
	       union
	       SELECT
	       t.OPE_REG_ID,
	       O.OPERATE_NO OPERATE_NO,
				 O.OPERATE_NAME OPERATE_NAME,
	       2 ROLE_ID,
				 '麻醉医生' ROLE_NAME,
	       p.CREATE_ID CREATE_ID,
				 NULL ID
	       from #TEMP_ADVICE_GROUP t
	       left join CISEAPP..OPE_ANESTHESIA_REGIST p ON t.OPE_REG_ID = p.OPE_REGIST_ID and p.DOCTOR_ID > 0
				 left join CISEAPP..OPE_PAT_REGISTER r ON t.OPE_REG_ID = r.ID
	       left join CISCOMM..AUTH_OPERATOR o on p.DOCTOR_ID= o.ID
				 
				 -----手术排班人员表取种子
				 select @person_count=count(0) from #TEMP_OPE_PERSON
   		 if @person_count>0
		 begin
		       BEGIN TRAN
					 UPDATE [FGHIS5].[dbo].[系统_编码流水号] SET 流水号=流水号+@person_count WHERE 分类='新手术管理' and 名称='手术_手术排班ID'
					--IF @@ERROR <> 0 GOTO ERR
					SELECT @person_num=ISNULL(MAX(流水号),@person_count) FROM [FGHIS5].[dbo].[系统_编码流水号] with (nolock)  WHERE 分类='新手术管理' and 名称='手术_手术排班ID'
					--IF @@ERROR <> 0 GOTO ERR
			   COMMIT TRAN
		 end
		 
		 			 select OPE_REG_ID,OPERATE_NO,OPERATE_NAME,ROLE_ID,ROLE_NAME,CREATE_ID,@person_num-(row_number() over(order by OPE_REG_ID)-1) ID into #TEMP_OPE_PERSON_NEW from #TEMP_OPE_PERSON
				 
		 
	
	begin tran
	
	--插入手术_登记表
	INSERT INTO [FGHIS5_SS].[dbo].[手术_登记表]
	([手术登记ID],[住院号],[住院ID],[附加ID],[门诊号],[挂号编号],[病人姓名],
	[性别],[年龄],[出生日期],[记帐代码],[手术性质],[所属病区],[所属科室],[所属床位],[是否紧急],[是否急救],[重大手术],[非计划再次],[体重],[身高],[血型],[申请类型],[预约日期],[预计费用],[是否植入],[手术名称],[诊断名称],[感染手术],[特殊需求],[健康卡号],[审核标志],[病人去向],[备注],[关联类型],[关联登记ID],
[医嘱ID],[切口等级],[状态],[申请时间],[时长],[是否越级],[上传标志],[默认卡号],[病案号],[手术接运状态],[记入账状态],[外部编号],[手术类型])
	select 
	p.ID [手术登记ID],
	P.inp_id [住院号],
	c.IN_HOSPITAL_ID [住院ID],
	c.ADDITIONAL_ID [附加ID],
	p.PATIENT_ID [门诊号],
	null [挂号编号],
	c.NAME [病人姓名],
	c.GENDER [性别],
	CONVERT(VARCHAR(10),DATEDIFF(YEAR,c.BIRTHDAY,@Start_date)) + 'Y' [年龄],
	convert(varchar(10),c.BIRTHDAY,112) [出生日期],
	c.ACCOUNT_CODE [记帐代码],
	'住院手术' [手术性质],
	p.WARD_ID [所属病区],
	p.DEPT_ID [所属科室],
	c.BEDS_ID [所属床位],
	p.IS_URGENT [是否紧急],
	p.IS_EMERG [是否急救],
  p.IS_MAJOR [重大手术],
  p.IS_PLAN [非计划再次],
	p.WEIGHT [体重],
	p.HEIGHT [身高],
	bloodDict.STATI_DETAIL_NAME [血型],
	applyTypeDict.STATI_DETAIL_NAME [申请类型],
	p.APPOINTMENT_DATE [预约日期],
	null [预计费用],
	p.IMPLANT_EQUIPMENT [是否植入],
  p.OPE_NAME [手术名称],
	DIA.DIA_NAME [诊断名称],
	p.INFECTED [感染手术],
	p.SPECIAL_NEED [特殊需求],
	null [健康卡号],
	0 [审核标志],
	p.WHEREABOUTS [病人去向],
	p.REMARKS [备注],
	null [关联类型],
	null [关联登记ID],
  null [医嘱ID],
	p.INCISION_ID [切口等级],
	2 [状态],
	p.APPLY_TIME [申请时间],
	case when p.DURATION is not null and p.DURATION != '' then CONVERT(NUMERIC(3,2),p.DURATION) else 0 end [时长],
	p.IS_LEAPFROG [是否越级],
	null [上传标志],
	c.CARD_NO [默认卡号],
	c.MED_RECORD_NO [病案号],
	-1 [手术接运状态],
	null [记入账状态],
	pa.wbbh [外部编号],
	p.RELATION_TYPE [手术类型]
	from #TEMP_ADVICE_GROUP t 
	left join CISEAPP..OPE_PAT_REGISTER p on t.OPE_REG_ID = p.ID
	left join CISCOMM..cis_hostpital_info c on p.INP_ID = c.inp_id
	left join CISCOMM..AUTH_OPERATOR creater on p.CREATE_ID = creater.ID
	left join CISPRO..V_CIS_PATIENT_INFO pa on p.PATIENT_ID = pa.id
	left join CISCOMM..CIS_STATIC_DETAIL_DICT applyTypeDict ON applyTypeDict.STATIC_CODE = 'OPE_APPLY_TYPE'  AND applyTypeDict.STATI_DETAIL_CODE = convert(varchar(20),p.APPLY_TYPE)
	left join CISCOMM..CIS_STATIC_DETAIL_DICT bloodDict ON bloodDict.STATIC_CODE = 'ba_xx'  AND bloodDict.STATI_DETAIL_CODE = p.BLOOD_TYPE
	left join CISEAPP..OPE_DIA_DETAIL DIA ON t.OPE_REG_ID = DIA.OPE_REGIST_ID and DIA.SEQ = 1
 
	;
	
	--插入手术_手术登记表
	INSERT INTO [FGHIS5_SS].[dbo].[手术_手术登记表]
	([手术ID],[手术登记ID],[状态],[科室代码],[主刀医生],[主刀医生科室],[排班人],[排班时间],[申请医生],[申请科室],[申请日期],[手术日期],[手术房间],[手术台次])
	select 
	r.OPE_ID [手术ID],
	r.OPE_REGIST_ID [手术登记ID],
	2 [状态],
	p.OPE_DEPT_ID [科室代码],
	knife.OPERATE_NO [主刀医生],
	null [主刀医生科室],
	null [排班人],
	null [排班时间],
	doc.OPERATE_NO [申请医生],
	r.APPLY_DEPT_ID [申请科室],
	r.APPLY_DEPT_TIME [申请日期],
	p.APPOINTMENT_DATE [手术日期],
	r.ROOM_ID [手术房间],
	r.OPE_TABLE_TIMES [手术台次]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_DOC_REGISTER r on t.OPE_REG_ID = r.OPE_REGIST_ID
	left join CISEAPP..OPE_PAT_REGISTER p on t.OPE_REG_ID = p.ID 
	left join CISCOMM..AUTH_OPERATOR knife on r.OPERATOR_DOC_ID =  knife.ID
	left join CISCOMM..AUTH_OPERATOR doc on r.APPLY_DOC_ID =  doc.ID
	;
	
	
	--插入手术麻醉表	
	INSERT INTO [FGHIS5_SS].[dbo].[手术_麻醉登记表]
	([麻醉ID],[手术登记ID],[状态],[科室代码],[排班人],[排班时间],[申请医生],[申请科室],[申请日期],[麻醉方式],[麻醉医生])
	select 
	r.ANAESTHESIA_ID [麻醉ID],
	r.OPE_REGIST_ID [手术登记ID],
	2 [状态],
	r.DEPT_ID [科室代码],
	null [排班人],
	null [排班时间],
	r.APPLY_DOC_ID [申请医生],
	r.APPLY_DEPT_ID [申请科室],
	r.APPLY_TIME [申请日期],
	r.MODE_ID [麻醉方式],
	r.DOCTOR_ID [麻醉医生]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_ANESTHESIA_REGIST r on t.OPE_REG_ID = r.OPE_REGIST_ID	
	;
	
	--插入手术明细表
	INSERT INTO [FGHIS5_SS].[dbo].[手术_手术明细表]
	([手术明细ID],[手术登记ID],[序号],[前导词],[后缀词],[CM3编码],[手术编码],[手术名称],[手术规模],[手术部位],[手术体位],[手术等级])
	select 
	d.OPE_DETAIL_ID [手术明细ID],
	d.OPE_REGIST_ID [手术登记ID],
	d.SEQ [序号],
	d.PREFIX [前导词],
	d.SUFFIX[后缀词],
	d.CM3_CODE [CM3编码],
	d.OPE_CODE [手术编码],
	d.OPE_NAME [手术名称],
	d.SCALE_ID [手术规模],
	d.POSITION_ID [手术部位],
	d.PLACE_ID [手术体位],
	d.LEVEL_ID [手术等级]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_PAT_REGISTER p on t.OPE_REG_ID = p.ID
	left join CISEAPP..OPE_DETAIL_INFO D ON p.ID = D.OPE_REGIST_ID
	;
	--插入诊断明细表
 INSERT INTO [FGHIS5_SS].[dbo].[手术_诊断明细表]
	([诊断明细ID],[手术登记ID],[序号],[手术诊断ID],[诊断代码],[诊断名称],[备注])
	select 
	D.DIA_DETAIL_ID [诊断明细ID],
	D.OPE_REGIST_ID [手术登记ID],
	D.SEQ [序号],
	D.DIA_CODE [手术诊断ID],
	D.DIA_CODE [诊断代码],
	D.DIA_NAME [诊断名称],
	D.REMARKS [备注]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_DIA_DETAIL D ON t.OPE_REG_ID = D.OPE_REGIST_ID 
	;
		
 	--插入手术排班表
	INSERT INTO [FGHIS5_SS].[dbo].[手术_排班人员表]
	 ([排班ID],[手术登记ID],[排班人员姓名],[排班人员工号],[手术角色ID],[角色名称],[操作时间],[操作人])
	 SELECT
	 t.ID [排班ID],
	 t.OPE_REG_ID [手术登记ID],
	 t.OPERATE_NAME [排班人员姓名],
	 t.OPERATE_NO [排班人员工号],
	 t.ROLE_ID [手术角色ID],
	 t.ROLE_NAME [角色名称],
	 GETDATE() [操作时间],
	 t.CREATE_ID [操作人]
	 from #TEMP_OPE_PERSON_NEW t
	 where t.OPERATE_NO is not null
	;
	
	set identity_insert  [FGHIS5_SS].[dbo].[手术_特殊手术明细表] ON
	--插入特殊手术明细
	INSERT INTO [FGHIS5_SS].[dbo].[手术_特殊手术明细表]
	 ([id],[手术登记ID],[姓名],[性别],[病区代码],[病区名称],[科室代码],[科室名称],[住院号],[住院ID],[附加ID],[入院日期],[入院时间],[特殊手术名称],[特殊手术原因],[特殊手术补充],[特殊手术时间],[审核状态],[审核人工号],[手术名称])
	 SELECT
	 D.ID [id],
	 D.OPE_REGIST_ID [手术登记ID],
	 D.NAME [姓名],
	 D.SEX [性别],
	 D.WARD_ID [病区代码],
	 D.WARD_NAME [病区名称],
	 D.DEPT_ID [科室代码],
	 D.DEPT_NAME [科室名称],
	 D.INP_ID [住院号],
	 D.IN_HOSPITAL_ID [住院ID],
	 D.ADDITIONAL_ID [附加ID],
	 D.INP_DATE [入院日期],
	 D.INP_TIME [入院时间],
	 D.SPECIAL_OPE_NAME [特殊手术名称],
	 D.SPECIAL_OPE_REASON [特殊手术原因],
	 D.SPECIAL_OPE_REMARK [特殊手术补充],
	 D.SPECIAL_OPE_TIME [特殊手术时间],
	 null [审核状态],
	 null [审核人工号],
	 null [手术名称]
	 from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_SPECIAL_DETAIL D ON t.OPE_REG_ID = D.OPE_REGIST_ID 
	;
	set identity_insert  [FGHIS5_SS].[dbo].[手术_特殊手术明细表] OFF
-- 	
	--插入手术_流程记录表
	INSERT INTO [FGHIS5_SS].[dbo].[手术_流程记录表](
	[手术登记ID],[操作类型],[操作时间],[操作ID],[备注],[最后操作])
	select
	t.OPE_REG_ID [手术登记ID],
	'申请' [操作类型],
	GETDATE() [操作时间],
	P.CREATE_ID [操作ID],
	'' [备注],
	1 [最后操作]
	from #TEMP_ADVICE_GROUP t
	left join CISEAPP..OPE_PAT_REGISTER p ON t.OPE_REG_ID = p.ID
	;
	    --插入手术同步记录表
	    INSERT INTO CISEAPP..OPE_PAT_REG_RECORD
	    select OPE_REG_ID,ADVICE_ID,INP_ID,APPLY_TIME,@Start_date,SEQ
	    from #TEMP_ADVICE t where not exists(select * from CISEAPP..OPE_PAT_REG_RECORD r where r.OPE_REG_ID=t.OPE_REG_ID and r.SEQ = t.SEQ)

	
	
	  IF @@ROWCOUNT=0 AND @@ERROR = 0 GOTO ERR
	    COMMIT TRAN 
		DROP TABLE #TEMP_OPE_PERSON_NEW
  RETURN(0) 
ERR:
  ROLLBACK TRAN
  RAISERROR('保存手术申请数据失败！',1,2) WITH NOWAIT 
 
  RETURN(-1)
END
go

