CREATE PROCEDURE [dbo].[ZY_APPLY_INSPECT_CHECK]
(@check_type NUMERIC, --1校验CT同部位 2校验超声动脉静脉
@item_id varchar(1000),
@errmessage varchar(200) OUTPUT) -- type = 1时传入同部位的项目id,type = 2时传入所有超声项目id

AS
BEGIN

   DECLARE @item_table table(item VARCHAR(50))
	 insert into @item_table
	 select * from F_STRSPLIT(@item_id)
	 
	 --分割字符串获取检查项目的项目id和部位id
	 DECLARE @item_pos table(item_id int,position_id varchar(20))
	 insert into @item_pos
	 SELECT 
	 SUBSTRING(item,1,CHARINDEX('|',item)-1) item_id,
	 SUBSTRING(item,CHARINDEX('|',item)+1,len(item)-charindex('|',item)) position_id 
	 from @item_table
	 
	  BEGIN
	  --校验传入的检查项目是否存在CT项目相同部位
	  DECLARE @temp_table TABLE(position_id VARCHAR(200),position_name VARCHAR(200),pos_count int)
		insert into @temp_table
	  SELECT T.POSITION_ID,PO.POSITION_NAME,count(*)  pos_count  from @item_pos T
		LEFT JOIN CISEAPP..APPLY_MED_PROJECT P ON P.MED_ADVICE_ID = T.item_id
	  LEFT JOIN CISEAPP..APPLY_MED_CATEGORY C ON P.CATEGORY_ID = C.CATEGORY_ID 
	  LEFT JOIN CISEAPP..APPLY_MED_POSITION PO ON T.position_id = CONVERT(varchar,PO.POSITION_ID)
		WHERE C.CATEGORY_NAME LIKE '%CT%'
		GROUP BY T.POSITION_ID,PO.POSITION_NAME
		SELECT @errmessage = 'CT项目中存在部位【' + stuff((select ',' + position_name from @temp_table where pos_count > 1 for xml path('')),1,1,'') + '】重复'
     END
	
		BEGIN
		DECLARE @jm_count int,@dm_count int
		SELECT @jm_count = count(*) from @item_pos t 
		LEFT JOIN CISEAPP..APPLY_MED_PROJECT P ON t.item_id = P.MED_ADVICE_ID
		where p.dept_id = 79 and p.med_advice_name like '%静脉%' 
		SELECT @dm_count = count(*) from @item_pos t 
		LEFT JOIN CISEAPP..APPLY_MED_PROJECT P ON t.item_id = P.MED_ADVICE_ID
		where p.dept_id = 79 and p.med_advice_name like '%动脉%' 
		if @jm_count > 0 and @dm_count > 0
		SELECT @errmessage = '超声项目存在动脉静脉互斥项目'
		END	

--     BEGIN
--     DECLARE @temp_table TABLE(position_id VARCHAR(200),position_name VARCHAR(200),pos_count int)
-- 		insert into @temp_table
-- 		SELECT P.POSITION_ID,PO.POSITION_NAME,count(*)  pos_count  from CISEAPP..APPLY_MED_PROJECT P 
-- 		LEFT JOIN CISEAPP..APPLY_MED_CATEGORY C ON P.CATEGORY_ID = C.CATEGORY_ID 
-- 		LEFT JOIN CISEAPP..APPLY_MED_POSITION PO ON P.POSITION_ID = CONVERT(varchar,PO.POSITION_ID)
-- 		WHERE C.CATEGORY_NAME LIKE '%CT%' and p.med_advice_id in (select * from F_STRSPLIT(@item_id)) and p.position_id is not null
-- 		GROUP BY P.POSITION_ID,PO.POSITION_NAME
-- 		SELECT @errmessage = 'CT项目中存在部位【' + stuff((select ',' + position_name from @temp_table where pos_count > 1 for xml path('')),1,1,'') + '】重复'
-- 		END
-- 	
-- 		BEGIN
-- 		DECLARE @jm_count int,@dm_count int
-- 		SELECT @jm_count = count(*) from CISEAPP..APPLY_MED_PROJECT P 
-- 		where p.dept_id = 79 and p.med_advice_name like '%静脉%' and p.med_advice_id in (select * from F_STRSPLIT(@item_id))
-- 		SELECT @dm_count = count(*) from CISEAPP..APPLY_MED_PROJECT P 
-- 		where p.dept_id = 79 and p.med_advice_name like '%动脉%' and p.med_advice_id in (select * from F_STRSPLIT(@item_id))
-- 		if @jm_count > 0 and @dm_count > 0
-- 		SELECT @errmessage = '超声项目存在动脉静脉互斥项目'
-- 		END
		
	-- routine body goes here, e.g.
	-- SELECT 'Navicat for SQL Server'
END
go

