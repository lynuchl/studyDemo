CREATE  PROCEDURE [dbo].[HIS_DES_ENCODE](@str varchar(100)) AS
-- CIS住院药品查询                                             
BEGIN
    select dbo.ClrFgEncrypt(@str);
  END;
go

