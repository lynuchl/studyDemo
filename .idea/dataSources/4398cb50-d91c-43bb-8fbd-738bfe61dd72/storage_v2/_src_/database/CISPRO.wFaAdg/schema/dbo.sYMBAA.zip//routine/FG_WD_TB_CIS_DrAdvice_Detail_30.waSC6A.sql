--exec FG_WD_TB_CIS_DrAdvice_Detail_30
CREATE  proc [dbo].[FG_WD_TB_CIS_DrAdvice_Detail_30](@RQ CHAR(9)='')                  

AS 
 
 declare @start_date date ,@end_date date
if LEN(@RQ)<1
	BEGIN
		SELECT @start_date=CONVERT(VARCHAR(10),GETDATE()-1,120),@end_date=CONVERT(VARCHAR(10),GETDATE(),120)
	END
ELSE
    BEGIN
	    SELECT @start_date=DATEADD(DAY,-1, CAST(@RQ AS date)),@end_date=CAST(@RQ AS date)
	END


 select a.ADVICE_ID YZID --医嘱ID
,'42506408531011811A2101' WSJGDM    --卫生机构（组织）代码
,'42506408500' YLJGDM    --医疗机构代码
,'42506408531011811A2101' FJ_WSJGDM  --总院卫生机构（组织）代码
--,ZJHM   --证件号码
--,ZJLX   --证件类型
,c.IN_HOSPITAL_ID JZLSH  --住院就诊流水号
,1 CXBZ   --撤销标志
,(case when c.INP_PATHWAY in(1,3,4,5) then '400' when c.INP_PATHWAY=2 then '300' else '999' end) JZLX   --就诊类型
,c.CARD_NO KH     --卡号
,CASE WHEN LEN(RTRIM(c.CARD_NO)) = 9 THEN '0'   WHEN  LEN(RTRIM(c.CARD_NO))= 15  and  c.CARD_NO like '148214%'  then  '2'
     when  LEN(RTRIM(c.CARD_NO)) = 10 THEN '1'     when  c.ACCOUNT_CODE = 84  THEN '8'  ELSE '9' END  KLX    --卡类型
,b.WARD_ID BQ    --病区
,a.DEPT_ID XDKSBM   --下达科室编码
,d.DEPT_NAME XDKSMC           --下达科室名称
,b.ADV_DOC_NO XDRGH     --医嘱下达人工号
,b.ADV_DOC_NAME XDRXM    --医嘱下达人姓名
,ISNULL((select i.ID_NUMBER from ciscomm..AUTH_OPERATOR_INFO i where i.OPERATE_NO=b.ADV_DOC_NO),'000000000000000000')  YZXDSFZ                --医嘱下达人身份证
,b.ADV_SUBMIT_DATE YZXDSJ   --医嘱下达时间
,b.EXECUTE_DEPT_ID ZXKSBM    --执行科室编码
,(select e.DEPT_NAME from CISCOMM..AUTH_DEPT e where e.ID=b.EXECUTE_DEPT_ID) ZXKSMC                     --执行科室名称
,b.LAST_EXECUTOR_NO ZXRGH     --医嘱执行人工号
,b.LAST_EXECUTOR_NAME ZXRXM   --医嘱执行人姓名
,ISNULL((select i.ID_NUMBER from ciscomm..AUTH_OPERATOR_INFO i where i.OPERATE_NO=b.LAST_EXECUTOR_NO),'000000000000000000') YZZXSFZ                    --医嘱执行人身份证号
,b.EXECUTE_DATE YZZXSJ        --医嘱执行时间
,b.STOP_DATE YZZZSJ           --医嘱终止时间
,a.REMARK YZSM                --医嘱说明
,a.MAIN_ID YZZH                --医嘱组号
,(case when a.ADVICE_CLASS=0 then '1'
when a.ADVICE_CLASS=1 then '2'
when a.ADVICE_CLASS=2 then '3'
else '9' end) YZLB             --医嘱类别
,a.ADVICE_CODE YZMXBM           --医嘱明细编码（院内）
,'zzzzzzzzzzzzzzz' YZMXBMYB                     --项目标准代码
,cast('' as VARCHAR(32)) SCPH                         --（项目的）生产批号
,null YXQZ                         --（项目的）有效期至
,a.ADVICE_NAME YZMXMC           --医嘱明细名称
,(case when a.ADVICE_CLASS in('1','2','3') then '01'
when a.ADVICE_CLASS='81' then '02'
when a.ADVICE_CLASS='82' then '03'
when a.ADVICE_CLASS='36' then '06'
when a.ADVICE_CLASS='99' then '07'
else '99'
end) YZLX                         --医嘱类型
,(case when DATALENGTH(a.SPEC)>32 then substring(a.SPEC,1,16) else a.SPEC end   ) YPGG                      --药品规格
,a.USAGE
,a.USAGE YPYF                           --药品用法
,e.EXTEND_CODE YYPDDM                         --用药频次代码
,e.EXTEND_NAME YYPD                           --用药频度
,a.ONE_DOSAGE JL                  --每次使用剂量（数量）
,a.BASIC_DOSAGE_UNIT DW            --每次使用剂量（数量）单位
--,(case when a.USAGE='1' then '1'
--when a.USAGE in('2','3') then '404'
--when a.USAGE='4' then '403'
--when a.USAGE='5' then '401'
--when a.USAGE in('7','8','18') then '5'
--when a.USAGE='12' then '2'
--when a.USAGE='13' then '605'
--when a.USAGE in ('11','22') then '611'
--when a.USAGE='15' then '608'
--when a.USAGE='26' then '402'
--when a.USAGE='28' then '604'
--when a.USAGE='35' then '607' 
--else '9'
--end) YF                              --给药途径(用法)
,(case when a.USAGE='口服' then '1'
when a.USAGE in('静推','静滴') then '404'
when a.USAGE='肌注' then '403'
when a.USAGE='皮下' then '401'
when a.USAGE in('喷雾','鼻饲','吸入') then '5'
when a.USAGE='肛内' then '2'
when a.USAGE='阴道' then '605'
when a.USAGE in ('外用','外涂') then '611'
when a.USAGE='滴鼻' then '608'
when a.USAGE='皮内' then '402'
when a.USAGE='腹注' then '604'
when a.USAGE='滴眼' then '607' 
else '9'
end) YF         -- 给药途径(用法)           
,null YYTS                               --用药天数
,null SFPS                               --皮试判别
,NULL YPSL                               --发药数量
,(case when a.ADVICE_ATTR='2' then a.APPLY_PACKAGE_UNIT else null end) YPDW                               --发药数量单位
,null JYDM                              --中药煎煮法代码
,null JCBW                             --检查部位
,a.REMARK BZ                                --备注
,1 XGBZ                              --修改标志
,null MJ                             --密级
,null YLYL1                          --预留一
,null YLYL2                          --预留二
into #temp
 from cisdoct..DOC_ADVICE a
 inner join cisdoct..DOC_ADVICE_EXTEND b on a.ADVICE_ID=b.ADVICE_ID
 left join ciscomm..CIS_HOSTPITAL_INFO c on a.INPAT_NO=c.INP_ID
 left join ciscomm..AUTH_DEPT d on a.DEPT_ID=d.ID
 left join ciscomm.dbo.CODE_FREQ_DICT e on a.FREQ=e.FREQ_CODE
 where b.ADV_SUBMIT_DATE>@start_date and b.ADV_SUBMIT_DATE<@end_date
 
 --select * from fghis5_yb.dbo.上海_国家医保目录对照表  b   where b.医疗目录类别='药品'

   --药品统编代码   YZMXBMYB 项目标准代码   YXQZ  有效期
   update   a   set   a.YZMXBMYB=B.上海医保码 ,a.YXQZ=B.结束日期  from   #temp  a  left  join   fghis5_yb.dbo.上海_国家医保目录对照表  b   on   a.YZMXBM=b.项目ID 
	where    a.YZLX='01'  and  b.结束日期>=@RQ
 
   
      print 2  

--select  *  from   FGHIS_YGPT..代码_药品品规基础信息

    update   a   set   a.SCPH=isnull(b.批准文号,'0')    from   #temp  a  left  join  FGHIS_YGPT.dbo.代码_药品品规基础信息  b  on   a.YZMXBMYB=b.统编代码 
    where    a.YZLX='01'   and  B.有效期限>=@RQ
		
	update   #TEMP   set  YZZXSJ=YZXDSJ    where  YZZXSJ is  null

	insert into CISPRO.dbo.TB_CIS_DrAdvice_Detail

	select [YZID]
           ,[WSJGDM]
           ,[YLJGDM]
           ,[FJ_WSJGDM]
           ,[JZLSH]
           ,[CXBZ]
           ,[JZLX]
           ,[KH]
           ,[KLX]
           ,[BQ]
           ,[XDKSBM]
           ,[XDKSMC]
           ,[XDRGH]
           ,[XDRXM]
           ,[YZXDSFZ]
           ,[YZXDSJ]
           ,[ZXKSBM]
           ,[ZXKSMC]
           ,[ZXRGH]
           ,[ZXRXM]
           ,[YZZXSFZ]
           ,[YZZXSJ]
           ,[YZZZSJ]
           ,[YZSM]
           ,[YZZH]
           ,[YZLB]
           ,[YZMXBM]
           ,[YZMXBMYB]
           ,[SCPH]
           ,[YXQZ]
           ,[YZMXMC]
           ,[YZLX]
           ,[YPGG]
           ,[YPYF]
           ,[YYPDDM]
           ,[YYPD]
           ,[JL]
           ,[DW]
           ,[YF]
           ,[YYTS]
           ,[SFPS]
           ,[YPSL]
           ,[YPDW]
           ,[JYDM]
           ,[JCBW]
           ,[BZ]
           ,[XGBZ]
           ,[MJ]
           ,[YLYL1]
           ,[YLYL2] from #temp
go

