





CREATE VIEW [dbo].[V_DRUG_DOSAGE] AS
SELECT T.剂型名称 DRUG_DOSAGE,T.输入码1 INPUT_CODE FROM [FGHIS5_YP].[dbo].[代码_药品剂型信息表] T
go

