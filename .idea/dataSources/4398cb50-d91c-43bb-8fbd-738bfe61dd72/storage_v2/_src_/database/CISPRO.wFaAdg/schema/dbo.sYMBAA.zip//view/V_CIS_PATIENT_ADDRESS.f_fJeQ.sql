CREATE  VIEW [dbo].[V_CIS_PATIENT_ADDRESS] AS
select ID,OUTP_NO,ADDR_TYPE_CODE,PROVINCE,CITY,COUNTY,TOWN,VILLAGE,HOUSE_NUMBER,ADDRESS_INFO,POSTALCODE from CISCOMM..CIS_PATIENT_ADDRESS;
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'患者地址信息表视图', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'主键ID', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS', N'COLUMN',
                               N'ID'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'病人id（门诊号）', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'OUTP_NO'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址类型编码：01户籍住址 02工', N'SCHEMA', @sn, N'VIEW',
                               N'V_CIS_PATIENT_ADDRESS', N'COLUMN', N'ADDR_TYPE_CODE'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址-省（自治区、直辖市）编码', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'PROVINCE'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址-市（地区、州）编码', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'CITY'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址-县（区）编码', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'COUNTY'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址-乡（镇、街道办事处）', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'TOWN'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址-村（街、路、弄等）', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'VILLAGE'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址-门牌号码', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS',
                               N'COLUMN', N'HOUSE_NUMBER'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'地址详情', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS', N'COLUMN',
                               N'ADDRESS_INFO'
go

declare @sn nvarchar(30)
set @sn = schema_name()
execute sp_addextendedproperty N'MS_Description', N'邮编', N'SCHEMA', @sn, N'VIEW', N'V_CIS_PATIENT_ADDRESS', N'COLUMN',
                               N'POSTALCODE'
go

