CREATE   PROCEDURE [dbo].[OUTP_ITEM_LIST](@itemClass  int,
                                           @deptId     int,
                                           @orgId      int,
                                           @docId      int,
                                           @name       varchar,
                                           @DRUG_CODE_LIST  varchar) AS
  -- CIS门诊项目列表查询
  BEGIN
    IF @DRUG_CODE_LIST IS NOT NULL AND LEN(@DRUG_CODE_LIST) > 0 BEGIN
        SELECT DISTINCT T.DRUG_ID         AS itemId,
                        T.DRUG_ID	      AS itemCode,
                        T.DRUG_NAME       AS itemName,
                        T.INPUT_CODE      AS inputCode,
                        T.DRUG_CLASS      AS itemClass,
                        T.DRUG_CLASS_NAME AS itemClassName,
                        T.RMB_FLAG        AS rmbFlag,
                        T.RMB_NAME        AS rmbName,
                        T.DEPT_ID         AS execDeptId,
                        T.DEPT_NAME       AS execDeptName,
                        --常规包装量(整装数量)等于1，规格取基本规格,大于1 规格取包装规格
                        --草药用基本规格
                        CASE
                          WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                           T.BASIC_SPEC
                          WHEN T.WHOLE_QUANTITY > 1 THEN
                           T.CONV_PACKING_SPEC
                        END AS spec,
                        T.CONV_PACKING_QUANTITY AS packageNum,
                        CASE
                          WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                           T.DRUG_UNIT
                          WHEN T.WHOLE_QUANTITY > 1 THEN
                           T.CONV_PACKING_UNIT
                        END AS packageUnit,
                        T.RETAIL_PRICE AS price,
                        T.BASIC_DOSE AS dose,
                        T.DOSE_UNIT AS doseUnit,
                        T.DOSE_UNIT AS dosageUnit,
                        T.DRUG_ATTR AS drugAttr,
                        T.DRUG_DOSAGE AS drugDosage,
                        T.STOCK_QUANTITY AS stockQuantity,
                        NULL AS spiritOneFlag,
                        NULL AS spiritTwoFlag,
                        NULL AS narcoticFlag,
                        T.ANTIBIOTICS_FLAG AS antibioticsFlag,
                        '1' AS upLowCabFlag
          FROM DRUG_INFO_TEMP T
         WHERE T.DRUG_ID IN (select * from F_STRSPLIT(@DRUG_CODE_LIST));
	END;
    ELSE IF @itemClass IS NOT NULL BEGIN
        SELECT DISTINCT T.DRUG_ID         AS itemId,
                        T.DRUG_ID	      AS itemCode,
                        T.DRUG_NAME       AS itemName,
                        T.INPUT_CODE      AS inputCode,
                        T.DRUG_CLASS      AS itemClass,
                        T.DRUG_CLASS_NAME AS itemClassName,
                        T.RMB_FLAG        AS rmbFlag,
                        T.RMB_NAME        AS rmbName,
                        T.DEPT_ID         AS execDeptId,
                        T.DEPT_NAME       AS execDeptName,
                        --常规包装量(整装数量)等于1，规格取基本规格,大于1 规格取包装规格
                        --草药用基本规格
                        CASE
                          WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                           T.BASIC_SPEC
                          WHEN T.WHOLE_QUANTITY > 1 THEN
                           T.CONV_PACKING_SPEC
                        END AS spec,
                        T.CONV_PACKING_QUANTITY AS packageNum,
                        CASE
                          WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                           T.DRUG_UNIT
                          WHEN T.WHOLE_QUANTITY > 1 THEN
                           T.CONV_PACKING_UNIT
                        END AS packageUnit,
                        T.RETAIL_PRICE AS price,
                        T.BASIC_DOSE AS dose,
                        T.DOSE_UNIT AS doseUnit,
                        T.DOSE_UNIT AS dosageUnit,
                        T.DRUG_ATTR AS drugAttr,
                        T.DRUG_DOSAGE AS drugDosage,
                        T.STOCK_QUANTITY AS stockQuantity,
                        NULL AS spiritOneFlag,
                        NULL AS spiritTwoFlag,
                        NULL AS narcoticFlag,
                        T.ANTIBIOTICS_FLAG AS antibioticsFlag,
                        '1' AS upLowCabFlag
          FROM DRUG_INFO_TEMP T
         WHERE T.DRUG_CLASS = @itemClass
           AND (T.DRUG_NAME LIKE '%' + @name + '%' OR
               T.INPUT_CODE LIKE '%' + @name + '%')
        UNION ALL
        SELECT DISTINCT T1.ITEM_ID AS ITEMID,
                        T1.ITEM_CODE AS ITEMCODE,
                        T1.ITEM_NAME AS ITEMNAME,
                        T1.INPUT_CODE AS inputCode,
                        T1.ITEM_CLASS AS ITEMCLASS,
                        T1.CLASS_NAME AS ITEMCLASSNAME,
                        T1.RMB_FLAG AS RMBFLAG,
                        NULL AS RMBNAME,
                        T1.DEF_DEPT_ID AS EXECDEPTID,
                        T2.DEPT_NAME AS EXECDEPTNAME,
                        T1.SPEC AS SPEC,
                        NULL AS PACKAGENUM,
                        T1.UNIT AS PACKAGEUNIT,
                        T1.PRICE AS PRICE,
                        NULL AS DOSE,
                        NULL AS DOSEUNIT,
                        T1.UNIT AS DOSAGEUNIT,
                        NULL AS DRUGATTR,
                        NULL AS DRUGDOSAGE,
                        NULL AS STOCKQUANTITY,
                        NULL AS spiritOneFlag,
                        NULL AS spiritTwoFlag,
                        NULL AS narcoticFlag,
                        NULL AS antibioticsFlag,
                        NULL AS upLowCabFlag
          FROM CODE_CHARGE_ITEM T1
          LEFT JOIN AUTH_DEPT T2
            ON T2.ID = T1.DEF_DEPT_ID
         WHERE T1.ITEM_CLASS = @itemClass
           AND T1.ORG_ID = @orgId
           AND (T1.ITEM_NAME LIKE '%' + @name + '%' OR
               T1.INPUT_CODE LIKE '%' + @name + '%');
	END;
    ELSE
        SELECT DISTINCT T.DRUG_ID         AS itemId,
                        T.DRUG_ID	      AS itemCode,
                        T.DRUG_NAME       AS itemName,
                        T.INPUT_CODE      AS inputCode,
                        T.DRUG_CLASS      AS itemClass,
                        T.DRUG_CLASS_NAME AS itemClassName,
                        T.RMB_FLAG        AS rmbFlag,
                        T.RMB_NAME        AS rmbName,
                        T.DEPT_ID         AS execDeptId,
                        T.DEPT_NAME       AS execDeptName,
                        --常规包装量(整装数量)等于1，规格取基本规格,大于1 规格取包装规格
                        --草药用基本规格
                        CASE
                          WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                           T.BASIC_SPEC
                          WHEN T.WHOLE_QUANTITY > 1 THEN
                           T.CONV_PACKING_SPEC
                        END AS spec,
                        T.CONV_PACKING_QUANTITY AS packageNum,
                        CASE
                          WHEN T.DRUG_CLASS = '3' OR T.WHOLE_QUANTITY = 1 THEN
                           T.DRUG_UNIT
                          WHEN T.WHOLE_QUANTITY > 1 THEN
                           T.CONV_PACKING_UNIT
                        END AS packageUnit,
                        T.RETAIL_PRICE AS price,
                        T.BASIC_DOSE AS dose,
                        T.DOSE_UNIT AS doseUnit,
                        T.DOSE_UNIT AS dosageUnit,
                        T.DRUG_ATTR AS drugAttr,
                        T.DRUG_DOSAGE AS drugDosage,
                        T.STOCK_QUANTITY AS stockQuantity,
                        NULL AS spiritOneFlag,
                        NULL AS spiritTwoFlag,
                        NULL AS narcoticFlag,
                        T.ANTIBIOTICS_FLAG AS antibioticsFlag,
                        '1' AS upLowCabFlag
          FROM DRUG_INFO_TEMP T
         WHERE T.DRUG_CLASS IN
               (SELECT ITEM_CLASS FROM V_CODE_CHARGE_ITEM_CLASS)
           AND (T.DRUG_NAME LIKE '%' + @name + '%' OR
               T.INPUT_CODE LIKE '%' + @name + '%')
        UNION ALL
        SELECT DISTINCT T1.ITEM_ID AS ITEMID,
                        T1.ITEM_CODE AS ITEMCODE,
                        T1.ITEM_NAME AS ITEMNAME,
                        T1.INPUT_CODE AS inputCode,
                        T1.ITEM_CLASS AS ITEMCLASS,
                        T1.CLASS_NAME AS ITEMCLASSNAME,
                        T1.RMB_FLAG AS RMBFLAG,
                        NULL AS RMBNAME,
                        T1.DEF_DEPT_ID AS EXECDEPTID,
                        T2.DEPT_NAME AS EXECDEPTNAME,
                        T1.SPEC AS SPEC,
                        NULL AS PACKAGENUM,
                        T1.UNIT AS PACKAGEUNIT,
                        T1.PRICE AS PRICE,
                        NULL AS DOSE,
                        NULL AS DOSEUNIT,
                        T1.UNIT AS DOSAGEUNIT,
                        NULL AS DRUGATTR,
                        NULL AS DRUGDOSAGE,
                        NULL AS STOCKQUANTITY,
                        NULL AS spiritOneFlag,
                        NULL AS spiritTwoFlag,
                        NULL AS narcoticFlag,
                        NULL AS antibioticsFlag,
                        NULL AS upLowCabFlag
          FROM CODE_CHARGE_ITEM T1
          LEFT JOIN AUTH_DEPT T2
            ON T2.ID = T1.DEF_DEPT_ID
         WHERE T1.ITEM_CLASS IN
               (SELECT ITEM_CLASS FROM V_CODE_CHARGE_ITEM_CLASS)
           AND T1.ORG_ID = @orgId
           AND (T1.ITEM_NAME LIKE '%' + @name + '%' OR
               T1.INPUT_CODE LIKE '%' + @name + '%');
	END;
go

