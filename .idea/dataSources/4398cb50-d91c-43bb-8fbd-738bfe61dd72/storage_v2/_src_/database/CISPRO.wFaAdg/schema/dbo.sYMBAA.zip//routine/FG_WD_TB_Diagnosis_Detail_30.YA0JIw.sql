--exec FG_WD_TB_Diagnosis_Detail_30 '20230308'
CREATE PROC [dbo].[FG_WD_TB_Diagnosis_Detail_30] (@RQ CHAR(8)='')                                      

AS    
 declare @start_date date ,@end_date date
if LEN(@RQ)<1
	BEGIN
		SELECT @start_date=CONVERT(VARCHAR(10),GETDATE()-1,120),@end_date=CONVERT(VARCHAR(10),GETDATE(),120)
	END
ELSE
    BEGIN
	    SELECT @start_date=DATEADD(DAY,-1, CAST(@RQ AS date)),@end_date=CAST(@RQ AS date)
	END

select 
t.DIAG_ID ZYZDLSH      --诊断流水号
,'42506408531011811A2101' WSJGDM      --卫生机构（组织）代码
,'42506408500' YLJGDM      --医疗机构代码
,'42506408531011811A2101' FJ_WSJGDM      --总院卫生机构（组织）代码
,(CASE WHEN id_card IS NULL THEN 'ZZZZZZZZZZZZZZZZZZ' ELSE B.id_card END) ZJHM      --证件号码
,'01' ZJLX      --证件类型
,A.IN_HOSPITAL_ID JZLSH      --就诊流水号
,'2' MZZYBZ      --门诊/住院标志
,A.CARD_NO KH      --卡号
,CASE WHEN  len(A.CARD_NO)=9 THEN '0'    when  len(A.CARD_NO)=10 THEN '1'    when  len(A.CARD_NO)=15 THEN '2' else '3' END KLX      --卡类型
,(case when DIAG_TYPE='WEST' then '1' when DIAG_TYPE='CN' THEN '2' else '1' END) ZDLXQF      --诊断类型区分
,(case  when  DIAG_TYPE='WEST' and DIAG_CATE='出院诊断' then '1' 
		when  DIAG_TYPE='WEST' and DIAG_CATE='门诊诊断' then '2' 
		when  DIAG_TYPE='WEST' and DIAG_CATE='入院诊断' then '3' 
		when  DIAG_TYPE='WEST' and DIAG_CATE='术前诊断' then '4' 
		when  DIAG_TYPE='WEST' and DIAG_CATE='术后诊断' then '5' 
		when  DIAG_TYPE='CN' and DIAG_CATE='门诊诊断' AND DIAG_STAND_TYPE='病' then '1' 
		when  DIAG_TYPE='CN' and DIAG_CATE='入院诊断' AND DIAG_STAND_TYPE='病' then '2' 
		when  DIAG_TYPE='CN' and DIAG_CATE='出院诊断' AND DIAG_STAND_TYPE='病' then '3' 
		when  DIAG_TYPE='CN' and DIAG_CATE='门诊诊断' AND DIAG_STAND_TYPE='证' then '4' 
		when  DIAG_TYPE='CN' and DIAG_CATE='入院诊断' AND DIAG_STAND_TYPE='证' then '5' 
		when  DIAG_TYPE='CN' and DIAG_CATE='出院诊断' AND DIAG_STAND_TYPE='证' then '6' 
else '99' end) ZDLB      --诊断类别代码
,T.DIAG_DATE ZDSJ      --诊断时间
,T.DIAG_CODE ZDBM      --诊断编码
,'01' BMLX      --诊断编码类型
,'' ZDSM      --诊断说明
,(case when DIAG_SEQ='1' then '1'  else '2' end) CYZDBZ      --主要诊断标志
,'0' YZDBZ      --疑似诊断标志
,'4' RYBQ      --入院病情
,(case when a.INP_STAT='4' and DISCHARGE_CONDITION='0' then '1' 
		when a.INP_STAT='4' and DISCHARGE_CONDITION='1' then '2' 
		when a.INP_STAT='4' and DISCHARGE_CONDITION='2' then '3' 
		when a.INP_STAT='4' and DISCHARGE_CONDITION='3' then '4' 
		when a.INP_STAT='4' and DISCHARGE_CONDITION='4' then '5' 
     else '' end) CYQKBM      --出院情况编码
,'' MJ      --密级
,'1' XGBZ      --修改标志
,NULL YLYL1      --预留一
,NULL YLYL2      --预留二
into #temp
from ciscomm..CIS_DIAG_INFO t  
INNER JOIN CISCOMM..CIS_HOSTPITAL_INFO A ON T.INPAT_NO=A.INP_ID
left join CISPRO.dbo.V_CIS_PATIENT_INFO b on A.PATIENT_ID=B.outp_no
where t.DIAG_DATE>=@start_date and t.DIAG_DATE<@end_date
 
  
insert into CISPRO.dbo.TB_DIAGNOSIS_DETAIL( [ZYZDLSH]
           ,[WSJGDM]
           ,[YLJGDM]
           ,[FJ_WSJGDM]
           ,[JZLSH]
           ,[MZZYBZ]
           ,[KH]
           ,[KLX]
           ,[ZDLXQF]
           ,[ZDLB]
           ,[ZDSJ]
           ,[ZDBM]
           ,[BMLX]
           ,[ZDSM]
           ,[CYZDBZ]
           ,[YZDBZ]
           ,[RYBQ]
           ,[CYQKBM]
           ,[MJ]
           ,[XGBZ]
           ,[YLYL1]
           ,[YLYL2] )

  select [ZYZDLSH]
           ,[WSJGDM]
           ,[YLJGDM]
           ,[FJ_WSJGDM]
           ,[JZLSH]
           ,[MZZYBZ]
           ,[KH]
           ,[KLX]
           ,[ZDLXQF]
           ,[ZDLB]
           ,[ZDSJ]
           ,[ZDBM]
           ,[BMLX]
           ,[ZDSM]
           ,[CYZDBZ]
           ,[YZDBZ]
           ,[RYBQ]
           ,[CYQKBM]
           ,[MJ]
           ,[XGBZ]
           ,[YLYL1]
           ,[YLYL2] from #temp

drop table #temp
go

