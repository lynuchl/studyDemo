CREATE PROCEDURE [dbo].[SYNC_OPERATION_MASTER_CANCEL]
(@ope_regist_id INT,@operator_id INT) 
AS
BEGIN
	-- routine body goes here, e.g.
	-- SELECT 'Navicat for SQL Server'
-- 	UPDATE [FGHIS5_ZY].[dbo].[手术_登记表] set 手术状态 = 7,麻醉状态 = 7 where 手术登记ID = @ope_regist_id and 手术状态 = 0 
-- 	
-- 	IF @@ROWCOUNT > 0
-- 	update [FGHIS5_ZY].[dbo].[手术_流程记录表] set 最后操作 = 0 where 手术登记ID = @ope_regist_id
-- 	
-- 	--插入手术_流程记录表
-- 	INSERT INTO [FGHIS5_ZY].[dbo].[手术_流程记录表](
-- 	[手术登记ID],[操作类型],[操作时间],[操作ID],[备注],[最后操作])
-- 	VALUES (@ope_regist_id,'作废',GETDATE(),@operator_id,'',1)
-- 	

	UPDATE [FGHIS5_SS].[dbo].[手术_登记表] set 状态 = 10 where 手术登记ID = @ope_regist_id and 状态 = 2 
	UPDATE [FGHIS5_SS].[dbo].[手术_手术登记表] set 状态 = 10 where 手术登记ID = @ope_regist_id and 状态 = 2 
	UPDATE [FGHIS5_SS].[dbo].[手术_麻醉登记表] set 状态 = 10 where 手术登记ID = @ope_regist_id and 状态 = 2 
	
	IF @@ROWCOUNT > 0
	update [FGHIS5_SS].[dbo].[手术_流程记录表] set 最后操作 = 0 where 手术登记ID = @ope_regist_id

INSERT INTO [FGHIS5_SS].[dbo].[手术_流程记录表](
	[手术登记ID],[操作类型],[操作时间],[操作ID],[备注],[最后操作]) VALUES (@ope_regist_id,'作废',GETDATE(),@operator_id,'',1)
	
END
go

