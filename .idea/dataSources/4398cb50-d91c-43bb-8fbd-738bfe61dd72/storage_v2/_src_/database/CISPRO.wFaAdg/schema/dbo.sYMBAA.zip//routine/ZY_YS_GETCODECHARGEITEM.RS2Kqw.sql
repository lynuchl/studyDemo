CREATE PROCEDURE [dbo].[ZY_YS_GETCODECHARGEITEM](@itemClass      int,
												@advAttr        varchar(1)--医嘱属性：0-长期 1-临时 2-出院带药 3-中草药
												) AS

-- CIS住院收费项目查询

SELECT  T.ITEM_CLASS  AS itemClass,
                 T.CLASS_NAME  AS className,
                 T.RMB_FLAG    AS rmbFlag,
				 R.REIMBURSE_NAME AS rmbName,
                 T.ITEM_ID     AS itemCode,
                 T.ITEM_NAME   AS itemName,
                 T.SPEC        AS spec,
				 T.UNIT        AS basicDosageUnit,
                 T.PRICE       AS price,
                 T.DEF_DEPT_ID AS deptId,
                 T1.DEPT_NAME  AS deptName,
                 T.INPUT_CODE  AS inputCode
			INTO #TEMP
            FROM CISPRO..V_ADVICE_CHARGE_ITEM T
            LEFT JOIN CISCOMM..AUTH_DEPT T1 ON T1.ID = T.DEF_DEPT_ID
			LEFT JOIN CISCOMM..CODE_REIMBURSE_INFO R ON R.REIMBURSE_CODE = T.RMB_FLAG AND R.STATE = 1
           WHERE T.STATUS = '1'
             AND T.ITEM_CODE IS NOT NULL
             AND T.PRICE IS NOT NULL
			 AND (T.ITEM_ID NOT IN (SELECT ITEM_ID FROM CISNURS..NUR_ATTEND_COST)
				 OR (T.ITEM_ID IN (SELECT ITEM_ID FROM CISNURS..NUR_ATTEND_COST) AND @advAttr='0'))
           ORDER BY T.SERIAL_NO;

BEGIN
  IF @itemClass IS NOT NULL BEGIN
      SELECT * FROM #TEMP T WHERE T.itemClass = @itemClass;
  END;
  ELSE
      SELECT * FROM #TEMP T;
END;
go

