-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步手术申请-手术人员信息(OPE_STAFF)
-- Description:	 通过作业定时去同步his中新增或者修改的手术人员信息
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_OPE_STAFF]
	 
AS
BEGIN 
 

     
select distinct [EMP_ID],[EMP_NO]
      ,[EMP_NAME]
      ,[DEPT_ID]
      ,[OPE_DEPT_ID]
      ,[LEVEL_ID]
      ,[ROLE_ID]
      ,[STATE]
      ,[REMARKS]
      ,[INPUT_CODE]
      ,[CREATE_ID]
      ,[CREATE_DATE]
      ,[UPDATE_ID]
      ,[UPDATE_DATE]
      ,[ORG_ID] into #temp
        from
		(
		SELECT a.人员ID emp_id,t.人员工号 [EMP_NO]
				   ,t.人员姓名 [EMP_NAME]
				   ,t.所属科室 [DEPT_ID]
				   ,t.手术科室 [OPE_DEPT_ID]
				   ,t.手术等级 [LEVEL_ID]
		   
 -----HIS字典        ：3 主刀医生 4 第一助手 6 第二助手                   2 麻醉医生                                       1 巡回护士   5 洗手护士  7 第二巡回  8 第二洗手
 -----CIS取字典表数据：0  主刀    1 一助     2 二助     3 三助    4 四助  5 麻醉医生   6 器械护士  7一麻       8 二麻      9 巡回护士
           ,(case when t.手术角色ID=3 then 0
                when t.手术角色ID=4 then 1
				when t.手术角色ID=6 then 2
				when t.手术角色ID=2 then 5
				when t.手术角色ID=1 then 9
				when t.手术角色ID in(5,7,8) then 9 end) [ROLE_ID]
           ,t.状态 [STATE]
           ,t.备注 [REMARKS]
           ,t.输入码 [INPUT_CODE]
           ,-1 [CREATE_ID]
           ,getdate() [CREATE_DATE]
           ,null [UPDATE_ID]
           ,null [UPDATE_DATE]
           ,'10001' [ORG_ID] 
		   ,ROW_NUMBER() over(partition by t.人员工号,t.手术科室,t.手术角色ID order by t.手术等级 desc) fzxh
  from [FGHIS5_ZY].[dbo].手术_手术人员表 t
  left join fghis5.dbo.系统_工作人员表 a on t.人员工号=a.人员工号
  )bb where bb.fzxh=1


      merge CISEAPP..OPE_STAFF as A
	  using #temp B ON A.EMP_ID=B.EMP_ID
			when not matched then 
			INSERT (EMP_ID
           ,[EMP_NO]
           ,[EMP_NAME]
           ,[DEPT_ID]
           ,[OPE_DEPT_ID]
           ,[LEVEL_ID]
           ,[ROLE_ID]
           ,[STATE]
           ,[REMARKS]
           ,[INPUT_CODE]
           ,[CREATE_ID]
           ,[CREATE_DATE]
           ,[UPDATE_ID]
           ,[UPDATE_DATE]
           ,[ORG_ID]) 
		values(b.EMP_ID
           ,b.[EMP_NO]
           ,b.[EMP_NAME]
           ,b.[DEPT_ID]
           ,b.[OPE_DEPT_ID]
           ,b.[LEVEL_ID]
           ,b.[ROLE_ID]
           ,b.[STATE]
           ,b.[REMARKS]
           ,b.[INPUT_CODE]
           ,b.[CREATE_ID]
           ,b.[CREATE_DATE]
           ,b.[UPDATE_ID]
           ,b.[UPDATE_DATE]
           ,b.[ORG_ID])	;
		    
		 drop table #temp
END


go

