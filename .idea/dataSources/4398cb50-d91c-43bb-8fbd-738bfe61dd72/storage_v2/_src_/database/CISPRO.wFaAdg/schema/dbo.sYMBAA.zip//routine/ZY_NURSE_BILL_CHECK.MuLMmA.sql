CREATE PROCEDURE [dbo].[ZY_NURSE_BILL_CHECK](
    @inp_id varchar(50)) AS
-- 护士站 单据管理自定义筛选配置


BEGIN


    --定义中间表，有用存储返回结果集
    DECLARE @temp_table TABLE
                        (
                            adviceId   decimal(20),
                            adviceName varchar(500)
                        )

    --不展示医嘱名称为（Y）的医嘱
    insert into @temp_table
    select advice_Id as adviceId, advice_Name as adviceName
    from CISDOCT..DOC_ADVICE
    where INPAT_NO = @inp_id
      and ADVICE_NAME like '%(Y)';

    select * from @temp_table;

end ;
go

