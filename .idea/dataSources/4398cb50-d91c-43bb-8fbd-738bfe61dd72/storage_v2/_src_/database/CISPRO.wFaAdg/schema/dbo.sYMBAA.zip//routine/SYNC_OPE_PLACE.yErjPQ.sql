-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步手术申请-部位表(OPE_PLACE)
-- Description:	 通过作业定时去同步his中新增或者修改的手术部位信息
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_OPE_PLACE]
	 
AS
BEGIN 
 
      merge ciseapp..OPE_PLACE as A
	  using(
			 select t.部位ID [PLACE_ID]
			  ,t.部位名称 [PLACE_NAME]
			  ,t.输入码1 [INPUT_CODE]
			  ,t.输入码2 [FIVE_STROKES]
			  ,0 [STATE]
			  ,t.备注 [REMARKS]
			  ,t.部位类型 [TYPE]
			   from [FGHIS5_ZY].[dbo].[手术_部位表] t where t.部位类型='部位'
			)B ON A.PLACE_ID=B.PLACE_ID
			when not matched then 
			INSERT ([PLACE_ID]
           ,[PLACE_NAME]
           ,[INPUT_CODE]
           ,[FIVE_STROKES]
           ,[STATE]
           ,[REMARKS]
           ,[TYPE]
           ,[CREATE_ID]
           ,[CREATE_DATE]
           ,[UPDATE_ID]
           ,[UPDATE_DATE]
           ,[ORG_ID]) 
		values(B.[PLACE_ID]
           ,B.[PLACE_NAME]
           ,B.[INPUT_CODE]
           ,B.[FIVE_STROKES]
           ,B.[STATE]
           ,B.[REMARKS]
           ,B.[TYPE]
           ,-1  
			,GETDATE() 
			,null  
			,null  
			,'10001' )	;

			update ciseapp..OPE_PLACE set STATE=1 where not exists(select * from [FGHIS5_ZY].[dbo].[手术_部位表] t where t.部位类型='部位' and t.部位id=PLACE_ID)
END


go

