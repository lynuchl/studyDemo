
CREATE VIEW [dbo].[V_CIS_PATIENT_INFO] AS /*select ID,OUTP_NO,NAME,GENDER,BIRTH_DATE,BIRTH_TIME,ID_CARD,NATIONALITY,NATION,BLOOD_TYPE,MARRIAGE,OCCUPATION,TELEPHONE,MOBILE_PHONE,BIRTH_PROVINCE,BIRTH_CITY,BIRTH_COUNTY,NATIVE_PLACE_PROVINCE,NATIVE_PLACE_CITY,NATIVE_PLACE_COUNTY,CENSUS_REGISTER_PROVINCE,CENSUS_REGISTER_CITY,CENSUS_REGISTER_COUNTY,CENSUS_REGISTER_INFO,CURRENT_RESIDENCE_PROVINCE,CURRENT_RESIDENCE_CITY,CURRENT_RESIDENCE_COUNTY,CURRENT_RESIDENCE_INFO,REMARKS,SOURCE,CREATE_NAME,CREATE_DATE,HEIGHT,WEIGHT,POST_CODE,FAITH from CISCOMM..CIS_PATIENT_INFO;*/

select t.门诊号   id,
        t.门诊号   outp_no,
        t.姓名     name,
        t.性别     gender,
        t.出生日期 birth_date,
        t.出生时间 birth_time,
        t.身份证号 id_card,
        isnull(c.平台代码,t.国籍)     nationality,
        isnull(d.平台代码,t.民族)     nation,
        (case when t.血型='9' then '其它'
				when t.血型='1' then 'A'
				when t.血型='2' then 'B'
				when t.血型='3' then 'O'
				when t.血型='4' then 'AB'
				else '不明'
		end)     blood_type,
        (case when t.婚姻='1' then '未婚' 
		when t.婚姻='2' then '已婚' 
		when t.婚姻='3' then '离异' 
		when t.婚姻='4' then '丧偶' 
		else '其他' end)   marriage,
        t.职业     occupation,
        t.联系电话 telephone,
        t.联系手机 mobile_phone,
        a.出生地省 birth_province,
        a.出生地市 birth_city,
        a.出生地县 birth_county,
        a.籍贯省   native_place_province,
        a.籍贯市   native_place_city,
        a.籍贯县   native_place_county,
        null       census_register_province,
        null       census_register_city,
        null       census_register_county,
        a.户口地址 census_register_info,
        t.省       current_residence_province,
        t.市       current_residence_city,
        t.县       current_residence_county,
        t.联系地址 current_residence_info,
        null    remarks,
        null       source,
        t.创建人id create_name,
        t.创建时间 create_date,
        null     height,
        null     weight,
		t.联系邮编 POST_CODE,
		(case when t.宗教信仰='10' then '佛教' 
			when t.宗教信仰='20' then '喇嘛教' 
			when t.宗教信仰='30' then '道教' 
			when t.宗教信仰='40' then '天主教' 
			when t.宗教信仰='50' then '基督教' 
			when t.宗教信仰='60' then '东正教' 
			when t.宗教信仰='70' then '伊斯兰教' 
			when t.宗教信仰='99' then '其他'
		else '无宗教信仰' end)FAITH,
		NULL PZH, --凭证号
		NULL YXQ, --有效期
		t.保密级别 BMJB, --保密级别
		t.个人偏好 GRPH, --个人偏好
		t.首次就诊日期 SCJZ, --首次就诊
		t.健康卡号 JKKH, --健康卡号
		t.VIP标志 VIP,  --VIP
		NULL YY ,   --语言
		t.外部编号 wbbh
    from FGHIS5.dbo.系统_病人基本信息表 t
    left join FGHIS5.dbo.系统_病人基本信息_附加表 a    on t.门诊号 = a.门诊号
	left join FGHIS5.dbo.字典_代码名称映射表 c on t.国籍=c.His代码 and c.His类别='国家编码'
	left join FGHIS5.dbo.字典_代码名称映射表 d on t.民族=c.His代码 and c.His类别='民族'

go

