-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-申请检验类别表(APPLY_EXAMINE_CATEGORY)
-- Description:	 通过作业定时去同步his中新增或者修改的申请检验类别表
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_EXAMINE_CATEGORY]
	 
AS
BEGIN 
      merge ciseapp..APPLY_EXAMINE_CATEGORY as A
	  using(
	  select t.类别id category_id, 
			t.类别代码 category_code, 
			t.类别名称 category_name, 
			'' show_color, 
			t.上级类别代码 old_his_code, 
			
			t.显示序号 seq from fghis5_mz.dbo.代码_申请检验类别表 t
			)B ON A.category_id=B.category_id
			when not matched then 
			INSERT (CATEGORY_ID
					,CATEGORY_CODE
					,CATEGORY_NAME
					,SHOW_COLOR
					,OLD_HIS_CODE
					,CREATE_ID
					,CREATE_DATE
					,UPDATE_ID
					,UPDATE_DATE
					,DEPT_ID
					,ORG_ID
					,ENABLED
					,SEQ) 
		values(B.CATEGORY_ID
			,B.CATEGORY_CODE
			,B.CATEGORY_NAME
			,B.SHOW_COLOR
			,B.OLD_HIS_CODE
			,-1  
			,getdate()  
			,null  
			,null  
			,'71'    -----需要填写对应的检验科室id
			,'10001'  
			,0  
			,b.seq )	;

	----当HIS中检验类别被删除时，修改cis中类别状态为停用		 
     update ciseapp..APPLY_EXAMINE_CATEGORY set [ENABLED]=1 where not exists(select tt.类别id  from fghis5_mz.dbo.代码_申请检验类别表 tt where tt.类别id=CATEGORY_ID) ;

END


go

