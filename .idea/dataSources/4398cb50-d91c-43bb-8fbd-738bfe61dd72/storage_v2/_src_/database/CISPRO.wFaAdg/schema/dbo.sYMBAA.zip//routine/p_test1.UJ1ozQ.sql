CREATE proc [dbo].[p_test1]
 
as
  declare @sql varchar(8000)
  declare @error int =0 --事务中操作的错误记录
  --开启事务
  set xact_abort ON
  begin transaction
 
    --INSERT INTO HISZSK.FGHIS5.DBO.AAAAA(TI) VALUES('AAA');
	INSERT INTO FGHIS5.DBO.AAAAA VALUES(3);
 
--判断事务的提交或者回滚
if(@error<>0)
  begin
    rollback transaction
    return -1 --设置操作结果错误标识
  end
else
  begin
    commit transaction
    return 1 --操作成功的标识
  end
   set XACT_ABORT OFF
go

