CREATE  PROCEDURE [dbo].[ZY_B_COST_BATCH_ABUTMENT] (@ids  varchar(500)) AS

BEGIN

    insert into [DBLINK_HISPRODEV]..[HISPRO].[NUR_COST]
      (	   id,
           bed_no,
           ward_id,
           dept_id)
    select top(1) a.id,
           a.bed_no,
           a.ward_id,
           a.dept_id
      from cisnurs..nur_cost a with(nolock)
			left join CISCOMM..CIS_HOSTPITAL_INFO b with(nolock) on a.in_hospital_id = b.IN_HOSPITAL_ID and a.additional_id = b.ADDITIONAL_ID and a.INP_ID = b.INP_ID
			where a.id in (select * from F_STRSPLIT(@ids))
       and a.item_class in (1, 2, 3) ;
END;
go

