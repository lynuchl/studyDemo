-- dbo.V_CIS_P_CARD_INFO source

CREATE VIEW dbo.V_CIS_P_CARD_INFO
AS
SELECT NULL AS id,
       t.PATIENT_ID AS outp_no,
       a.NAME AS name,
       t.INSURANCE_NO AS card_number,
       NULL AS posting_key,
       t.FUND_TYPE AS posting_type,
       a.PATIENT_ID AS patient_id,
       NULL AS cabinet_number,
       NULL AS effective_date,
       t.OPERATOR AS create_name,
       t.UPDATE_DATE_TIME AS create_date,
       (CASE
         WHEN t.ACCOUNT_STATUS = 1 THEN
          0
         WHEN t.ACCOUNT_STATUS = 0 THEN
          1
       END) AS state,
       NULL AS default_type,
       t.ACCOUNT_TYPE AS card_type
  FROM DBLINK_HISPRODEV..INSURANCE.INSURANCE_ACCOUNTS  t
 INNER JOIN DBLINK_HISPRODEV..MEDREC.PAT_MASTER_INDEX  a
    ON t.PATIENT_ID = a.PATIENT_ID;
go

