CREATE PROCEDURE [dbo].[SYNC_APPLY_INSPECT_DETAIL_CANCEL]
(@apply_id INT,@apply_order_num INT) 
AS
BEGIN
	-- routine body goes here, e.g.
	-- SELECT 'Navicat for SQL Server'
  DELETE from [FGHIS5_MZ].[dbo].[申请_检查申请单明细] where 申请单号 = @apply_id and 申请序号 = @apply_order_num  and 申请状态 = '0' and 费用状态 = '0'
	
	
END
go

