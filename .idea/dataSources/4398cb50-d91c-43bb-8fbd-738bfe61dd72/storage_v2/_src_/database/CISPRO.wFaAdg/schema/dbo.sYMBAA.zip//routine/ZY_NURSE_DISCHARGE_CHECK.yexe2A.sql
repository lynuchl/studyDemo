CREATE PROCEDURE [dbo].[ZY_NURSE_DISCHARGE_CHECK](@inp_id varchar(50),
                                                  @quantity decimal(10, 2)) AS
-- 护士站 患者出院检查


BEGIN

    --定义一个中间表，用于存放放回结果集
    DECLARE @temp_table TABLE
                        (
                            typeName      varchar(200),
                            itemName      varchar(200),
                            deptName      varchar(200),
                            status        varchar(200),
                            operationTime datetime,
                            checkType     varchar(20) --1-只提示不强拦；其他-强拦
                        )

    --查询当前患者附加id
    DECLARE @ADDITIONAL_ID varchar(200)
    select @ADDITIONAL_ID = t.ADDITIONAL_ID
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id

    --查询当前患者的住院id
    DECLARE @IN_HOSPITAL_ID varchar(200)
    select @IN_HOSPITAL_ID = t.IN_HOSPITAL_ID
    from CISCOMM..CIS_HOSTPITAL_INFO t
    where t.INP_ID = @inp_id

    --查询床位固定费用计费数量
    DECLARE @fixedCostQuantity decimal(10, 2)
    --select @fixedCostQuantity = (select ISNULL(sum(t.quantity), 0)
    --                             from CISnurs..nur_cost t
    --                             where t.inp_id = @inp_id
    --                               and t.ITEM_CLASS = 4
    --                               and t.STATUS = '1')

	    select @fixedCostQuantity = (select ISNULL(sum(t.数量), 0)
                                 from cispro..V_INP_FEE_OTHER t
                                 where t.住院ID = @IN_HOSPITAL_ID
                                   and t.项目类别 = 4
                                   and t.状态 = '1')


    --查询护理费用计费数量
    DECLARE @nurseCostQuantity decimal(10, 2)
    --select @nurseCostQuantity = (select ISNULL(sum(t.quantity), 0)
    --                             from CISnurs..nur_cost t
    --                             where t.inp_id = @inp_id
    --                               and t.ITEM_CLASS = 11
    --                               and t.STATUS = '1')

		    select @nurseCostQuantity = (select ISNULL(sum(t.数量), 0)
                                 from cispro..V_INP_FEE_OTHER t
                                 where t.住院ID = @IN_HOSPITAL_ID
                                   and t.项目类别 = 11
                                   and t.状态 = '1')


--检查出院医嘱

    DECLARE @CHKE1 INT
    DECLARE @CHKE_STATUS varchar
    select @CHKE1 = count(1)
    from CISDOCT..DOC_ADVICE a
             left join CISCOMM..cis_hostpital_info c
                       on c.INP_ID = a.INPAT_NO
    where a.INPAT_NO = @inp_id
      and a.ADVICE_CLASS = '80'
      and a.ADVICE_NAME like '%出院%'
      and a.status != '0' --排除暂存

    if @CHKE1 < 1
        begin

            insert into @temp_table (typeName, itemName, deptName, status, operationTime, checkType)
            values ('医生未开出院医嘱', '请先联系医生开具医嘱后再做出院操作', '', '', null, '');
        end
    else
        begin
            select @CHKE_STATUS = count(1)
            from CISDOCT..DOC_ADVICE a
                     left join CISCOMM..cis_hostpital_info c
                               on c.INP_ID = a.INPAT_NO
            where a.INPAT_NO = @inp_id
              and a.ADVICE_CLASS = '80'
              and a.ADVICE_NAME like '%出院%'
              and a.status = '7' --护士停止确认
            if @CHKE_STATUS < 1
                begin

                    insert into @temp_table (typeName, itemName, deptName, status, operationTime, checkType)
                    values ('出院医嘱未经护士停用确认', '请先联系护士停用确认后再做出院操作', '', '', null, '');
                end
        end


    --未完全停止的医嘱
    insert into @temp_table
    select '[未完全停用的医嘱]: ' + adviceAttr.STATI_DETAIL_NAME typeName,
           advice.ADVICE_NAME                            itemName,
           dept.DEPT_NAME as                             deptName,
           status.STATI_DETAIL_NAME                      status,
           case
               when advice.status = 0 then ext.CREATE_DATE
               when advice.status = 1 then ext.ADV_SUBMIT_DATE
 when advice.status = 2 then ext.CONFIRM_DATE
               when advice.status = 3 then ext.EXECUTE_DATE
               else null end                             operationTime,
           ''                                            checkType
    from CISDOCT..DOC_ADVICE advice
             inner join CISDOCT..DOC_ADVICE_EXTEND ext on advice.advice_id = ext.advice_id
             left join CISCOMM..AUTH_DEPT dept on ext.execute_dept_id = dept.id
             left join CISCOMM..code_reimburse_info reimburse
                       on advice.rmb_flag = CONVERT(varchar(2), reimburse.reimburse_code) and reimburse.state = 1
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT adviceAttr
                       ON adviceAttr.STATIC_CODE = 'adv_attr' AND
                          adviceAttr.STATI_DETAIL_CODE = convert(varchar, advice.ADVICE_ATTR)
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
                       ON status.STATIC_CODE = 'advice_status' AND status.STATI_DETAIL_CODE = advice.status
    where advice.INPAT_NO = @inp_id
      and ext.INPAT_NO = @inp_id
      and (advice.status in (1, 2, 3) or
           (advice.status = 6 and ext.STOP_DATE < getdate())) --0:暂存;1:提交;2:护士确认;3:护士执行;4:停止;5:全停;6:预停;7:护士停止确认;8:作废;9:护士作废确认;10:撤销
--       and advice.ADVICE_CLASS not in ('99', '11')             --嘱托和护理不做拦截

    union all

    --检查
    --明细状态 ： 
    select '[未停止的电子申请]: ' + convert(varchar, apply_inspect_detail.APPLY_ID) + '检查' as typeName,
           apply_inspect_detail.MED_ADVICE_NAME                                    as itemName,
           AUTH_DEPT.dept_name                                                     as deptName,
           status.STATI_DETAIL_NAME                                                as status,
           apply_inspect_detail.update_date                                        as operationTime,
           ''                                                                         checkType
    from CISEAPP..apply_inspect_detail apply_inspect_detail
             left join CISEAPP..apply_inspect_master apply_inspect_master
                       on apply_inspect_master.apply_id = apply_inspect_detail.apply_id
             left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_inspect_master.accept_dept_id = AUTH_DEPT.id
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
                       ON status.STATIC_CODE = 'inspect_status' AND
                          status.STATI_DETAIL_CODE = apply_inspect_detail.apply_state
    where apply_inspect_master.INP_ID = @inp_id
      and apply_inspect_detail.apply_state in (0, 7, 22) --0是新申请，7医技登记，22取消登记
      and apply_inspect_master.APPLY_STATE != 0         --排除主单暂存状态

    union all

    --检验
    --明细表状态：
    select distinct '[未停止的电子申请]: ' + convert(varchar, apply_examine_detail.apply_id) + '检验' as typeName,
                    apply_examine_detail.MED_ADVICE_NAME                                    as itemName,
                    AUTH_DEPT.dept_name                                                     as deptName,
                    status.STATI_DETAIL_NAME                                                as status,
                    apply_examine_detail.update_date                                        as operationTime,
                    ''                                                                         checkType
    from CISEAPP..apply_examine_detail apply_examine_detail
             left join CISEAPP..APPLY_EXAMINE_MASTER APPLY_EXAMINE_MASTER
                       on APPLY_EXAMINE_MASTER.apply_id = apply_examine_detail.apply_id
             left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_examine_detail.excute_dept_id = AUTH_DEPT.id
             left join CISEAPP..apply_examine_compose apply_examine_compose
                       on apply_examine_compose.compose_id = apply_examine_detail.compose_id
             LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
                       ON status.STATIC_CODE = 'examine_status' AND
                      status.STATI_DETAIL_CODE = APPLY_EXAMINE_MASTER.apply_state
    where APPLY_EXAMINE_MASTER.INP_ID = @inp_id
      and apply_examine_detail.apply_state in (0, 23,24,17,27) --0 新申请，23 条码打印，24 撤销打印，17 标本采集，27 取消采集
      and APPLY_EXAMINE_MASTER.APPLY_STATE != 0 --排除主单暂存状态

--     union all

      --病理
      --病理状态配置,状态： 0暂存、1新申请、2护士确认、4科室接收、5科室取消（第三方回传）、6报告审核、7报告完成、8退费（仅门诊）、99作废
--     select '[未停止的电子申请]: ' + convert(varchar, apply_pathology_master.apply_id) + '病理' as typeName,
--            apply_pathology_detail.med_advice_name                                    as itemName,
--            AUTH_DEPT.dept_name                                                       as deptName,
--            status.STATI_DETAIL_NAME                                                  as status,
--            apply_pathology_master.update_date                                        as operationTime,
--            ''                                                                           checkType
--     from CISEAPP..apply_pathology_master apply_pathology_master
--              left join CISEAPP..apply_pathology_detail apply_pathology_detail
--                        on apply_pathology_master.apply_id = apply_pathology_detail.apply_id
--              left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_pathology_master.accept_dept_id = AUTH_DEPT.id
--              LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
--                        ON status.STATIC_CODE = 'pathology_status' AND
--                           status.STATI_DETAIL_CODE = apply_pathology_master.apply_state
--     where apply_pathology_master.INP_ID = @inp_id
--       and apply_pathology_master.apply_state in (1, 4, 6)

--     union all
--
--     --治疗
--     -- 治疗状态配置, 状态： 0暂存、1新申请、2护士确认、4科室接收、7治疗完成、8退费（仅门诊）、99作废
--     select '[未停止的电子申请]: ' + convert(varchar, apply_treatment_master.apply_id) + '治疗' as typeName,
--            apply_treatment_detail.med_advice_name                                    as itemName,
--            AUTH_DEPT.dept_name                                                       as deptName,
--            status.STATI_DETAIL_NAME                                                  as status,
--            apply_treatment_master.update_date                                        as operationTime
--     from CISEAPP..apply_treatment_master apply_treatment_master
--              left join CISEAPP..apply_treatment_detail apply_treatment_detail
--                        on apply_treatment_master.apply_id = apply_treatment_detail.apply_id
--              left join CISCOMM..AUTH_DEPT AUTH_DEPT on apply_treatment_master.accept_dept_id = AUTH_DEPT.id
--              LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
--                        ON status.STATIC_CODE = 'treatment_status' AND
--                           status.STATI_DETAIL_CODE = apply_treatment_master.apply_state
--     where apply_treatment_master.INP_ID = @inp_id
--       and apply_treatment_master.apply_state in (1, 2, 4, 8)

--     union all
--     --
--     --手术校验 ，走第三方his
--     select '[未停止的电子申请]: ' + convert(varchar, A.手术登记ID) + '手术' as typeName,
--            B.手术名称                                             as itemName,
--            ''                                                 as deptName,
--            case
--                when A.手术状态 = '0' then '申请'
--                when A.手术状态 = '1' then '排班'
--                when A.手术状态 = '2' then '登记'
--                when A.手术状态 = '3' then '审核'
--                when A.手术状态 = '4' then '术中'
--                when A.手术状态 = '5' then '完成'
--                when A.手术状态 = '6' then '记账'
--                when A.手术状态 = '8' then '归档'
--                when A.手术状态 = '9' then '入帐' end
--                                                               as status,
--            A.申请时间                                             as operationTime,
--            ''                                                    checkType
--     from FGHIS5.dbo.手术_登记表 A
--              JOIN FGHIS5.dbo.手术_手术明细表 B on A.手术登记ID = B.手术登记ID
--     where B.序号 = 1
--       AND A.登记部门 Like '手术%'
--       AND B.登记类型 = 0
--       AND 住院ID = @IN_HOSPITAL_ID
--       AND (@ADDITIONAL_ID = -1 or 附加ID = @ADDITIONAL_ID)
--       AND A.手术状态 NOT in (5, 7, 8)
--     union all
--     select '[未停止的电子申请]: ' + convert(varchar, A.手术登记ID) + '麻醉' as typeName,
--            B.手术名称                                             as itemName,
--            ''                                                 as deptName,
--            case
--                when A.手术状态 = '0' then '申请'
--                when A.手术状态 = '1' then '排班'
--                when A.手术状态 = '2' then '登记'
--                when A.手术状态 = '3' then '审核'
--                when A.手术状态 = '4' then '术中'
--                when A.手术状态 = '5' then '完成'
--                when A.手术状态 = '6' then '记账'
--                when A.手术状态 = '8' then '归档'
--                when A.手术状态 = '9' then '入帐' end                as status,
--            A.申请时间                                             as operationTime,
--            ''                                                    checkType
--     from FGHIS5.dbo.手术_登记表 A
--              JOIN FGHIS5.dbo.手术_手术明细表 B on A.手术登记ID = B.手术登记ID
--     where B.序号 = 1
--       AND A.登记部门 Like '%麻醉'
--       AND B.登记类型 = 0
--       AND 住院ID = @IN_HOSPITAL_ID
--       AND (@ADDITIONAL_ID = -1 or 附加ID = @ADDITIONAL_ID)
--       AND A.手术状态 NOT in (7)
--       AND A.麻醉状态 NOT in (5, 7, 8)


      --手术 查cis申请单状态的
      --手术状态配置, 状态：0暂存 1新申请 2-科主任审核 3登记 4排班 5记账 6入帐 7审核 8完成 10作废 11预约-1失效 12待审核
--     select '[未停止的电子申请]: ' + convert(varchar, ope_pat_register.id) + '手术' as typeName,
--            (stuff((select distinct ',' + T2.OPE_NAME
--                    FROM CISEAPP..ope_detail_info T2
--                    WHERE T2.ope_regist_id = ope_pat_register.id
--                    for xml path('')), 1, 1, ''))                         as itemName,
--            null                                                          as deptName,
--            status.STATI_DETAIL_NAME                                      as status,
--            ope_doc_register.update_date                                     operationTime,
--            ''                                                               checkType
--     from CISEAPP..ope_pat_register ope_pat_register
--              left join CISEAPP..ope_doc_register ope_doc_register
--                        on ope_pat_register.id = ope_doc_register.ope_regist_id
--              left join CISCOMM..AUTH_DEPT AUTH_DEPT on ope_doc_register.dept_id = AUTH_DEPT.id
--              LEFT JOIN CISCOMM..CIS_STATIC_DETAIL_DICT status
--                        ON status.STATIC_CODE = 'ope_status' AND
--                           status.STATI_DETAIL_CODE = ope_pat_register.state
--     where INP_ID = @inp_id
--       and ope_pat_register.state in (1, 3, 4, 5, 7)


    union all

    --排药
    select '[已排药申请]: ' + cast(t.ADVICE_ID as VARCHAR) typeName,
           t.drug_name as                             itemName,
           p.dept_name as                             deptName,
           '病区申请'      as                             status,
           t.gen_time  as                             operationTime,
           ''                                         checkType
    from CISPRO..V_DRUG_DISCHARGE_TEMP t
             left join CISDOCT..DOC_ADVICE d on t.advice_id = d.advice_id
             left join CISCOMM..AUTH_DEPT p on t.Pharmacy_Id = p.id
             left join CISCOMM..CIS_HOSTPITAL_INFO h on t.INP_ID = h.IN_HOSPITAL_ID
    where h.INP_ID = @inp_id
      and t.status = 0
      and t.DOC_TYPE = 0
      and t.APPLY_M_QUANTITY > 0

    union all
    --退药
    select '[已退药申请]: ' + cast(t.ADVICE_ID as VARCHAR) typeName,
           t.drug_name as                             itemName,
           p.dept_name as                             deptName,
           '病区申请'      as                             status,
           t.gen_time  as                             operationTime,
           ''                                         checkType
    from CISPRO..V_DRUG_DISCHARGE_TEMP t
             left join CISDOCT..DOC_ADVICE d on t.advice_id = d.advice_id
             left join CISCOMM..AUTH_DEPT p on t.Pharmacy_Id = p.id
             left join CISCOMM..CIS_HOSTPITAL_INFO h on t.INP_ID = h.IN_HOSPITAL_ID
    where h.INP_ID = @inp_id
      and t.status = 0
      and t.DOC_TYPE = 2

    union all


    --未收费的项目，非强拦
    select '存在未收费执行的项目：'   as typeName,
           doc.ADVICE_NAME as itemName,
           dept.DEPT_NAME  as deptName,
           '未收费'              status,
           convert(datetime,
                   FORMAT(CONVERT(bigint, cost.EXPENSES_DATE + cost.EXPENSES_TIME), '####-##-## ##:##:##'),
                   120)    as operationTime,
           '1'             as checkType
    from CISNURS..NUR_COST cost
             left join CISDOCT..DOC_ADVICE doc on cost.ADVICE_ID = doc.ADVICE_ID
             left join CISCOMM..AUTH_DEPT dept on dept.ID = cost.DEPT_ID

    where cost.STATUS = '0'
      and cost.INP_ID = @inp_id

    union all
    -- 费用日期时间在入院日期时间前和出院日期时间后，提示有不在住院时间范围的费用
    select '[存在非住院时间范围的费用]： ' as typeName,
           a.ITEM_NAME        as itemName,
           a.DEPT_NAME        as deptName,
           '已计费'              as status,
           convert(datetime,
                   FORMAT(CONVERT(bigint, a.EXPENSES_DATE + a.EXPENSES_TIME), '####-##-## ##:##:##'),
                   120)       as operationTime,
           ''                    checkType
    from (
             select t.INP_ID,
                    t.PATIENT_ID,
                    t.IN_HOSPITAL_ID,
                    t.ADVICE_ID,
                    t.DEPT_ID,
                    t.WARD_ID,
                    t.ADDITIONAL_ID,
                    t.STATUS,
                    t.EXPENSES_DATE,
                    t.EXPENSES_TIME,
                    dept.DEPT_NAME,
                    t.ITEM_NAME,
                    t.ITEM_CLASS,
                    t.ITEM_ID
             from CISPRO..V_INP_FEE_WASTE t
                      left join CISCOMM..CIS_HOSTPITAL_INFO t1
                                on t.INP_ID = t1.INP_ID

                      left join CISCOMM..AUTH_DEPT dept on t.DEPT_ID = dept.ID
             where t.IN_HOSPITAL_ID = @IN_HOSPITAL_ID
               and (
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t.EXPENSES_DATE + t.EXPENSES_TIME), '####-##-## ##:##:##'), 120)
                         <
                         convert(datetime,
                                 FORMAT(CONVERT(bigint, t1.INP_TIME), '####-##-## ##:##:##'), 120)
        
                 )
               and t.STATUS =1
             group by t.INP_ID, t.PATIENT_ID, t.IN_HOSPITAL_ID, t.ADVICE_ID, t.DEPT_ID, t.WARD_ID, t.ADDITIONAL_ID,
                      t.STATUS, t.EXPENSES_DATE, t.EXPENSES_TIME, dept.DEPT_NAME, t.ITEM_NAME, t.ITEM_CLASS,
                      t.ITEM_ID
             having sum(t.QUANTITY) > 0
         ) a

         --查询床位固定费用计费数量
    union all

    select case
               when @quantity > @fixedCostQuantity then
                       '[' + t1.BED_NO + '床]：床位固定费用少于应计费用，所差数量：' +
                       convert(varchar(10), (@quantity - @fixedCostQuantity))
               end        as typeName,
           '床位费'          as itemName,
           dept.DEPT_NAME as deptName,
           ''             as status,
           null           as operationTime,
           '1'            as checkType
    from CISCOMM..CIS_HOSTPITAL_INFO t1
             left join ciscomm..AUTH_DEPT dept on dept.ID = t1.DEPT_ID
    where t1.INP_ID = @inp_id
      and @quantity > @fixedCostQuantity

      --查询护理费计费数量
    union all

    select case
               when @quantity > @nurseCostQuantity then
                       '[' + t1.BED_NO + '床]：护理费用少于应计费用，所差数量：' + convert(varchar(10), (@quantity - @nurseCostQuantity))
               end     as typeName,
           '护理费'          as itemName,
           dept.DEPT_NAME as deptName,
           ''             as status,
           null           as operationTime,
           '1'            as checkType
    from CISCOMM..CIS_HOSTPITAL_INFO t1
             left join ciscomm..AUTH_DEPT dept on dept.ID = t1.DEPT_ID
    where t1.INP_ID = @inp_id
      and @quantity > @nurseCostQuantity;

    select * from @temp_table;

end ;
go

