-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-申请医技费用明细表(APPLY_MED_FEE_DETAIL)
-- Description:	 通过作业定时去同步his中新增或者修改的申请医技费用明细表
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_MED_FEE_DETAIL]
	 
AS
BEGIN
		
      merge ciseapp..APPLY_MED_FEE_DETAIL as A
	  using(
	  SELECT t.流水号 id, 
				a.流水号 med_advice_id, 
				t.收费类别 item_type, 
				t.收费ID item_id, 
				t.收费代码 item_code, 
				t.收费数量 fee_count, 
				t.部门代码 dept_id FROM  fghis5_mz.dbo.代码_申请医技相关收费 t 
				inner join fghis5_mz.dbo.代码_申请医技项目表 a on t.医嘱代码=a.医嘱代码
			)B ON A.id=B.id
			when not matched then 
			INSERT (ID
				,MED_ADVICE_ID
				,ITEM_TYPE
				,ITEM_ID
				,ITEM_CODE
				,FEE_COUNT
				,DEPT_ID
				,CREATE_ID
				,CREATE_DATE
				,UPDATE_ID
				,UPDATE_DATE
				,ORG_ID) 
		values(B.ID
			,B.MED_ADVICE_ID
			,B.ITEM_TYPE
			,B.ITEM_ID
			,B.ITEM_CODE
			,B.FEE_COUNT
			,B.DEPT_ID
			,-1  
			,getdate() 
			,null 
			,null  
			,'10001'  )	
			when not matched by source THEN DELETE    ----当B表中没有时，删除A表对应记录
			;

			 
END
go

