CREATE FUNCTION [dbo].[InitCap] ( @iString VARCHAR(5000) ) 
RETURNS VARCHAR(5000)
AS
BEGIN
DECLARE @tIndex          INT
DECLARE @tChar           CHAR(1)
DECLARE @pChar       CHAR(1)
DECLARE @oString   VARCHAR(5000)

SET @oString = LOWER(@iString)
SET @tIndex = 1

WHILE @tIndex <= LEN(@iString)
BEGIN
    SET @tChar     = SUBSTRING(@iString, @tIndex, 1)
    SET @pChar = CASE WHEN @tIndex = 1 THEN ' '
                         ELSE SUBSTRING(@iString, @tIndex - 1, 1)
END
IF @pChar IN (' ', ';', ':', '!', '?', ',', '.', '_', '-', '/', '&', '''', '(')
    BEGIN
        IF @pChar != '''' OR UPPER(@tChar) != 'S'
            SET @oString = STUFF(@oString, @tIndex, 1, UPPER(@tChar))
    END
    SET @tIndex = @tIndex + 1
END
RETURN @oString
END
go

