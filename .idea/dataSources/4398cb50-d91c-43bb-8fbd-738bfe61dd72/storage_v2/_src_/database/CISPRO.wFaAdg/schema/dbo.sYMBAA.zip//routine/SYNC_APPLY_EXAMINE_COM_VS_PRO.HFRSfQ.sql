-- =============================================
-- Author:		
-- Create date: 
-- Title： 同步电子申请-检验组合项目对照表(APPLY_EXAMINE_COM_VS_PRO)
-- Description:	 通过作业定时去同步his中新增或者修改的检验组合项目对照表
-- =============================================
CREATE PROCEDURE [dbo].[SYNC_APPLY_EXAMINE_COM_VS_PRO]
	 
AS
BEGIN  
      declare @num numeric(10)
	  select @num=MAX(t.ID) from ciseapp..APPLY_EXAMINE_COM_VS_PRO t ;

      merge ciseapp..APPLY_EXAMINE_COM_VS_PRO as A
	  using(
			 select row_number() over(order by t.项目id)+@num id, 
					t.组合ID compose_id, 
					t.项目id med_advice_id from  fghis5_mz.dbo.代码_申请检验项目表 t where t.组合ID is not null
			)B ON A.compose_id=B.compose_id and a.med_advice_id=b.med_advice_id
			when not matched then 
			INSERT ([ID]
           ,[COMPOSE_ID]
           ,[MED_ADVICE_ID]
           ,[CREATE_ID]
           ,[CREATE_DATE]
           ,[UPDATE_ID]
           ,[UPDATE_DATE]) 
		values(ID
           ,b.COMPOSE_ID
           ,b.MED_ADVICE_ID
			,-1
			,GETDATE()  
			,null  
			,null )	
		when not matched by source THEN DELETE   ; ----当B表中没有时，删除A表对应记录			

      
          

	 
END


go

