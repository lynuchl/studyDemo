
Create FUNCTION [dbo].[F_STRSPLIT] (@str VARCHAR(max))  
RETURNS @tableName TABLE ( Name nvarchar(50) )  
AS   
 
BEGIN  
  SET @str = REPLACE(REPLACE(@str , '，' , ',') , '，' , ',')  
  SET @str = @str + ','  
  DECLARE @insertStr VARCHAR(max)  
  
  --截取后的第一个字符串  
  DECLARE @newstr VARCHAR(max)  
  
  --截取第一个字符串后剩余的字符串  
  SET @insertStr = LEFT(@str , CHARINDEX(',' , @str) - 1)  
  SET @newstr = STUFF(@str , 1 , CHARINDEX(',' , @str) , '')  
  INSERT @tableName  
    VALUES ( CAST(@insertStr AS nvarchar) )  
  WHILE (LEN(@newstr) > 0)  
  BEGIN  
  SET @insertStr = LEFT(@newstr , CHARINDEX(',' , @newstr) - 1)  
  INSERT @tableName  
    VALUES ( CAST(@insertStr AS nvarchar) )  
  SET @newstr = STUFF(@newstr , 1 , CHARINDEX(',' , @newstr) , '')  
  END  
  RETURN  
END

go

