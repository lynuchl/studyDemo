-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	备份基础数据
-- =============================================
CREATE PROCEDURE [dbo].[BASE_DATA_BAK]
	 
AS
BEGIN 
	 INSERT INTO  [CISCOMM].DBO.[AUTH_OPERATOR_BAK]
	 select t.*,GETDATE() from CISCOMM.DBO.AUTH_OPERATOR t; 

	 INSERT INTO [CISCOMM].[dbo].[AUTH_PERM_BAK]
      select t.*,GETDATE() from [CISCOMM].[dbo].[AUTH_PERM] t;

      insert into [CISCOMM].[dbo].[AUTH_PERM_VS_OPR_BAK]
	  select t.*,GETDATE() from [CISCOMM].[dbo].AUTH_PERM_VS_OPR t;

      insert into [CISCOMM].[dbo].[AUTH_PERM_VS_ROLE_BAK]
	  select t.*,GETDATE() from [CISCOMM].[dbo].[AUTH_PERM_VS_ROLE] t;

	  insert into [CISCOMM].[dbo].[AUTH_ROLE_VS_MENU_BAK]
	  select t.*,GETDATE() from [CISCOMM].[dbo].[AUTH_ROLE_VS_MENU]  t;

	  insert into [CISCOMM].[dbo].AUTH_ROLE_VS_OPR_BAK
	  select t.*,GETDATE() from [CISCOMM].[dbo].AUTH_ROLE_VS_OPR  t;

	  insert into [CISCOMM].[dbo].AUTH_TITLE_VS_OPR_BAK
	  select t.*,GETDATE() from [CISCOMM].[dbo].AUTH_TITLE_VS_OPR  t;
	  
	  insert into [CISEMR].[dbo].REC_PERMIT_BAK
	  select t.*,GETDATE() from [CISEMR].[dbo].REC_PERMIT  t;

	  insert into [CISEMR].[dbo].REC_VS_DEPT_BAK
	  select t.*,GETDATE() from [CISEMR].[dbo].REC_VS_DEPT  t;

END
go

